package com.example.m3uplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Spark(val angle: Float, val dist: Float, val size: Float)

/**
 * Intro animée à l'ouverture (environ 4 s) :
 * logo qui tourne en 3D, halo, faisceaux de lumière, étincelles,
 * nom « IR PRO » qui se resserre, puis zoom vers l'accueil.
 */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val logoAlpha = remember { Animatable(0f) }
    val logoRot = remember { Animatable(-540f) }
    val logoScale = remember { Animatable(0.3f) }
    val glow = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    val word = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }
    val sparks = remember {
        List(40) { Spark(Random.nextFloat() * 6.283f, 0.25f + Random.nextFloat() * 0.6f, 2f + Random.nextFloat() * 3f) }
    }
    val glowColor = LogoPurple
    val rayColor = LogoPurpleLight

    LaunchedEffect(Unit) {
        launch { logoAlpha.animateTo(1f, tween(400)) }
        launch { logoRot.animateTo(0f, tween(1600, easing = FastOutSlowInEasing)) }
        launch {
            logoScale.animateTo(1.15f, tween(1150, easing = FastOutSlowInEasing))
            logoScale.animateTo(1f, tween(450))
        }
        delay(800)
        launch { glow.animateTo(1f, tween(1800)) }
        delay(250)
        launch { burst.animateTo(1f, tween(1500, easing = LinearOutSlowInEasing)) }
        delay(300)
        word.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        delay(1000)
        exit.animateTo(1f, tween(750, easing = FastOutLinearInEasing))
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .graphicsLayer {
                val s = 1f + 2f * exit.value
                scaleX = s
                scaleY = s
                alpha = 1f - exit.value
            },
        contentAlignment = Alignment.Center
    ) {
        // Halo, faisceaux et étincelles
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val g = glow.value
            val glowAlpha = if (g < 0.4f) g / 0.4f else 1f - (g - 0.4f) * 1.1f
            if (g > 0f) {
                val r = size.minDimension * (0.25f + 0.25f * g)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(glowColor.copy(alpha = 0.8f * glowAlpha.coerceIn(0f, 1f)), Color.Transparent),
                        center = c,
                        radius = r
                    ),
                    radius = r,
                    center = c
                )
            }
            val b = burst.value
            if (b > 0f && b < 1f) {
                val fade = 1f - b
                for (i in 0 until 14) {
                    val a = i * (6.283f / 14)
                    val len = size.maxDimension * 0.75f * b
                    val start = c + Offset(cos(a) * len * 0.25f, sin(a) * len * 0.25f)
                    val end = c + Offset(cos(a) * len, sin(a) * len)
                    drawLine(rayColor.copy(alpha = 0.85f * fade), start, end, strokeWidth = 3f, cap = StrokeCap.Round)
                }
                sparks.forEach { p ->
                    val d = size.minDimension * p.dist * b
                    drawCircle(
                        Color.White.copy(alpha = fade),
                        radius = p.size * (1f - b * 0.5f),
                        center = c + Offset(cos(p.angle) * d, sin(p.angle) * d)
                    )
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier.graphicsLayer {
                    rotationY = logoRot.value
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                    alpha = logoAlpha.value
                    cameraDistance = 16f * density
                }
            ) {
                IrProIcon(130.dp)
            }
            Spacer(Modifier.height(30.dp))
            Text(
                "IR PRO",
                color = Color.White.copy(alpha = word.value),
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (14f + 30f * (1f - word.value)).sp
            )
        }
    }
}
