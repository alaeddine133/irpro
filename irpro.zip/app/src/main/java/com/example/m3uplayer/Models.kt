package com.example.m3uplayer

data class Channel(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String,
    val streamId: String? = null,
    val epgId: String? = null
) {
    val favKey: String get() = url
}

data class Movie(
    val id: String,
    val name: String,
    val poster: String?,
    val category: String,
    val ext: String,
    val rating: String?,
    val added: Long
) {
    val favKey: String get() = "movie:$id"
}

data class Series(
    val id: String,
    val name: String,
    val cover: String?,
    val category: String,
    val plot: String?,
    val rating: String?,
    val added: Long
) {
    val favKey: String get() = "series:$id"
}

data class Episode(
    val id: String,
    val title: String,
    val season: Int,
    val num: Int,
    val ext: String,
    val image: String?,
    val plot: String?,
    val durationSec: Int?
)

data class SeriesInfo(
    val plot: String?,
    val cover: String?,
    val genre: String?,
    val year: String?,
    val seasons: Map<Int, List<Episode>>
)

data class MovieInfo(
    val plot: String?,
    val genre: String?,
    val year: String?,
    val duration: String?,
    val cast: String?,
    val director: String?,
    val backdrop: String?
)

data class EpgEntry(val title: String, val desc: String, val start: Long, val end: Long) {
    fun progress(nowSec: Long): Float =
        if (end > start) ((nowSec - start).toFloat() / (end - start)).coerceIn(0f, 1f) else 0f

    fun isNow(nowSec: Long) = nowSec in start until end
}

/** Tout ce que le lecteur sait lire : chaîne, film ou épisode. */
data class Playable(
    val title: String,
    val subtitle: String,
    val url: String,
    val image: String?,
    val isLive: Boolean,
    val key: String,
    val channel: Channel? = null
)
