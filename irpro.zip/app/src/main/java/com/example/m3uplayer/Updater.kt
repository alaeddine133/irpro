package com.example.m3uplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Updater {

    /** Lien fixe vers la dernière version publiée sur GitHub */
    val apkUrl: String
        get() = "https://github.com/${AppViewModel.GITHUB_OWNER}/${AppViewModel.GITHUB_REPO}/releases/latest/download/irpro.apk"

    /** Dossier où l'on range le fichier téléchargé */
    fun targetFile(context: Context): File {
        val dir = if (Build.VERSION.SDK_INT >= 24) {
            File(context.cacheDir, "updates")
        } else {
            // Android 7 et moins : l'installateur doit pouvoir lire le fichier directement
            context.getExternalFilesDir(null) ?: File(context.cacheDir, "updates")
        }
        dir.mkdirs()
        return File(dir, "irpro.apk")
    }

    /** Télécharge la mise à jour. [onProgress] reçoit une valeur de 0 à 1. */
    fun download(context: Context, onProgress: (Float) -> Unit): File {
        val out = targetFile(context)
        var url = URL(apkUrl)
        var conn: HttpURLConnection
        var redirects = 0
        // GitHub redirige vers son serveur de fichiers : on suit les redirections
        while (true) {
            conn = url.openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.setRequestProperty("User-Agent", "IRPRO-Updater")
            val code = conn.responseCode
            if (code in 300..399 && redirects < 5) {
                val loc = conn.getHeaderField("Location") ?: break
                url = URL(url, loc)
                conn.disconnect()
                redirects++
                continue
            }
            if (code !in 200..299) throw IllegalStateException("Erreur $code pendant le téléchargement")
            break
        }
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            out.outputStream().use { output ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    done += n
                    if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                }
            }
        }
        conn.disconnect()
        if (out.length() < 100_000) throw IllegalStateException("Fichier de mise à jour incomplet")
        return out
    }

    /** Ouvre l'installateur Android. Renvoie un message si quelque chose bloque. */
    fun install(context: Context, file: File): String? {
        if (Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            return try {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "Autorise IR PRO à installer des applis, puis reviens et appuie à nouveau sur Installer."
            } catch (e: Exception) {
                "Autorise IR PRO dans les paramètres de la box : Applications > Accès spécial > Installer des applis inconnues."
            }
        }
        val uri = if (Build.VERSION.SDK_INT >= 24) {
            FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        } else {
            Uri.fromFile(file)
        }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            null
        } catch (e: Exception) {
            "Impossible d'ouvrir l'installateur. Utilise Downloader avec ton code."
        }
    }
}

/** Fenêtre « Nouvelle version disponible » avec téléchargement et installation. */
@Composable
fun UpdateDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val progress = vm.updateProgress
    AlertDialog(
        onDismissRequest = { if (progress == null) onDismiss() },
        containerColor = Panel,
        title = {
            Text(
                if (vm.updateAvailable) "Nouvelle version d'IR PRO" else "Mise à jour de l'appli",
                color = TextMain
            )
        },
        text = {
            Column {
                Text(
                    "Version installée : ${vm.currentVersion}" +
                        (vm.latestVersion?.let { "\nDernière version : $it" } ?: ""),
                    color = TextSoft, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                when {
                    progress != null -> {
                        Text("Téléchargement… ${(progress * 100).toInt()} %", color = TextMain, fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth(),
                            color = PurpleMid,
                            trackColor = CardBg
                        )
                    }
                    vm.updateMessage != null -> Text(vm.updateMessage ?: "", color = TextMain, fontSize = 15.sp)
                    vm.updateAvailable -> Text(
                        "Une mise à jour est prête. Tes comptes, favoris et réglages sont conservés.",
                        color = TextMain, fontSize = 15.sp
                    )
                    else -> Text("Tu as déjà la dernière version.", color = TextMain, fontSize = 15.sp)
                }
            }
        },
        confirmButton = {
            if (vm.updateAvailable && progress == null) {
                TextButton(onClick = {
                    vm.downloadUpdate { file ->
                        vm.setUpdateMessageValue(Updater.install(context, file) ?: "Installation en cours…")
                    }
                }) { Text("Installer maintenant") }
            } else if (!vm.updateAvailable && progress == null) {
                TextButton(onClick = { vm.checkUpdateNow() }) { Text("Vérifier") }
            }
        },
        dismissButton = {
            if (progress == null) TextButton(onClick = onDismiss) { Text(if (vm.updateAvailable) "Plus tard" else "Fermer") }
        }
    )
}
