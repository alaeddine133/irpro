package com.example.m3uplayer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Accueil", Icons.Filled.Home),
    LIVE("Direct", Icons.Filled.LiveTv),
    GUIDE("Guide TV", Icons.Filled.CalendarMonth),
    MOVIES("Films", Icons.Filled.Movie),
    SERIES("Séries", Icons.Filled.Tv),
    SEARCH("Recherche", Icons.Filled.Search),
    FAVS("Favoris", Icons.Filled.Favorite),
    SETTINGS("Paramètres", Icons.Filled.Settings)
}

sealed interface Overlay {
    data class MovieDetail(val movie: Movie) : Overlay
    data class SeriesDetail(val series: Series) : Overlay
    data class Play(val items: List<Playable>, val index: Int) : Overlay
    data class Replay(val channel: Channel) : Overlay
}

/** Actions de navigation partagées par tous les écrans. */
class Nav(
    val play: (List<Playable>, Int) -> Unit,
    val openMovie: (Movie) -> Unit,
    val openSeries: (Series) -> Unit,
    val openSource: () -> Unit,
    val openReplay: (Channel) -> Unit
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = PurpleMid,
                    background = Bg,
                    surface = Panel,
                    onSurface = TextMain,
                    onBackground = TextMain
                )
            ) {
                App()
            }
        }
    }
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    var splash by remember { mutableStateOf(true) }
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    val stack = remember { mutableStateListOf<Overlay>() }
    var showSource by remember { mutableStateOf(false) }

    // Sans intro : simple écran de démarrage de 1,6 s
    LaunchedEffect(Unit) {
        if (!vm.introEnabled) {
            delay(1_600)
            splash = false
        }
    }

    val nav = remember {
        Nav(
            play = { list, i -> if (list.isNotEmpty()) stack.add(Overlay.Play(list, i.coerceIn(0, list.size - 1))) },
            openMovie = { stack.add(Overlay.MovieDetail(it)) },
            openSeries = { stack.add(Overlay.SeriesDetail(it)) },
            openSource = { showSource = true },
            openReplay = { stack.add(Overlay.Replay(it)) }
        )
    }

    // Relance de la dernière chaîne au démarrage (si activé dans les paramètres)
    var autoDone by remember { mutableStateOf(false) }
    LaunchedEffect(splash, vm.channels) {
        if (splash || autoDone || !vm.autoLastChannel || vm.channels.isEmpty()) return@LaunchedEffect
        autoDone = true
        val last = vm.lastChannel() ?: return@LaunchedEffect
        val group = vm.channels.filter { it.group == last.group }
        nav.play(group.map { vm.playableOf(it) }, group.indexOf(last).coerceAtLeast(0))
    }

    BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        if (splash) {
            if (vm.introEnabled) IntroScreen(onDone = { splash = false }) else Splash()
        } else {
            when (val top = stack.lastOrNull()) {
                null -> MainLayout(vm, tab, { tab = it }, nav)
                is Overlay.MovieDetail -> MovieDetailScreen(vm, top.movie, nav)
                is Overlay.SeriesDetail -> SeriesDetailScreen(vm, top.series, nav)
                is Overlay.Replay -> ReplayScreen(vm, top.channel, nav)
                is Overlay.Play -> PlayerScreen(vm, top.items, top.index, onBack = {
                    if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
                })
            }
        }
    }

    if (showSource) AddSourceDialog(vm, onDismiss = { showSource = false })
    // Fenêtre de mise à jour (pas pendant l'intro ni pendant la lecture)
    if (vm.showUpdateDialog && !splash && stack.lastOrNull() !is Overlay.Play) {
        UpdateDialog(vm, onDismiss = { vm.showUpdateDialog = false })
    }
}

@Composable
fun Splash() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IrProIcon(120.dp)
        Spacer(Modifier.height(24.dp))
        IrProWordmark(52.sp)
        Spacer(Modifier.height(32.dp))
        LinearProgressIndicator(Modifier.width(220.dp), color = PurpleMid, trackColor = CardBg)
    }
}

@Composable
fun MainLayout(vm: AppViewModel, tab: Tab, onTab: (Tab) -> Unit, nav: Nav) {
    when (vm.layoutStyle) {
        "premium" -> PremiumLayout(vm, tab, onTab, nav)
        "classic" -> ClassicLayout(vm, tab, onTab, nav)
        "mosaic" -> MosaicLayout(vm, tab, onTab, nav)
        else -> ModernLayout(vm, tab, onTab, nav)
    }
}

/** Contenu d'un onglet (commun aux 3 styles). */
@Composable
fun TabContent(vm: AppViewModel, tab: Tab, nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        if (vm.loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = PurpleMid, trackColor = Panel)
        }
        vm.errorMsg?.let {
            Text(it, color = FavPink, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (!vm.hasSource && tab != Tab.SETTINGS) {
                if (vm.loading) EmptyMessage("Chargement de tes chaînes, films et séries…") else Welcome(nav)
            } else {
                when (tab) {
                    Tab.HOME -> HomeScreen(vm, nav)
                    Tab.LIVE -> LiveScreen(vm, nav)
                    Tab.GUIDE -> GuideScreen(vm, nav)
                    Tab.MOVIES -> MoviesScreen(vm, nav)
                    Tab.SERIES -> SeriesScreen(vm, nav)
                    Tab.SEARCH -> SearchScreen(vm, nav)
                    Tab.FAVS -> FavoritesScreen(vm, nav)
                    Tab.SETTINGS -> SettingsScreen(vm, nav)
                }
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun ModernLayout(vm: AppViewModel, tab: Tab, onTab: (Tab) -> Unit, nav: Nav) {
    var railFocused by remember { mutableStateOf(false) }
    val railWidth by animateDpAsState(if (railFocused) 220.dp else 88.dp, label = "rail")
    val requesters = remember { Tab.entries.associateWith { FocusRequester() } }

    LaunchedEffect(Unit) {
        delay(150)
        runCatching { requesters.getValue(tab).requestFocus() }
    }

    Row(Modifier.fillMaxSize()) {
        // ---------- Menu latéral en icônes ----------
        Column(
            Modifier
                .width(railWidth)
                .fillMaxHeight()
                .background(Panel)
                .onFocusChanged { railFocused = it.hasFocus }
                .focusProperties { enter = { requesters.getValue(tab) } }
                .focusGroup()
                .padding(vertical = 14.dp, horizontal = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 6.dp, bottom = 14.dp)
            ) {
                IrProIcon(40.dp)
                if (railFocused) {
                    Spacer(Modifier.width(12.dp))
                    IrProWordmark(24.sp)
                }
            }
            Tab.entries.forEach { t ->
                FocusBox(
                    onClick = { onTab(t) },
                    onFocused = { onTab(t) },
                    focusScale = 1f,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .focusRequester(requesters.getValue(t))
                ) { focused ->
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            t.icon,
                            contentDescription = t.label,
                            tint = when {
                                focused -> Color.White
                                t == tab -> PurpleLight
                                else -> TextSoft
                            },
                            modifier = Modifier.size(24.dp)
                        )
                        if (railFocused) {
                            Spacer(Modifier.width(16.dp))
                            Text(
                                t.label,
                                color = if (focused || t == tab) TextMain else TextSoft,
                                fontSize = 17.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            RefreshButton(vm, compact = !railFocused, modifier = Modifier.fillMaxWidth())
        }

        // ---------- Contenu ----------
        Box(Modifier.weight(1f).fillMaxHeight()) {
            TabContent(vm, tab, nav)
        }
    }
}

@Composable
fun Welcome(nav: Nav) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IrProIcon(96.dp)
        Spacer(Modifier.height(20.dp))
        Text("Bienvenue sur IR PRO", color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Connecte ton compte Xtream Codes ou ajoute un lien M3U.", color = TextSoft, fontSize = 18.sp)
        Spacer(Modifier.height(30.dp))
        FocusBox(onClick = nav.openSource, selected = true, shape = RoundedCornerShape(30.dp)) {
            Text(
                "Se connecter",
                color = TextMain,
                fontSize = 20.sp,
                modifier = Modifier.padding(horizontal = 40.dp, vertical = 14.dp)
            )
        }
    }
}

@Composable
fun AddSourceDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    var mode by remember { mutableStateOf(vm.mode) }
    var url by remember { mutableStateOf(vm.lastUrl) }
    var server by remember { mutableStateOf(vm.savedServer) }
    var user by remember { mutableStateOf(vm.savedUser) }
    var pass by remember { mutableStateOf(vm.savedPass) }
    var accName by remember { mutableStateOf("") }
    var pickerError by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            vm.loadFile(uri)
            onDismiss()
        }
    }
    val isXtream = mode == "xtream"
    val canSubmit = if (isXtream) server.isNotBlank() && user.isNotBlank() && pass.isNotBlank() else url.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Compte et source", color = TextMain) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isXtream, onClick = { mode = "xtream" }, label = { Text("Xtream Codes") })
                    FilterChip(selected = !isXtream, onClick = { mode = "m3u" }, label = { Text("Lien M3U") })
                }
                Spacer(Modifier.height(12.dp))
                if (isXtream) {
                    OutlinedTextField(
                        value = accName, onValueChange = { accName = it },
                        label = { Text("Nom du compte (facultatif)") },
                        placeholder = { Text("Maison, Abonnement 2…") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = server, onValueChange = { server = it },
                        label = { Text("Serveur") },
                        placeholder = { Text("http://serveur.com:8080") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = user, onValueChange = { user = it },
                        label = { Text("Identifiant") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pass, onValueChange = { pass = it },
                        label = { Text("Mot de passe") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    OutlinedTextField(
                        value = url, onValueChange = { url = it },
                        label = { Text("Lien M3U") },
                        placeholder = { Text("http://exemple.com/playlist.m3u") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = {
                        pickerError = runCatching { picker.launch(arrayOf("*/*")) }.isFailure
                    }) { Text("Ou choisir un fichier .m3u") }
                    if (pickerError) {
                        Text("Cette box ne permet pas de choisir un fichier. Utilise un lien.", color = FavPink, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = canSubmit, onClick = {
                if (isXtream) vm.loadXtream(server, user, pass, accName) else vm.loadUrl(url.trim())
                onDismiss()
            }) { Text(if (isXtream) "Se connecter" else "Charger") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

/** Demande un code PIN à 4 chiffres. */
@Composable
fun PinDialog(title: String, onDismiss: () -> Unit, onPin: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title, color = TextMain) },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(4); wrong = false },
                    label = { Text("Code PIN (4 chiffres)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                if (wrong) Text("Code incorrect", color = FavPink, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text("Code par défaut : 0000", color = TextSoft, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = pin.length == 4, onClick = {
                if (onPin(pin)) onDismiss() else wrong = true
            }) { Text("Valider") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
