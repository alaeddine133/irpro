package com.example.m3uplayer

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class XtreamAccount(val server: String, val user: String, val pass: String)

data class XtreamInfo(val status: String, val expiry: String?)

object XtreamClient {

    private const val UA = "IRPRO/1.0"

    fun normalizeServer(raw: String): String {
        var s = raw.trim().trimEnd('/')
        s = s.removeSuffix("/player_api.php").removeSuffix("/get.php").trimEnd('/')
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
        return s
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Appelle l'API Xtream. [action] peut contenir des paramètres : "get_vod_info&vod_id=12". */
    fun api(acc: XtreamAccount, action: String?): String {
        val url = "${acc.server}/player_api.php?username=${enc(acc.user)}&password=${enc(acc.pass)}" +
            (action?.let { "&action=$it" } ?: "")
        return httpGet(url)
    }

    fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 90_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", UA)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("Le serveur a répondu avec l'erreur $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    // ---------- Compte ----------

    fun login(acc: XtreamAccount): XtreamInfo {
        val root = try {
            JSONObject(api(acc, null))
        } catch (e: Exception) {
            throw IllegalStateException("Ce serveur ne répond pas comme un serveur Xtream. Vérifie l'adresse.")
        }
        val ui = root.optJSONObject("user_info")
            ?: throw IllegalStateException("Identifiant ou mot de passe incorrect")
        if (ui.optInt("auth", 0) != 1) throw IllegalStateException("Identifiant ou mot de passe incorrect")
        val status = ui.optString("status")
        if (status.isNotBlank() && status != "null" && !status.equals("Active", ignoreCase = true)) {
            throw IllegalStateException("Abonnement non actif ($status)")
        }
        val expiry = ui.optString("exp_date").toLongOrNull()?.let {
            SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(it * 1000))
        }
        return XtreamInfo(status, expiry)
    }

    // ---------- Petits outils JSON ----------

    private fun JSONObject.str(key: String): String? =
        optString(key).takeIf { it.isNotBlank() && it != "null" }

    private fun parseArray(raw: String): JSONArray =
        try { JSONArray(raw) } catch (e: Exception) { JSONArray() }

    /** id de catégorie -> (position, nom) */
    private fun parseCategories(raw: String): Map<String, Pair<Int, String>> {
        val arr = parseArray(raw)
        val out = HashMap<String, Pair<Int, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out[o.optString("category_id")] = i to (o.str("category_name") ?: "Autres")
        }
        return out
    }

    private fun <T> sortByCategory(items: List<T>, order: List<Int>): List<T> =
        items.indices.sortedBy { order[it] }.map { items[it] }

    // ---------- Direct ----------

    fun liveUrl(acc: XtreamAccount, id: String) = "${acc.server}/live/${acc.user}/${acc.pass}/$id.ts"

    fun parseLive(acc: XtreamAccount, catsRaw: String, streamsRaw: String): List<Channel> {
        val cats = parseCategories(catsRaw)
        val arr = parseArray(streamsRaw)
        val out = ArrayList<Channel>(arr.length())
        val order = ArrayList<Int>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("stream_id") ?: continue
            val cat = cats[o.optString("category_id")]
            out += Channel(
                name = o.str("name") ?: "Chaîne $id",
                url = liveUrl(acc, id),
                logo = o.str("stream_icon"),
                group = cat?.second ?: "Autres",
                streamId = id,
                epgId = o.str("epg_channel_id"),
                archiveDays = if (o.optInt("tv_archive", 0) == 1) o.optInt("tv_archive_duration", 0).coerceAtLeast(1) else 0
            )
            order += cat?.first ?: Int.MAX_VALUE
        }
        return sortByCategory(out, order)
    }

    // ---------- Films ----------

    fun movieUrl(acc: XtreamAccount, m: Movie) = "${acc.server}/movie/${acc.user}/${acc.pass}/${m.id}.${m.ext}"

    fun parseMovies(catsRaw: String, raw: String): List<Movie> {
        val cats = parseCategories(catsRaw)
        val arr = parseArray(raw)
        val out = ArrayList<Movie>(arr.length())
        val order = ArrayList<Int>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("stream_id") ?: continue
            val cat = cats[o.optString("category_id")]
            out += Movie(
                id = id,
                name = o.str("name") ?: "Film $id",
                poster = o.str("stream_icon"),
                category = cat?.second ?: "Autres",
                ext = o.str("container_extension") ?: "mp4",
                rating = o.str("rating")?.takeIf { it != "0" },
                added = o.optString("added").toLongOrNull() ?: 0L
            )
            order += cat?.first ?: Int.MAX_VALUE
        }
        return sortByCategory(out, order)
    }

    fun movieInfo(acc: XtreamAccount, id: String): MovieInfo {
        val root = JSONObject(api(acc, "get_vod_info&vod_id=$id"))
        val info = root.optJSONObject("info") ?: JSONObject()
        val backdrop = info.optJSONArray("backdrop_path")?.let { if (it.length() > 0) it.optString(0) else null }
            ?.takeIf { it.isNotBlank() && it != "null" }
        return MovieInfo(
            plot = info.str("plot") ?: info.str("description"),
            genre = info.str("genre"),
            year = (info.str("releasedate") ?: info.str("release_date"))?.take(4),
            duration = info.str("duration"),
            cast = info.str("cast") ?: info.str("actors"),
            director = info.str("director"),
            backdrop = backdrop,
            trailer = trailerId(info.str("youtube_trailer") ?: info.str("trailer"))
        )
    }

    // ---------- Séries ----------

    fun episodeUrl(acc: XtreamAccount, e: Episode) = "${acc.server}/series/${acc.user}/${acc.pass}/${e.id}.${e.ext}"

    fun parseSeries(catsRaw: String, raw: String): List<Series> {
        val cats = parseCategories(catsRaw)
        val arr = parseArray(raw)
        val out = ArrayList<Series>(arr.length())
        val order = ArrayList<Int>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("series_id") ?: continue
            val cat = cats[o.optString("category_id")]
            out += Series(
                id = id,
                name = o.str("name") ?: "Série $id",
                cover = o.str("cover"),
                category = cat?.second ?: "Autres",
                plot = o.str("plot"),
                rating = o.str("rating")?.takeIf { it != "0" },
                added = o.optString("last_modified").toLongOrNull() ?: 0L
            )
            order += cat?.first ?: Int.MAX_VALUE
        }
        return sortByCategory(out, order)
    }

    fun seriesInfo(acc: XtreamAccount, id: String): SeriesInfo {
        val root = JSONObject(api(acc, "get_series_info&series_id=$id"))
        val info = root.optJSONObject("info") ?: JSONObject()
        val seasons = sortedMapOf<Int, MutableList<Episode>>()
        val eps = root.optJSONObject("episodes")
        if (eps != null) {
            val keys = eps.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = eps.optJSONArray(k) ?: continue
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val epId = o.str("id") ?: continue
                    val epInfo = o.optJSONObject("info")
                    val season = o.optString("season").toIntOrNull() ?: k.toIntOrNull() ?: 1
                    val num = o.optString("episode_num").toIntOrNull() ?: (i + 1)
                    seasons.getOrPut(season) { mutableListOf() } += Episode(
                        id = epId,
                        title = o.str("title") ?: "Épisode $num",
                        season = season,
                        num = num,
                        ext = o.str("container_extension") ?: "mp4",
                        image = epInfo?.str("movie_image"),
                        plot = epInfo?.str("plot"),
                        durationSec = epInfo?.optString("duration_secs")?.toIntOrNull()
                    )
                }
            }
        }
        return SeriesInfo(
            plot = info.str("plot"),
            cover = info.str("cover"),
            genre = info.str("genre"),
            year = (info.str("releaseDate") ?: info.str("release_date"))?.take(4),
            seasons = seasons.mapValues { (_, list) -> list.sortedBy { it.num } },
            trailer = trailerId(info.str("youtube_trailer") ?: info.str("trailer"))
        )
    }

    // ---------- Bandes-annonces ----------

    /** Accepte un identifiant YouTube ou un lien complet, renvoie l'identifiant. */
    fun trailerId(raw: String?): String? {
        val v = raw?.trim()?.takeIf { it.isNotBlank() && it != "null" } ?: return null
        Regex("""(?:v=|youtu\.be/|embed/|shorts/)([A-Za-z0-9_-]{6,})""").find(v)?.let { return it.groupValues[1] }
        return v.takeIf { Regex("[A-Za-z0-9_-]{6,20}").matches(it) }
    }

    // ---------- Guide TV (EPG) ----------

    private fun b64(s: String?): String {
        if (s.isNullOrBlank()) return ""
        return try {
            String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8).trim()
        } catch (e: Exception) {
            s
        }
    }

    fun shortEpg(acc: XtreamAccount, streamId: String): List<EpgEntry> {
        val root = JSONObject(api(acc, "get_short_epg&stream_id=$streamId&limit=8"))
        val arr = root.optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<EpgEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val start = o.optString("start_timestamp").toLongOrNull() ?: continue
            val end = o.optString("stop_timestamp").toLongOrNull() ?: continue
            out += EpgEntry(b64(o.optString("title")), b64(o.optString("description")), start, end)
        }
        return out.sortedBy { it.start }
    }
    // ---------- Replay (catch-up) ----------

    /** Guide complet d'une chaîne : passé (avec replay) et à venir. */
    fun fullEpg(acc: XtreamAccount, streamId: String): List<EpgEntry> {
        val root = JSONObject(api(acc, "get_simple_data_table&stream_id=$streamId"))
        val arr = root.optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<EpgEntry>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val start = o.optString("start_timestamp").toLongOrNull() ?: continue
            val end = o.optString("stop_timestamp").toLongOrNull() ?: continue
            out += EpgEntry(
                title = b64(o.optString("title")),
                desc = b64(o.optString("description")),
                start = start,
                end = end,
                hasArchive = o.optInt("has_archive", 0) == 1,
                startRaw = o.str("start")
            )
        }
        return out.sortedBy { it.start }
    }

    /** Adresse de lecture d'une émission passée. */
    fun replayUrl(acc: XtreamAccount, streamId: String, e: EpgEntry): String {
        val minutes = ((e.end - e.start) / 60).coerceAtLeast(1)
        // Format attendu par le serveur : 2026-01-01:20-00
        val start = e.startRaw?.takeIf { it.length >= 16 }?.let {
            it.substring(0, 10) + ":" + it.substring(11, 16).replace(':', '-')
        } ?: SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US).format(Date(e.start * 1000))
        return "${acc.server}/timeshift/${acc.user}/${acc.pass}/$minutes/$start/$streamId.ts"
    }

    // ---------- Mise à jour de l'appli ----------

    /** Numéro de la dernière version publiée sur GitHub (« Version 12 » -> 12). */
    fun latestVersion(owner: String, repo: String): Int? {
        val root = JSONObject(httpGet("https://api.github.com/repos/$owner/$repo/releases/latest"))
        return Regex("\\d+").find(root.optString("body"))?.value?.toIntOrNull()
    }
}
