package com.example.m3uplayer

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

// =====================================================================
// STYLE PREMIUM : plein écran cinéma
// =====================================================================

/** Un contenu mis en avant (film, série ou chaîne). */
private data class Spot(
    val key: String,
    val title: String,
    val tag: String,
    val meta: String,
    val plot: String?,
    val image: String?,
    val channel: Channel? = null,
    val movie: Movie? = null,
    val series: Series? = null,
    val progress: Float = 0f
)

/** Ce qu'affiche le fond (sans actions, pour des fondus fluides). */
private data class Backdrop(val title: String, val image: String?, val channel: Channel?)

private fun Spot.backdrop() = Backdrop(title, image, channel)

private fun movieSpot(m: Movie, prog: Float) = Spot(
    "movie:${m.id}", m.name, "FILM",
    listOfNotNull(m.category, m.rating?.let { "★ $it" }).joinToString("  ·  "),
    null, m.poster, movie = m, progress = prog
)

private fun seriesSpot(s: Series) = Spot(
    "series:${s.id}", s.name, "SÉRIE",
    listOfNotNull(s.category, s.rating?.let { "★ $it" }).joinToString("  ·  "),
    s.plot, s.cover, series = s
)

private fun liveSpot(c: Channel) = Spot("live:${c.url}", c.name, "EN DIRECT", c.group, null, c.logo, channel = c)

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PremiumLayout(vm: AppViewModel, tab: Tab, onTab: (Tab) -> Unit, nav: Nav) {
    val tabs = listOf(Tab.HOME, Tab.LIVE, Tab.GUIDE, Tab.MOVIES, Tab.SERIES, Tab.FAVS)
    val requesters = remember { Tab.entries.associateWith { FocusRequester() } }
    val onHome = tab == Tab.HOME && vm.hasSource

    LaunchedEffect(Unit) {
        if (!onHome) {
            delay(150)
            runCatching { requesters.getValue(tab).requestFocus() }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (onHome) {
            PremiumHome(vm, nav)
        } else {
            Column(Modifier.fillMaxSize().background(Bg)) {
                Spacer(Modifier.height(64.dp))
                Box(Modifier.weight(1f).fillMaxWidth()) { TabContent(vm, tab, nav) }
            }
        }

        // Barre du haut : transparente sur l'accueil
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(
                    if (onHome) Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent))
                    else Brush.verticalGradient(listOf(Bg, Bg))
                )
                .padding(horizontal = 32.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IrProIcon(36.dp)
            Spacer(Modifier.width(22.dp))
            Row(
                Modifier
                    .focusProperties { enter = { requesters.getValue(tab) } }
                    .focusGroup(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEach { t ->
                    TopTab(
                        if (t == Tab.FAVS) "Ma liste" else t.label,
                        selected = t == tab,
                        onClick = { onTab(t) },
                        modifier = Modifier.focusRequester(requesters.getValue(t))
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            TopIcon(Icons.Filled.Search, "Recherche", tab == Tab.SEARCH, Modifier.focusRequester(requesters.getValue(Tab.SEARCH))) { onTab(Tab.SEARCH) }
            Spacer(Modifier.width(6.dp))
            RefreshButton(vm, compact = true)
            Spacer(Modifier.width(6.dp))
            TopIcon(Icons.Filled.Settings, "Paramètres", tab == Tab.SETTINGS, Modifier.focusRequester(requesters.getValue(Tab.SETTINGS))) { onTab(Tab.SETTINGS) }
        }
    }
}

@Composable
private fun TopTab(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    FocusBox(onClick = onClick, focusScale = 1.06f, shape = RoundedCornerShape(20.dp), modifier = modifier) { f ->
        Column(Modifier.padding(horizontal = 14.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                color = if (f || selected) Color.White else Color(0xAAFFFFFF),
                fontSize = 16.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
            )
            if (selected && !f) {
                Box(Modifier.padding(top = 3.dp).width(20.dp).height(3.dp).background(PurpleMid, RoundedCornerShape(2.dp)))
            }
        }
    }
}

@Composable
private fun TopIcon(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusBox(onClick = onClick, focusScale = 1.1f, shape = RoundedCornerShape(20.dp), modifier = modifier) { f ->
        Icon(
            icon, contentDescription = label,
            tint = if (f || selected) Color.White else Color(0xAAFFFFFF),
            modifier = Modifier.padding(9.dp).size(24.dp)
        )
    }
}

@Composable
private fun PremiumHome(vm: AppViewModel, nav: Nav) {
    val prog = remember(vm.progressVersion) { vm.progressMap() }
    val resume = remember(vm.progressVersion) { vm.continueWatching() }
    val favorites = vm.favorites

    // Contenus mis en avant dans la grande bannière
    val spots = remember(vm.movies, vm.series, vm.channels, favorites, prog) {
        val movies = vm.movies.sortedByDescending { it.added }.take(5)
        val series = vm.series.sortedByDescending { it.added }.take(3)
        val live = vm.channels.firstOrNull { it.favKey in favorites } ?: vm.channels.firstOrNull()
        buildList {
            movies.getOrNull(0)?.let { add(movieSpot(it, prog[it.favKey] ?: 0f)) }
            live?.let { add(liveSpot(it)) }
            series.getOrNull(0)?.let { add(seriesSpot(it)) }
            movies.drop(1).forEach { add(movieSpot(it, prog[it.favKey] ?: 0f)) }
            series.drop(1).forEach { add(seriesSpot(it)) }
        }
    }
    val liveRow = remember(vm.channels, favorites) {
        vm.channels.filter { it.favKey in favorites }.take(25).ifEmpty { vm.channels.take(25) }
    }
    val recentMovies = remember(vm.movies, prog) { vm.movies.sortedByDescending { it.added }.take(30).map { movieSpot(it, prog[it.favKey] ?: 0f) } }
    val recentSeries = remember(vm.series) { vm.series.sortedByDescending { it.added }.take(30).map { seriesSpot(it) } }

    var heroIndex by remember { mutableIntStateOf(0) }
    var heroFocused by remember { mutableStateOf(true) }
    var focusedSpot by remember { mutableStateOf<Spot?>(null) }
    val plots = remember { mutableStateMapOf<String, String>() }

    // La bannière défile toute seule tant qu'on est dessus
    LaunchedEffect(heroFocused, spots.size) {
        while (heroFocused && spots.size > 1) {
            delay(6_500)
            heroIndex = (heroIndex + 1) % spots.size
        }
    }
    val heroSpot = spots.getOrNull(heroIndex % spots.size.coerceAtLeast(1))
    val shown = if (heroFocused) heroSpot else focusedSpot ?: heroSpot

    // Résumé du film affiché et guide de la chaîne affichée
    LaunchedEffect(shown?.key) {
        val s = shown ?: return@LaunchedEffect
        s.channel?.let { vm.loadEpg(it) }
        val m = s.movie
        if (m != null && plots[s.key] == null) {
            vm.movieInfo(m)?.plot?.let { plots[s.key] = it }
        }
    }

    fun play(s: Spot) {
        when {
            s.movie != null -> vm.playableOf(s.movie)?.let { nav.play(listOf(it), 0) }
            s.series != null -> nav.openSeries(s.series)
            s.channel != null -> {
                val group = vm.channels.filter { it.group == s.channel.group }
                nav.play(group.map { vm.playableOf(it) }, group.indexOf(s.channel).coerceAtLeast(0))
            }
        }
    }

    fun more(s: Spot) {
        when {
            s.movie != null -> nav.openMovie(s.movie)
            s.series != null -> nav.openSeries(s.series)
            s.channel != null -> vm.toggleFavorite(s.channel.favKey)
        }
    }

    val playFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200)
        runCatching { playFocus.requestFocus() }
    }

    Box(Modifier.fillMaxSize()) {
        PremiumBackground(shown?.backdrop())

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
            // ---------- Grande bannière ----------
            item {
                Column(
                    Modifier
                        .fillParentMaxHeight(0.66f)
                        .fillMaxWidth()
                        .onFocusChanged { heroFocused = it.hasFocus }
                        .padding(start = 56.dp, end = 56.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    if (shown != null) {
                        Crossfade(targetState = shown.key, animationSpec = tween(500), label = "hero") { key ->
                            val s = spots.firstOrNull { it.key == key } ?: recentMovies.firstOrNull { it.key == key }
                                ?: recentSeries.firstOrNull { it.key == key } ?: shown
                            Column(Modifier.fillMaxWidth(0.5f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (s.channel != null) {
                                        Box(Modifier.size(9.dp).background(LiveRed, RoundedCornerShape(5.dp)))
                                        Spacer(Modifier.width(8.dp))
                                    }
                                    Text(s.tag, color = PurpleLight, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    s.title, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold,
                                    lineHeight = 46.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(6.dp))
                                val (now, _) = vm.nowNext(s.channel)
                                Text(
                                    if (now != null) "${hhmm(now.start)} – ${hhmm(now.end)}  ·  ${now.title}" else s.meta,
                                    color = Color(0xFFDDDDDD), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                val plot = plots[s.key] ?: s.plot ?: now?.desc
                                if (!plot.isNullOrBlank()) {
                                    Spacer(Modifier.height(10.dp))
                                    Text(plot, color = Color(0xFFBBBBBB), fontSize = 14.sp, lineHeight = 20.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            HeroButton("Lecture", Icons.Filled.PlayArrow, primary = true, modifier = Modifier.focusRequester(playFocus)) { play(shown) }
                            val isFav = shown.channel?.let { it.favKey in favorites } ?: false
                            HeroButton(
                                when {
                                    shown.channel != null -> if (isFav) "Dans ma liste" else "Ma liste"
                                    else -> "Plus d'infos"
                                },
                                when {
                                    shown.channel != null -> if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder
                                    else -> Icons.Filled.Info
                                }
                            ) { more(shown) }
                            Spacer(Modifier.width(10.dp))
                            // Petits points : position dans la bannière
                            spots.forEachIndexed { i, _ ->
                                Box(
                                    Modifier
                                        .padding(horizontal = 3.dp)
                                        .width(if (i == heroIndex) 22.dp else 10.dp)
                                        .height(4.dp)
                                        .background(if (i == heroIndex) Color.White else Color(0x55FFFFFF), RoundedCornerShape(2.dp))
                                )
                            }
                        }
                    }
                }
            }

            // ---------- Rangées ----------
            if (spots.isNotEmpty()) {
                item {
                    PremiumRow("Tendances du moment", spots, onFocusSpot = { focusedSpot = it }, vm = vm) { i ->
                        val s = spots[i]
                        if (s.channel != null) play(s) else more(s)
                    }
                }
            }
            if (resume.isNotEmpty()) {
                item {
                    val items = resume.map { (p, f) -> Spot("res:${p.key}", p.title, "REPRENDRE", p.subtitle, null, p.image, progress = f) }
                    PremiumRow("Reprendre la lecture", items, onFocusSpot = { focusedSpot = it }, vm = vm) { i ->
                        nav.play(resume.map { it.first }, i)
                    }
                }
            }
            if (liveRow.isNotEmpty()) {
                item {
                    val items = liveRow.map { liveSpot(it) }
                    PremiumRow(
                        if (liveRow.any { it.favKey in favorites }) "Tes chaînes favorites" else "En direct maintenant",
                        items, onFocusSpot = { focusedSpot = it }, vm = vm
                    ) { i -> nav.play(liveRow.map { vm.playableOf(it) }, i) }
                }
            }
            if (recentMovies.isNotEmpty()) {
                item {
                    PremiumRow("Films ajoutés récemment", recentMovies, onFocusSpot = { focusedSpot = it }, vm = vm) { i ->
                        recentMovies[i].movie?.let { nav.openMovie(it) }
                    }
                }
            }
            if (recentSeries.isNotEmpty()) {
                item {
                    PremiumRow("Séries à découvrir", recentSeries, onFocusSpot = { focusedSpot = it }, vm = vm) { i ->
                        recentSeries[i].series?.let { nav.openSeries(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroButton(
    text: String,
    icon: ImageVector,
    primary: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by androidx.compose.animation.core.animateFloatAsState(if (focused) 1.08f else 1f, label = "btn")
    Row(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(30.dp))
            .background(
                when {
                    primary && focused -> Color.White
                    primary -> Color(0xEEFFFFFF)
                    focused -> PurpleMid
                    else -> Color(0x40FFFFFF)
                }
            )
            .border(3.dp, if (focused && !primary) Color.White else Color.Transparent, RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (primary) Color.Black else Color.White)
        Spacer(Modifier.width(8.dp))
        Text(text, color = if (primary) Color.Black else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Fond plein écran : image qui bouge lentement + lumière d'ambiance + voiles sombres. */
@Composable
private fun PremiumBackground(bd: Backdrop?) {
    val inf = rememberInfiniteTransition(label = "kenburns")
    val kb by inf.animateFloat(1f, 1.08f, infiniteRepeatable(tween(14_000), RepeatMode.Reverse), label = "kb")

    Crossfade(targetState = bd, animationSpec = tween(900), label = "bg", modifier = Modifier.fillMaxSize()) { b ->
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (b != null) {
                val ambient = colorFor(b.title)
                // Lumière d'ambiance de la couleur du contenu
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.radialGradient(listOf(ambient.copy(alpha = 0.9f), Color.Black)))
                )
                if (b.channel != null) {
                    Box(
                        Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 140.dp, bottom = 120.dp)
                            .graphicsLayer { scaleX = kb; scaleY = kb }
                    ) { ChannelLogo(b.channel, 220) }
                } else if (b.image != null) {
                    AsyncImage(
                        model = b.image,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .fillMaxWidth(0.66f)
                            .fillMaxHeight(0.8f)
                            .graphicsLayer { scaleX = kb; scaleY = kb }
                    )
                }
            }
            // Voiles : texte lisible à gauche et en bas
            Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(0f to Color.Black, 0.32f to Color(0xD9000000), 0.65f to Color.Transparent)
                )
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0.45f to Color.Transparent, 0.8f to Color(0xE6000000), 1f to Color.Black)
                )
            )
        }
    }
}

@Composable
private fun PremiumRow(
    title: String,
    items: List<Spot>,
    onFocusSpot: (Spot) -> Unit,
    vm: AppViewModel,
    onClick: (Int) -> Unit
) {
    Column(Modifier.padding(top = 14.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 56.dp, bottom = 4.dp))
        LazyRow(
            Modifier.height(190.dp),
            contentPadding = PaddingValues(horizontal = 52.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            itemsIndexed(items) { i, s ->
                PremiumCard(s, vm, onFocus = { onFocusSpot(s) }) { onClick(i) }
            }
        }
    }
}

/** Carte qui s'agrandit et montre ses infos quand on la sélectionne. */
@Composable
private fun PremiumCard(s: Spot, vm: AppViewModel, onFocus: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val w by animateDpAsState(if (focused) 300.dp else 230.dp, tween(260), label = "w")
    val h by animateDpAsState(if (focused) 170.dp else 130.dp, tween(260), label = "h")
    Box(
        Modifier
            .width(w)
            .height(h)
            .clip(RoundedCornerShape(14.dp))
            .border(3.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape(14.dp))
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) {
                    onFocus()
                    s.channel?.let { c -> vm.loadEpg(c) }
                }
            }
            .clickable(onClick = onClick)
    ) {
        if (s.channel != null) {
            Box(Modifier.fillMaxSize().background(colorFor(s.title)), contentAlignment = Alignment.Center) {
                ChannelLogo(s.channel, if (focused) 70 else 58)
            }
        } else {
            ArtImage(s.image, s.title, Modifier.fillMaxSize())
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.4f to Color.Transparent, 1f to Color(0xE6000000))
            )
        )
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(s.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (focused) {
                val (now, _) = vm.nowNext(s.channel)
                Text(
                    now?.title ?: s.meta, color = Color(0xFFDDDDDD), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (s.progress > 0f) {
                Spacer(Modifier.height(5.dp))
                ProgressLine(s.progress, Modifier.fillMaxWidth())
            }
        }
    }
}
