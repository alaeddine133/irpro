package com.example.m3uplayer

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================
// STYLE VERRE (façon iPhone) : icônes arrondies, panneaux translucides
// =====================================================================

/** Une icône d'appli : dégradé de deux couleurs + pictogramme. */
private class GlassApp(val label: String, val icon: ImageVector, val c1: Color, val c2: Color, val action: () -> Unit)

internal val GlassWhite = Color(0x1FFFFFFF)
internal val GlassBorder = Color(0x33FFFFFF)

/** Couleur du fond selon l'onglet (le dégradé change en douceur). */
private fun tabTint(tab: Tab): Color = when (tab) {
    Tab.HOME -> Color(0xFF0C447C)
    Tab.LIVE -> Color(0xFF085041)
    Tab.GUIDE -> Color(0xFF04342C)
    Tab.MOVIES -> Color(0xFF26215C)
    Tab.SERIES -> Color(0xFF712B13)
    Tab.SEARCH -> Color(0xFF2C2C2A)
    Tab.FAVS -> Color(0xFF72243E)
    Tab.SETTINGS -> Color(0xFF2C2C2A)
}

/** Fond animé : grandes taches de couleur douces qui bougent lentement. */
@Composable
fun GlassBackdrop(tint: Color, modifier: Modifier = Modifier) {
    val color by animateColorAsState(tint, tween(900), label = "tint")
    val inf = rememberInfiniteTransition(label = "blobs")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(16_000), RepeatMode.Reverse), label = "t")
    Canvas(modifier.fillMaxSize().background(Color(0xFF05070D))) {
        val w = size.width
        val h = size.height
        fun blob(c: Color, x: Float, y: Float, r: Float) = drawCircle(
            Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(x, y), radius = r),
            radius = r, center = Offset(x, y)
        )
        blob(color.copy(alpha = 0.95f), w * (0.72f + 0.08f * t), h * (0.25f + 0.1f * t), w * 0.55f)
        blob(LogoPurple.copy(alpha = 0.55f), w * (0.15f + 0.1f * t), h * (0.85f - 0.1f * t), w * 0.45f)
        blob(Color(0xFF1D9E75).copy(alpha = 0.25f), w * (0.4f - 0.1f * t), h * (0.1f + 0.15f * t), w * 0.35f)
    }
}

/** Icône arrondie qui se soulève quand on la sélectionne. */
@Composable
private fun GlassAppIcon(app: GlassApp, size: Int, modifier: Modifier = Modifier, showLabel: Boolean = true) {
    var focused by remember { mutableStateOf(false) }
    val lift by animateFloatAsState(if (focused) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "lift")
    Column(
        modifier
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = app.action),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .graphicsLayer {
                    val sc = 1f + 0.15f * lift
                    scaleX = sc
                    scaleY = sc
                    translationY = -10f * lift * density
                    shadowElevation = 18f * lift * density
                    shape = RoundedCornerShape((size * 0.24f).dp)
                    clip = true
                }
                .size(size.dp)
                .background(Brush.linearGradient(listOf(app.c1, app.c2)))
                .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape((size * 0.24f).dp)),
            contentAlignment = Alignment.Center
        ) {
            // Reflet brillant en haut de l'icône
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0f to Color(0x55FFFFFF), 0.45f to Color.Transparent)
                )
            )
            Icon(app.icon, contentDescription = app.label, tint = Color.White, modifier = Modifier.size((size * 0.46f).dp))
        }
        if (showLabel) {
            Spacer(Modifier.height(8.dp))
            Text(
                app.label,
                color = if (focused) Color.White else Color(0xCCFFFFFF),
                fontSize = 13.sp,
                fontWeight = if (focused) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
            )
        }
    }
}

/** Pilule de la barre du haut. */
@Composable
private fun GlassPill(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                when {
                    focused -> Color.White
                    selected -> Color(0x40FFFFFF)
                    else -> Color.Transparent
                }
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp)
    ) {
        Text(
            text,
            color = if (focused) Color.Black else Color.White,
            fontSize = 15.sp,
            fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

/** Bouton Actualiser bien visible, avec l'heure de la dernière mise à jour. */
@Composable
private fun GlassRefresh(vm: AppViewModel) {
    var focused by remember { mutableStateOf(false) }
    val label = when {
        vm.loading -> "Mise à jour…"
        vm.lastUpdate > 0 -> "Actualiser · " + SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(vm.lastUpdate))
        else -> "Actualiser"
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (focused) Color.White else Color(0x26FFFFFF))
            .onFocusChanged { focused = it.isFocused }
            .clickable { if (!vm.loading) vm.refresh() }
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Refresh, null, tint = if (focused) Color.Black else Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = if (focused) Color.Black else Color.White, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable
private fun GlassIconButton(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                when {
                    focused -> Color.White
                    selected -> Color(0x40FFFFFF)
                    else -> Color.Transparent
                }
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Icon(icon, label, tint = if (focused) Color.Black else Color.White, modifier = Modifier.size(20.dp))
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun GlassLayout(vm: AppViewModel, tab: Tab, onTab: (Tab) -> Unit, nav: Nav) {
    val tabs = listOf(Tab.HOME, Tab.LIVE, Tab.MOVIES, Tab.SERIES, Tab.GUIDE, Tab.FAVS)
    val requesters = remember { Tab.entries.associateWith { FocusRequester() } }
    val onHome = tab == Tab.HOME && vm.hasSource

    LaunchedEffect(Unit) {
        if (!onHome) {
            delay(150)
            runCatching { requesters.getValue(tab).requestFocus() }
        }
    }

    Box(Modifier.fillMaxSize()) {
        GlassBackdrop(tabTint(tab))

        Column(Modifier.fillMaxSize()) {
            // ---------- Barre du haut en verre ----------
            Box(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(28.dp))
                        .background(GlassWhite)
                        .border(1.dp, GlassBorder, RoundedCornerShape(28.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .focusProperties { enter = { requesters.getValue(tab) } }
                        .focusGroup(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IrProIcon(28.dp)
                    Spacer(Modifier.width(6.dp))
                    tabs.forEach { t ->
                        GlassPill(
                            if (t == Tab.FAVS) "Ma liste" else t.label,
                            selected = t == tab,
                            onClick = { onTab(t) },
                            modifier = Modifier.focusRequester(requesters.getValue(t))
                        )
                    }
                    GlassIconButton(Icons.Filled.Search, "Recherche", tab == Tab.SEARCH, Modifier.focusRequester(requesters.getValue(Tab.SEARCH))) { onTab(Tab.SEARCH) }
                    GlassRefresh(vm)
                    GlassIconButton(Icons.Filled.Settings, "Paramètres", tab == Tab.SETTINGS, Modifier.focusRequester(requesters.getValue(Tab.SETTINGS))) { onTab(Tab.SETTINGS) }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    onHome -> GlassHome(vm, onTab, nav)
                    vm.hasSource && tab == Tab.LIVE -> GlassLiveScreen(vm, nav)
                    vm.hasSource && tab == Tab.MOVIES -> GlassMoviesScreen(vm, nav)
                    vm.hasSource && tab == Tab.SERIES -> GlassSeriesScreen(vm, nav)
                    else -> TabContent(vm, tab, nav)
                }
            }
        }
    }
}

@Composable
private fun GlassHome(vm: AppViewModel, onTab: (Tab) -> Unit, nav: Nav) {
    val favorites = vm.favorites
    val movie = remember(vm.movies) { vm.movies.maxByOrNull { it.added } }
    val series = remember(vm.series) { vm.series.maxByOrNull { it.added } }
    val live = remember(vm.channels, favorites) { vm.channels.firstOrNull { it.favKey in favorites } ?: vm.channels.firstOrNull() }
    LaunchedEffect(live) { vm.loadEpg(live) }
    var plot by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(movie) { plot = movie?.let { vm.movieInfo(it)?.plot } }

    val apps = listOf(
        GlassApp("TV en direct", Tab.LIVE.icon, Color(0xFFE24B4A), Color(0xFFA32D2D)) { onTab(Tab.LIVE) },
        GlassApp("Films", Tab.MOVIES.icon, Color(0xFF378ADD), Color(0xFF0C447C)) { onTab(Tab.MOVIES) },
        GlassApp("Séries", Tab.SERIES.icon, Color(0xFF7F77DD), Color(0xFF3C3489)) { onTab(Tab.SERIES) },
        GlassApp("Guide TV", Tab.GUIDE.icon, Color(0xFF1D9E75), Color(0xFF085041)) { onTab(Tab.GUIDE) },
        GlassApp("Favoris", Tab.FAVS.icon, Color(0xFFD4537E), Color(0xFF72243E)) { onTab(Tab.FAVS) },
        GlassApp("Recherche", Tab.SEARCH.icon, Color(0xFF888780), Color(0xFF444441)) { onTab(Tab.SEARCH) },
        GlassApp("Actualiser", Icons.Filled.Refresh, Color(0xFFEF9F27), Color(0xFF854F0B)) { if (!vm.loading) vm.refresh() },
        GlassApp("Réglages", Tab.SETTINGS.icon, Color(0xFF5F5E5A), Color(0xFF2C2C2A)) { onTab(Tab.SETTINGS) }
    )
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200)
        runCatching { playFocus.requestFocus() }
    }

    Box(Modifier.fillMaxSize()) {
        // Affiche du film mis en avant, fondue sur la droite
        movie?.poster?.let { url ->
            AsyncImage(
                model = url, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .fillMaxWidth(0.42f)
                    .fillMaxHeight(0.62f)
                    .padding(end = 40.dp, top = 6.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .graphicsLayer { alpha = 0.9f }
            )
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 44.dp)) {
            // ---------- À la une ----------
            Column(Modifier.fillMaxWidth(0.52f).weight(1f), verticalArrangement = Arrangement.Center) {
                if (movie != null) {
                    Text("À LA UNE", color = Color(0xFF85B7EB), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text(movie.name, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        listOfNotNull(movie.category, movie.rating?.let { "★ $it" }).joinToString("  ·  "),
                        color = Color(0xCCFFFFFF), fontSize = 14.sp
                    )
                    plot?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, color = Color(0xAAFFFFFF), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        GlassButton("Lecture", Icons.Filled.PlayArrow, primary = true, modifier = Modifier.focusRequester(playFocus)) {
                            vm.playableOf(movie)?.let { nav.play(listOf(it), 0) }
                        }
                        GlassButton("Plus d'infos", Icons.Filled.Info) { nav.openMovie(movie) }
                    }
                } else if (live != null) {
                    LiveWidget(vm, live, Modifier.focusRequester(playFocus)) {
                        val group = vm.channels.filter { it.group == live.group }
                        nav.play(group.map { vm.playableOf(it) }, group.indexOf(live).coerceAtLeast(0))
                    }
                }
                if (movie != null && live != null) {
                    Spacer(Modifier.height(16.dp))
                    LiveWidget(vm, live) {
                        val group = vm.channels.filter { it.group == live.group }
                        nav.play(group.map { vm.playableOf(it) }, group.indexOf(live).coerceAtLeast(0))
                    }
                }
                if (movie == null && live == null && series != null) {
                    GlassButton(series.name, Icons.Filled.PlayArrow, primary = true, modifier = Modifier.focusRequester(playFocus)) { nav.openSeries(series) }
                }
            }

            // ---------- Dock d'icônes en verre ----------
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 22.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(GlassWhite)
                    .border(1.dp, GlassBorder, RoundedCornerShape(30.dp))
                    .padding(top = 22.dp, bottom = 14.dp, start = 10.dp, end = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                apps.forEach { a -> GlassAppIcon(a, 64) }
            }
        }
    }
}

@Composable
internal fun GlassButton(text: String, icon: ImageVector, primary: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (focused) 1.08f else 1f, label = "gb")
    Row(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(26.dp))
            .background(
                when {
                    primary || focused -> Color.White
                    else -> Color(0x33FFFFFF)
                }
            )
            .border(if (focused) 3.dp else 0.dp, if (focused) LogoPurpleLight else Color.Transparent, RoundedCornerShape(26.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val fg = if (primary || focused) Color.Black else Color.White
        Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Petit widget « en direct » en verre. */
@Composable
private fun LiveWidget(vm: AppViewModel, c: Channel, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val (now, _) = vm.nowNext(c)
    val nowSec = System.currentTimeMillis() / 1000
    Row(
        modifier
            .width(380.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (focused) Color(0x55FFFFFF) else GlassWhite)
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else GlassBorder, RoundedCornerShape(22.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ChannelLogo(c, 48)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(LiveRed, RoundedCornerShape(4.dp)))
                Spacer(Modifier.width(6.dp))
                Text("EN DIRECT · ${c.name}", color = Color(0xCCFFFFFF), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(now?.title ?: c.group, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Spacer(Modifier.height(5.dp))
                ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(), Color.White)
            }
        }
        Spacer(Modifier.width(10.dp))
        Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
    }
}

// =====================================================================
// INTRO DU STYLE VERRE
// =====================================================================

/**
 * Taches de couleur qui apparaissent, logo en verre qui rebondit avec un reflet,
 * icônes colorées qui jaillissent, nom IR PRO, puis fondu vers l'accueil.
 */
@Composable
fun GlassIntro(onDone: () -> Unit) {
    val bg = remember { Animatable(0f) }
    val logo = remember { Animatable(0f) }
    val shine = remember { Animatable(-1f) }
    val icons = remember { List(6) { Animatable(0f) } }
    val word = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }
    val colors = listOf(
        Color(0xFFE24B4A) to Color(0xFFA32D2D),
        Color(0xFF378ADD) to Color(0xFF0C447C),
        Color(0xFF7F77DD) to Color(0xFF3C3489),
        Color(0xFF1D9E75) to Color(0xFF085041),
        Color(0xFFEF9F27) to Color(0xFF854F0B),
        Color(0xFFD4537E) to Color(0xFF72243E)
    )
    val glyphs = listOf(Tab.LIVE.icon, Tab.MOVIES.icon, Tab.SERIES.icon, Tab.GUIDE.icon, Icons.Filled.Refresh, Tab.FAVS.icon)

    LaunchedEffect(Unit) {
        launch { bg.animateTo(1f, tween(1200)) }
        delay(250)
        launch { logo.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 180f)) }
        delay(700)
        launch { shine.animateTo(1.6f, tween(900, easing = FastOutSlowInEasing)) }
        delay(250)
        icons.forEachIndexed { i, a ->
            launch {
                delay(i * 90L)
                a.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 220f))
            }
        }
        delay(450)
        word.animateTo(1f, tween(600))
        delay(1100)
        exit.animateTo(1f, tween(650, easing = FastOutLinearInEasing))
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF05070D))
            .graphicsLayer { alpha = 1f - exit.value },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = bg.value }) {
            GlassBackdrop(Color(0xFF0C447C))
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                val s = 1f + 0.12f * exit.value
                scaleX = s
                scaleY = s
            }
        ) {
            // Logo dans une tuile de verre, avec un reflet qui passe
            Box(
                Modifier
                    .graphicsLayer {
                        scaleX = 0.4f + 0.6f * logo.value
                        scaleY = 0.4f + 0.6f * logo.value
                        alpha = logo.value.coerceIn(0f, 1f)
                    }
                    .size(150.dp)
                    .clip(RoundedCornerShape(38.dp))
                    .background(Color(0x26FFFFFF))
                    .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(38.dp)),
                contentAlignment = Alignment.Center
            ) {
                IrProIcon(110.dp)
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { translationX = shine.value * 150f * density }
                        .background(
                            Brush.horizontalGradient(
                                0.35f to Color.Transparent, 0.5f to Color(0x66FFFFFF), 0.65f to Color.Transparent
                            )
                        )
                )
            }
            Spacer(Modifier.height(30.dp))
            // Les icônes jaillissent l'une après l'autre
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                icons.forEachIndexed { i, a ->
                    Box(
                        Modifier
                            .graphicsLayer {
                                val v = a.value
                                scaleX = 0.3f + 0.7f * v
                                scaleY = 0.3f + 0.7f * v
                                alpha = v.coerceIn(0f, 1f)
                                translationY = (1f - v) * -60f * density
                            }
                            .size(52.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(Brush.linearGradient(listOf(colors[i].first, colors[i].second))),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x55FFFFFF), 0.45f to Color.Transparent)))
                        Icon(glyphs[i], null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
            Spacer(Modifier.height(26.dp))
            Text(
                "IR PRO",
                color = Color.White.copy(alpha = word.value),
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (6f + 10f * (1f - word.value)).sp,
                modifier = Modifier.offset(y = (12f * (1f - word.value)).dp)
            )
        }
    }
}
