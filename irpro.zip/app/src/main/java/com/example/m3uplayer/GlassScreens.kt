package com.example.m3uplayer

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.foundation.lazy.grid.items as gridItems

// =====================================================================
// ÉCRANS DU STYLE VERRE : Direct, Films, Séries
// =====================================================================

private val GlassShape = RoundedCornerShape(22.dp)

/** Panneau en verre arrondi. */
private fun Modifier.glassPanel(): Modifier =
    this.clip(GlassShape).background(GlassWhite).border(1.dp, GlassBorder, GlassShape)

/** Ligne de liste en verre (bouquets, catégories). */
@Composable
private fun GlassListItem(text: String, selected: Boolean, onClick: () -> Unit, onFocused: () -> Unit = {}) {
    var focused by remember { mutableStateOf(false) }
    Text(
        text,
        color = if (focused) Color.Black else Color.White,
        fontSize = 15.sp,
        fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                when {
                    focused -> Color.White
                    selected -> Color(0x40FFFFFF)
                    else -> Color.Transparent
                }
            )
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

/** Pilule de catégorie / tri. */
@Composable
private fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(
        text,
        color = if (focused || selected) Color.Black else Color.White,
        fontSize = 13.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                when {
                    focused -> Color.White
                    selected -> Color(0xE6FFFFFF)
                    else -> Color.Transparent
                }
            )
            .border(if (focused) 2.dp else 0.dp, if (focused) LogoPurpleLight else Color.Transparent, RoundedCornerShape(18.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}

// ---------------------------------------------------------------------
// DIRECT
// ---------------------------------------------------------------------

@Composable
fun GlassLiveScreen(vm: AppViewModel, nav: Nav) {
    val channels = vm.channels
    val favorites = vm.favorites
    val groups = remember(channels) { listOf("Toutes les chaînes", "Favoris") + channels.map { it.group }.distinct() }
    var group by rememberSaveable { mutableStateOf("Toutes les chaînes") }
    val list = remember(channels, group, favorites) {
        when (group) {
            "Toutes les chaînes" -> channels
            "Favoris" -> channels.filter { it.favKey in favorites }
            else -> channels.filter { it.group == group }
        }
    }
    var focused by remember { mutableStateOf<Channel?>(null) }
    val preview = focused ?: list.firstOrNull()
    LaunchedEffect(preview) { vm.loadEpg(preview) }

    Row(
        Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, top = 6.dp, bottom = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Bouquets
        LazyColumn(
            Modifier.width(210.dp).fillMaxHeight().glassPanel(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(groups) { g ->
                GlassListItem(g, selected = g == group, onClick = { group = g }, onFocused = { group = g })
            }
        }

        // Chaînes en cartes de verre
        LazyColumn(
            Modifier.weight(1f).fillMaxHeight(),
            contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (list.isEmpty()) {
                item {
                    Text(
                        if (group == "Favoris") "Aucune chaîne favorite. Ajoute-les avec « Ma liste » dans la fiche à droite."
                        else "Aucune chaîne ici.",
                        color = Color(0xCCFFFFFF), fontSize = 15.sp, modifier = Modifier.padding(16.dp)
                    )
                }
            }
            itemsIndexed(list) { i, c ->
                GlassChannelCard(vm, i + 1, c, onFocus = { focused = c }) {
                    nav.play(list.map { vm.playableOf(it) }, i)
                }
            }
        }

        // Fiche de la chaîne
        GlassChannelInfo(vm, preview, nav, list, Modifier.width(300.dp).fillMaxHeight())
    }
}

@Composable
private fun GlassChannelCard(vm: AppViewModel, number: Int, c: Channel, onFocus: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (focused) 1.03f else 1f, label = "card")
    val (now, _) = vm.nowNext(c)
    val nowSec = System.currentTimeMillis() / 1000
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(20.dp))
            .background(if (focused) Color(0x4DFFFFFF) else GlassWhite)
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else GlassBorder, RoundedCornerShape(20.dp))
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) {
                    onFocus()
                    vm.loadEpg(c)
                }
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$number", color = Color(0xAAFFFFFF), fontSize = 13.sp, modifier = Modifier.width(34.dp))
        ChannelLogo(c, 46)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                now?.title ?: c.group, color = Color(0xCCFFFFFF), fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (now != null) {
                Spacer(Modifier.height(4.dp))
                ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.8f), Color.White)
            }
        }
        if (c.favKey in vm.favorites) {
            Text("♥", color = FavPink, fontSize = 16.sp)
        }
    }
}

@Composable
private fun GlassChannelInfo(vm: AppViewModel, c: Channel?, nav: Nav, list: List<Channel>, modifier: Modifier) {
    Column(modifier.glassPanel().verticalScroll(rememberScrollState()).padding(18.dp)) {
        if (c == null) return@Column
        ChannelLogo(c, 66)
        Spacer(Modifier.height(10.dp))
        Text(c.name, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(c.group, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1)
        Spacer(Modifier.height(14.dp))
        val epg = c.streamId?.let { vm.epg[it] }
        val nowSec = System.currentTimeMillis() / 1000
        val (now, next) = vm.nowNext(c)
        when {
            vm.account == null -> Text("Guide TV disponible avec un compte Xtream.", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            epg == null -> Text("Chargement du guide TV…", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            now == null && next == null -> Text("Pas de guide TV pour cette chaîne.", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            else -> {
                now?.let {
                    Text("MAINTENANT · ${hhmm(it.start)} – ${hhmm(it.end)}", color = Color(0xFF9FE1CB), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(it.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(5.dp))
                    ProgressLine(it.progress(nowSec), Modifier.fillMaxWidth(), Color.White)
                    if (it.desc.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(it.desc, color = Color(0xCCFFFFFF), fontSize = 11.sp, lineHeight = 15.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    }
                }
                next?.let {
                    Spacer(Modifier.height(10.dp))
                    Text("ENSUITE · ${hhmm(it.start)}", color = Color(0xAAFFFFFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(it.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        GlassButton("Regarder", Icons.Filled.PlayArrow, primary = true) {
            nav.play(list.map { vm.playableOf(it) }, list.indexOf(c).coerceAtLeast(0))
        }
        if (c.archiveDays > 0 && vm.account != null) {
            Spacer(Modifier.height(8.dp))
            GlassButton("Replay · ${c.archiveDays} j", Icons.Filled.Replay) { nav.openReplay(c) }
        }
        Spacer(Modifier.height(8.dp))
        val fav = c.favKey in vm.favorites
        GlassButton(if (fav) "Dans ma liste" else "Ma liste", if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder) {
            vm.toggleFavorite(c.favKey)
        }
    }
}

// ---------------------------------------------------------------------
// FILMS ET SÉRIES
// ---------------------------------------------------------------------

/** Ce qu'il faut savoir d'une affiche pour l'écran en verre. */
private class PosterInfo(
    val key: String,
    val title: String,
    val image: String?,
    val category: String,
    val rating: String?,
    val added: Long,
    val plot: String?,
    val progress: Float
)

@Composable
fun GlassMoviesScreen(vm: AppViewModel, nav: Nav) {
    val prog = remember(vm.progressVersion) { vm.progressMap() }
    val byKey = remember(vm.movies) { vm.movies.associateBy { it.favKey } }
    val infos = remember(vm.movies, prog) {
        vm.movies.map { PosterInfo(it.favKey, it.name, it.poster, it.category, it.rating, it.added, null, prog[it.favKey] ?: 0f) }
    }
    val plots = remember { mutableStateMapOf<String, String>() }
    GlassPosterScreen(
        items = infos,
        emptyText = "Aucun film disponible avec cette source.",
        loadPlot = { key ->
            if (plots[key] == null) byKey[key]?.let { m -> vm.movieInfo(m)?.plot?.let { plots[key] = it } }
        },
        plotOf = { plots[it.key] },
        onOpen = { p -> byKey[p.key]?.let { nav.openMovie(it) } }
    )
}

@Composable
fun GlassSeriesScreen(vm: AppViewModel, nav: Nav) {
    val byKey = remember(vm.series) { vm.series.associateBy { it.favKey } }
    val infos = remember(vm.series) {
        vm.series.map { PosterInfo(it.favKey, it.name, it.cover, it.category, it.rating, it.added, it.plot, 0f) }
    }
    GlassPosterScreen(
        items = infos,
        emptyText = "Aucune série disponible avec cette source.",
        loadPlot = {},
        plotOf = { it.plot },
        onOpen = { p -> byKey[p.key]?.let { nav.openSeries(it) } }
    )
}

@Composable
private fun GlassPosterScreen(
    items: List<PosterInfo>,
    emptyText: String,
    loadPlot: suspend (String) -> Unit,
    plotOf: (PosterInfo) -> String?,
    onOpen: (PosterInfo) -> Unit
) {
    if (items.isEmpty()) {
        EmptyMessage(emptyText)
        return
    }
    val cats = remember(items) { listOf("Tout") + items.map { it.category }.distinct() }
    var cat by rememberSaveable { mutableStateOf("Tout") }
    var sort by rememberSaveable { mutableStateOf("Par défaut") }
    val list = remember(items, cat, sort) {
        val base = if (cat == "Tout") items else items.filter { it.category == cat }
        when (sort) {
            "A → Z" -> base.sortedBy { it.title.lowercase() }
            "Récents" -> base.sortedByDescending { it.added }
            "Mieux notés" -> base.sortedByDescending { it.rating?.toDoubleOrNull() ?: 0.0 }
            else -> base
        }
    }
    var focused by remember { mutableStateOf<PosterInfo?>(null) }
    val shown = focused ?: list.firstOrNull()

    // Résumé chargé quand on reste un instant sur une affiche
    LaunchedEffect(shown?.key) {
        val k = shown?.key ?: return@LaunchedEffect
        delay(350)
        loadPlot(k)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        // Catégories dans une pilule en verre
        Box(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
            LazyRow(
                Modifier.glassPanel(),
                contentPadding = PaddingValues(5.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(cats) { c -> GlassChip(c, c == cat) { cat = c } }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${list.size} titre(s)  ·  Trier :", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            listOf("Par défaut", "A → Z", "Récents", "Mieux notés").forEach { o -> GlassChip(o, o == sort) { sort = o } }
        }

        // Affiches arrondies
        LazyVerticalGrid(
            columns = GridCells.Adaptive(128.dp),
            contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 10.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            gridItems(list) { p ->
                GlassPoster(p, onFocus = { focused = p }) { onOpen(p) }
            }
        }

        // Aperçu de l'affiche sélectionnée
        if (shown != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp, top = 4.dp)
                    .glassPanel()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(shown.image, shown.title, Modifier.width(44.dp).height(64.dp).clip(RoundedCornerShape(10.dp)))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(shown.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        listOfNotNull(shown.category, shown.rating?.let { "★ $it" }).joinToString("  ·  "),
                        color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1
                    )
                    plotOf(shown)?.let {
                        Text(it, color = Color(0xAAFFFFFF), fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Text("OK : ouvrir la fiche", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun GlassPoster(p: PosterInfo, onFocus: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (focused) 1.1f else 1f, label = "poster")
    Column(
        Modifier
            .graphicsLayer {
                scaleX = sc
                scaleY = sc
                translationY = if (focused) -6f * density else 0f
                shadowElevation = if (focused) 16f * density else 0f
                shape = RoundedCornerShape(16.dp)
            }
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocus()
            }
            .clickable(onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .clip(RoundedCornerShape(16.dp))
                .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape(16.dp))
        ) {
            ArtImage(p.image, p.title, Modifier.fillMaxSize())
            // Reflet en haut de l'affiche
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x40FFFFFF), 0.35f to Color.Transparent)))
            p.rating?.let {
                Text(
                    "★ $it", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .background(Color(0x99000000), RoundedCornerShape(10.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            if (p.progress > 0f) ProgressLine(p.progress, Modifier.align(Alignment.BottomCenter).fillMaxWidth(), Color.White)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            p.title, color = if (focused) Color.White else Color(0xCCFFFFFF), fontSize = 13.sp,
            fontWeight = if (focused) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}
