package com.example.m3uplayer

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("m3u", Context.MODE_PRIVATE)
    private val dir = app.filesDir

    // Listes complètes (avant filtre parental)
    private var allChannels: List<Channel> = emptyList()
    private var allMovies: List<Movie> = emptyList()
    private var allSeries: List<Series> = emptyList()

    // Listes affichées
    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var movies by mutableStateOf<List<Movie>>(emptyList())
        private set
    var series by mutableStateOf<List<Series>>(emptyList())
        private set

    var loading by mutableStateOf(false)
        private set
    var errorMsg by mutableStateOf<String?>(null)
        private set
    var expiry by mutableStateOf(prefs.getString("expiry", null))
        private set
    var favorites by mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
        private set
    var hideAdult by mutableStateOf(prefs.getBoolean("hideAdult", true))
        private set

    /** Augmente à chaque sauvegarde de progression : sert à rafraîchir « Reprendre ». */
    var progressVersion by mutableIntStateOf(0)
        private set

    /** Guide TV par stream_id */
    val epg = mutableStateMapOf<String, List<EpgEntry>>()
    private val epgLoading = HashSet<String>()

    val mode: String get() = prefs.getString("mode", "xtream") ?: "xtream"
    val lastUrl: String get() = prefs.getString("url", "") ?: ""
    val savedServer: String get() = prefs.getString("xs", "") ?: ""
    val savedUser: String get() = prefs.getString("xu", "") ?: ""
    val savedPass: String get() = prefs.getString("xp", "") ?: ""

    val account: XtreamAccount?
        get() = if (mode == "xtream" && savedServer.isNotBlank()) XtreamAccount(savedServer, savedUser, savedPass) else null

    val hasSource: Boolean get() = channels.isNotEmpty() || movies.isNotEmpty() || series.isNotEmpty()

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { loadFromCache() }
            applyFilter()
            account?.let { refreshXtream(it) }
        }
    }

    // ---------- Chargement ----------

    private fun file(name: String) = File(dir, name)
    private fun readOr(name: String) = file(name).takeIf { it.exists() }?.readText() ?: ""

    private fun loadFromCache() {
        val acc = account
        if (acc != null) {
            if (file("live.json").exists()) allChannels = XtreamClient.parseLive(acc, readOr("live_cats.json"), readOr("live.json"))
            if (file("vod.json").exists()) allMovies = XtreamClient.parseMovies(readOr("vod_cats.json"), readOr("vod.json"))
            if (file("ser.json").exists()) allSeries = XtreamClient.parseSeries(readOr("ser_cats.json"), readOr("ser.json"))
        } else if (file("playlist.m3u").exists()) {
            allChannels = M3uParser.parse(readOr("playlist.m3u"))
        }
    }

    private fun applyFilter() {
        if (hideAdult) {
            channels = allChannels.filterNot { isAdult(it.group) || isAdult(it.name) }
            movies = allMovies.filterNot { isAdult(it.category) }
            series = allSeries.filterNot { isAdult(it.category) }
        } else {
            channels = allChannels
            movies = allMovies
            series = allSeries
        }
    }

    private val adultRegex = Regex("""(adult|xxx|porn|\+18|18\+|for adults|erotic)""", RegexOption.IGNORE_CASE)
    private fun isAdult(s: String) = adultRegex.containsMatchIn(s)

    fun refresh() {
        val acc = account
        if (acc != null) refreshXtream(acc) else if (lastUrl.isNotBlank()) loadUrl(lastUrl)
    }

    private fun refreshXtream(acc: XtreamAccount) {
        viewModelScope.launch {
            loading = true
            errorMsg = null
            try {
                val info = withContext(Dispatchers.IO) {
                    val info = XtreamClient.login(acc)
                    val liveCats = XtreamClient.api(acc, "get_live_categories")
                    val live = XtreamClient.api(acc, "get_live_streams")
                    file("live_cats.json").writeText(liveCats)
                    file("live.json").writeText(live)
                    allChannels = XtreamClient.parseLive(acc, liveCats, live)
                    // Films et séries : facultatifs selon le fournisseur
                    runCatching {
                        val c = XtreamClient.api(acc, "get_vod_categories")
                        val v = XtreamClient.api(acc, "get_vod_streams")
                        file("vod_cats.json").writeText(c)
                        file("vod.json").writeText(v)
                        allMovies = XtreamClient.parseMovies(c, v)
                    }
                    runCatching {
                        val c = XtreamClient.api(acc, "get_series_categories")
                        val s = XtreamClient.api(acc, "get_series")
                        file("ser_cats.json").writeText(c)
                        file("ser.json").writeText(s)
                        allSeries = XtreamClient.parseSeries(c, s)
                    }
                    info
                }
                expiry = info.expiry
                prefs.edit().putString("expiry", info.expiry).apply()
                epg.clear()
                applyFilter()
            } catch (e: Exception) {
                errorMsg = e.message ?: "Erreur de chargement"
            } finally {
                loading = false
            }
        }
    }

    fun loadXtream(server: String, user: String, pass: String) {
        val acc = XtreamAccount(XtreamClient.normalizeServer(server), user.trim(), pass.trim())
        prefs.edit()
            .putString("mode", "xtream")
            .putString("xs", acc.server)
            .putString("xu", acc.user)
            .putString("xp", acc.pass)
            .apply()
        refreshXtream(acc)
    }

    fun loadUrl(url: String) {
        prefs.edit().putString("mode", "m3u").putString("url", url).apply()
        loadM3u { XtreamClient.httpGet(url) }
    }

    fun loadFile(uri: Uri) {
        prefs.edit().putString("mode", "m3u").apply()
        loadM3u {
            getApplication<Application>().contentResolver.openInputStream(uri)
                ?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("Impossible de lire ce fichier")
        }
    }

    private fun loadM3u(fetch: () -> String) {
        viewModelScope.launch {
            loading = true
            errorMsg = null
            try {
                val list = withContext(Dispatchers.IO) {
                    val text = fetch()
                    val parsed = M3uParser.parse(text)
                    if (parsed.isEmpty()) throw IllegalStateException("Aucune chaîne trouvée")
                    file("playlist.m3u").writeText(text)
                    parsed
                }
                allChannels = list
                allMovies = emptyList()
                allSeries = emptyList()
                expiry = null
                prefs.edit().remove("expiry").apply()
                applyFilter()
            } catch (e: Exception) {
                errorMsg = e.message ?: "Erreur de chargement"
            } finally {
                loading = false
            }
        }
    }

    // ---------- Infos détaillées ----------

    suspend fun movieInfo(m: Movie): MovieInfo? {
        val acc = account ?: return null
        return withContext(Dispatchers.IO) { runCatching { XtreamClient.movieInfo(acc, m.id) }.getOrNull() }
    }

    suspend fun seriesInfo(s: Series): SeriesInfo? {
        val acc = account ?: return null
        return withContext(Dispatchers.IO) { runCatching { XtreamClient.seriesInfo(acc, s.id) }.getOrNull() }
    }

    fun loadEpg(c: Channel?) {
        val acc = account ?: return
        val id = c?.streamId ?: return
        val cached = epg[id]
        val now = System.currentTimeMillis() / 1000
        // Déjà en mémoire et encore à jour
        if (cached != null && (cached.isEmpty() || cached.last().end > now)) return
        if (!epgLoading.add(id)) return
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { XtreamClient.shortEpg(acc, id) }.getOrDefault(emptyList())
            }
            epg[id] = list.filter { it.end > now }
            epgLoading.remove(id)
        }
    }

    fun nowNext(c: Channel?): Pair<EpgEntry?, EpgEntry?> {
        val list = c?.streamId?.let { epg[it] } ?: return null to null
        val now = System.currentTimeMillis() / 1000
        val i = list.indexOfFirst { it.isNow(now) }
        return if (i >= 0) list[i] to list.getOrNull(i + 1) else null to list.firstOrNull { it.start > now }
    }

    // ---------- Lecture ----------

    fun playableOf(c: Channel) = Playable(c.name, c.group, c.url, c.logo, true, c.favKey, c)

    fun playableOf(m: Movie): Playable? {
        val acc = account ?: return null
        return Playable(m.name, m.category, XtreamClient.movieUrl(acc, m), m.poster, false, m.favKey)
    }

    fun playableOf(s: Series, e: Episode): Playable? {
        val acc = account ?: return null
        return Playable(
            "${s.name} · S${e.season} E${e.num}",
            e.title,
            XtreamClient.episodeUrl(acc, e),
            e.image ?: s.cover,
            false,
            "ep:${e.id}"
        )
    }

    // ---------- Favoris ----------

    fun isFavorite(key: String) = key in favorites

    fun toggleFavorite(key: String) {
        favorites = if (key in favorites) favorites - key else favorites + key
        prefs.edit().putStringSet("favs", favorites).apply()
    }

    // ---------- Reprise de lecture ----------

    private fun progressJson(): JSONObject =
        try { JSONObject(prefs.getString("progress", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    /** Position sauvegardée en ms (0 si rien). */
    fun savedPosition(key: String): Long {
        val o = progressJson().optJSONObject(key) ?: return 0L
        val p = o.optLong("p")
        val d = o.optLong("d")
        return if (d > 0 && p > d * 0.95) 0L else p
    }

    fun progressFraction(key: String): Float {
        val o = progressJson().optJSONObject(key) ?: return 0f
        val d = o.optLong("d")
        return if (d > 0) (o.optLong("p").toFloat() / d).coerceIn(0f, 1f) else 0f
    }

    fun saveProgress(item: Playable, posMs: Long, durMs: Long) {
        if (item.isLive || durMs <= 0) return
        val root = progressJson()
        root.put(item.key, JSONObject().apply {
            put("p", posMs); put("d", durMs)
            put("t", item.title); put("s", item.subtitle)
            put("u", item.url); put("i", item.image ?: "")
            put("ts", System.currentTimeMillis())
        })
        // On garde les 60 plus récents
        if (root.length() > 60) {
            val keys = root.keys().asSequence().toList()
                .sortedBy { root.optJSONObject(it)?.optLong("ts") ?: 0L }
            keys.take(root.length() - 60).forEach { root.remove(it) }
        }
        prefs.edit().putString("progress", root.toString()).apply()
        progressVersion++
    }

    fun continueWatching(): List<Pair<Playable, Float>> {
        val root = progressJson()
        return root.keys().asSequence().mapNotNull { k ->
            val o = root.optJSONObject(k) ?: return@mapNotNull null
            val d = o.optLong("d")
            val p = o.optLong("p")
            if (d <= 0) return@mapNotNull null
            val f = p.toFloat() / d
            if (f < 0.02f || f > 0.95f) return@mapNotNull null
            Triple(
                Playable(
                    o.optString("t"), o.optString("s"), o.optString("u"),
                    o.optString("i").ifBlank { null }, false, k
                ),
                f,
                o.optLong("ts")
            )
        }.sortedByDescending { it.third }.take(20).map { it.first to it.second }.toList()
    }

    /** Toutes les progressions d'un coup (pour les grilles d'affiches). */
    fun progressMap(): Map<String, Float> {
        val root = progressJson()
        val out = HashMap<String, Float>()
        root.keys().forEach { k ->
            val o = root.optJSONObject(k) ?: return@forEach
            val d = o.optLong("d")
            if (d > 0) out[k] = (o.optLong("p").toFloat() / d).coerceIn(0f, 1f)
        }
        return out
    }

    fun resetProgress(key: String) {
        val root = progressJson()
        root.remove(key)
        prefs.edit().putString("progress", root.toString()).apply()
        progressVersion++
    }

    fun clearHistory() {
        prefs.edit().remove("progress").apply()
        progressVersion++
    }

    // ---------- Contrôle parental ----------

    fun checkPin(pin: String) = pin == (prefs.getString("pin", "0000") ?: "0000")

    fun changePin(newPin: String) {
        prefs.edit().putString("pin", newPin).apply()
    }

    fun setHideAdultValue(hide: Boolean) {
        hideAdult = hide
        prefs.edit().putBoolean("hideAdult", hide).apply()
        applyFilter()
    }
}
