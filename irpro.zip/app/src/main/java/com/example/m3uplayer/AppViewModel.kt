package com.example.m3uplayer

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("m3u", Context.MODE_PRIVATE)
    private val dir = app.filesDir

    // Listes complètes (avant filtre parental)
    private var allChannels: List<Channel> = emptyList()
    private var allMovies: List<Movie> = emptyList()
    private var allSeries: List<Series> = emptyList()

    // Listes affichées
    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var movies by mutableStateOf<List<Movie>>(emptyList())
        private set
    var series by mutableStateOf<List<Series>>(emptyList())
        private set

    var loading by mutableStateOf(false)
        private set
    var errorMsg by mutableStateOf<String?>(null)
        private set
    var expiry by mutableStateOf(prefs.getString("expiry", null))
        private set
    var favorites by mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
        private set
    var hideAdult by mutableStateOf(prefs.getBoolean("hideAdult", true))
        private set

    /** Catégories verrouillées par code PIN */
    var lockedCats by mutableStateOf(prefs.getStringSet("locked", emptySet())?.toSet() ?: emptySet())
        private set
    /** Déverrouillé avec le PIN jusqu'à la fermeture de l'appli */
    var sessionUnlocked by mutableStateOf(false)
        private set
    /** Relancer la dernière chaîne au démarrage */
    var autoLastChannel by mutableStateOf(prefs.getBoolean("autoLast", false))
        private set
    /** Comptes enregistrés */
    var accounts by mutableStateOf(loadAccounts())
        private set
    /** Style d'interface : "modern", "classic" ou "mosaic" */
    var layoutStyle by mutableStateOf(prefs.getString("layout", "glass") ?: "glass")
        private set
    /** Taille du texte : 0 = petite, 1 = normale, 2 = grande */
    var textSize by mutableIntStateOf(prefs.getInt("textSize", 0))
        private set

    /** Intro animée à l'ouverture */
    var introEnabled by mutableStateOf(prefs.getBoolean("intro", true))
        private set
    /** Heure de la dernière mise à jour réussie des contenus (ms) */
    var lastUpdate by mutableStateOf(prefs.getLong("lastUpdate", 0L))
        private set

    /** Une nouvelle version est publiée sur GitHub */
    var updateAvailable by mutableStateOf(false)
        private set
    /** Numéro de la dernière version publiée */
    var latestVersion by mutableStateOf<Int?>(null)
        private set
    /** Progression du téléchargement de la mise à jour (null = rien en cours) */
    var updateProgress by mutableStateOf<Float?>(null)
        private set
    var updateMessage by mutableStateOf<String?>(null)
        private set
    /** Affiche la fenêtre de mise à jour */
    var showUpdateDialog by mutableStateOf(false)

    /** Augmente à chaque sauvegarde de progression : sert à rafraîchir « Reprendre ». */
    var progressVersion by mutableIntStateOf(0)
        private set

    /** Guide TV par stream_id */
    val epg = mutableStateMapOf<String, List<EpgEntry>>()
    private val epgLoading = HashSet<String>()

    val mode: String get() = prefs.getString("mode", "xtream") ?: "xtream"
    val lastUrl: String get() = prefs.getString("url", "") ?: ""
    val savedServer: String get() = prefs.getString("xs", "") ?: ""
    val savedUser: String get() = prefs.getString("xu", "") ?: ""
    val savedPass: String get() = prefs.getString("xp", "") ?: ""

    val account: XtreamAccount?
        get() = if (mode == "xtream" && savedServer.isNotBlank()) XtreamAccount(savedServer, savedUser, savedPass) else null

    val hasSource: Boolean get() = channels.isNotEmpty() || movies.isNotEmpty() || series.isNotEmpty()

    init {
        AppTheme.accent = accentThemes.getOrElse(prefs.getInt("accent", 0)) { accentThemes[0] }
        // Le style Verre devient le style par défaut (une seule fois)
        if (!prefs.getBoolean("glassDefaultApplied", false)) {
            prefs.edit().putString("layout", "glass").putBoolean("glassDefaultApplied", true).apply()
            layoutStyle = "glass"
        }
        applyBackground()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { loadFromCache() }
            applyFilter()
            account?.let { refreshXtream(it) }
        }
        checkUpdate()
    }

    // ---------- Chargement ----------

    private fun file(name: String) = File(dir, name)
    private fun readOr(name: String) = file(name).takeIf { it.exists() }?.readText() ?: ""

    private fun loadFromCache() {
        val acc = account
        if (acc != null) {
            if (file("live.json").exists()) allChannels = XtreamClient.parseLive(acc, readOr("live_cats.json"), readOr("live.json"))
            if (file("vod.json").exists()) allMovies = XtreamClient.parseMovies(readOr("vod_cats.json"), readOr("vod.json"))
            if (file("ser.json").exists()) allSeries = XtreamClient.parseSeries(readOr("ser_cats.json"), readOr("ser.json"))
        } else if (file("playlist.m3u").exists()) {
            allChannels = M3uParser.parse(readOr("playlist.m3u"))
        }
    }

    private fun applyFilter() {
        val hideAdultNow = hideAdult && !sessionUnlocked
        val locked = if (sessionUnlocked) emptySet() else lockedCats
        fun hidden(cat: String, name: String = "") =
            cat in locked || (hideAdultNow && (isAdult(cat) || isAdult(name)))
        channels = allChannels.filterNot { hidden(it.group, it.name) }
        movies = allMovies.filterNot { hidden(it.category) }
        series = allSeries.filterNot { hidden(it.category) }
    }

    /** Toutes les catégories (direct, films, séries), même masquées. */
    fun allCategories(): List<String> =
        (allChannels.map { it.group } + allMovies.map { it.category } + allSeries.map { it.category }).distinct()

    fun setLocked(cat: String, locked: Boolean) {
        lockedCats = if (locked) lockedCats + cat else lockedCats - cat
        prefs.edit().putStringSet("locked", lockedCats).apply()
        applyFilter()
    }

    fun setSessionUnlockedValue(v: Boolean) {
        sessionUnlocked = v
        applyFilter()
    }

    private val adultRegex = Regex("""(adult|xxx|porn|\+18|18\+|for adults|erotic)""", RegexOption.IGNORE_CASE)
    private fun isAdult(s: String) = adultRegex.containsMatchIn(s)

    fun refresh() {
        val acc = account
        if (acc != null) refreshXtream(acc) else if (lastUrl.isNotBlank()) loadUrl(lastUrl)
    }

    private fun refreshXtream(acc: XtreamAccount) {
        viewModelScope.launch {
            loading = true
            errorMsg = null
            try {
                val info = withContext(Dispatchers.IO) {
                    val info = XtreamClient.login(acc)
                    val liveCats = XtreamClient.api(acc, "get_live_categories")
                    val live = XtreamClient.api(acc, "get_live_streams")
                    file("live_cats.json").writeText(liveCats)
                    file("live.json").writeText(live)
                    allChannels = XtreamClient.parseLive(acc, liveCats, live)
                    // Films et séries : facultatifs selon le fournisseur
                    runCatching {
                        val c = XtreamClient.api(acc, "get_vod_categories")
                        val v = XtreamClient.api(acc, "get_vod_streams")
                        file("vod_cats.json").writeText(c)
                        file("vod.json").writeText(v)
                        allMovies = XtreamClient.parseMovies(c, v)
                    }
                    runCatching {
                        val c = XtreamClient.api(acc, "get_series_categories")
                        val s = XtreamClient.api(acc, "get_series")
                        file("ser_cats.json").writeText(c)
                        file("ser.json").writeText(s)
                        allSeries = XtreamClient.parseSeries(c, s)
                    }
                    info
                }
                expiry = info.expiry
                prefs.edit().putString("expiry", info.expiry).apply()
                markUpdated()
                epg.clear()
                applyFilter()
            } catch (e: Exception) {
                errorMsg = e.message ?: "Erreur de chargement"
            } finally {
                loading = false
            }
        }
    }

    fun loadXtream(server: String, user: String, pass: String, name: String = "") {
        val acc = XtreamAccount(XtreamClient.normalizeServer(server), user.trim(), pass.trim())
        val changed = acc.server != savedServer || acc.user != savedUser || mode != "xtream"
        saveAccount(Account(name.trim().ifBlank { acc.user }, acc.server, acc.user, acc.pass))
        if (changed) clearCache()
        prefs.edit()
            .putString("mode", "xtream")
            .putString("xs", acc.server)
            .putString("xu", acc.user)
            .putString("xp", acc.pass)
            .apply()
        refreshXtream(acc)
    }

    fun loadUrl(url: String) {
        prefs.edit().putString("mode", "m3u").putString("url", url).apply()
        loadM3u { XtreamClient.httpGet(url) }
    }

    fun loadFile(uri: Uri) {
        prefs.edit().putString("mode", "m3u").apply()
        loadM3u {
            getApplication<Application>().contentResolver.openInputStream(uri)
                ?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("Impossible de lire ce fichier")
        }
    }

    private fun loadM3u(fetch: () -> String) {
        viewModelScope.launch {
            loading = true
            errorMsg = null
            try {
                val list = withContext(Dispatchers.IO) {
                    val text = fetch()
                    val parsed = M3uParser.parse(text)
                    if (parsed.isEmpty()) throw IllegalStateException("Aucune chaîne trouvée")
                    file("playlist.m3u").writeText(text)
                    parsed
                }
                allChannels = list
                allMovies = emptyList()
                allSeries = emptyList()
                expiry = null
                prefs.edit().remove("expiry").apply()
                markUpdated()
                applyFilter()
            } catch (e: Exception) {
                errorMsg = e.message ?: "Erreur de chargement"
            } finally {
                loading = false
            }
        }
    }

    // ---------- Infos détaillées ----------

    suspend fun movieInfo(m: Movie): MovieInfo? {
        val acc = account ?: return null
        return withContext(Dispatchers.IO) { runCatching { XtreamClient.movieInfo(acc, m.id) }.getOrNull() }
    }

    suspend fun seriesInfo(s: Series): SeriesInfo? {
        val acc = account ?: return null
        return withContext(Dispatchers.IO) { runCatching { XtreamClient.seriesInfo(acc, s.id) }.getOrNull() }
    }

    // Guide XMLTV complet, chargé une seule fois si le petit guide est vide
    private var xmltvMap: Map<String, List<EpgEntry>>? = null
    private var xmltvLoading = false

    fun loadEpg(c: Channel?) {
        val acc = account ?: return
        val id = c?.streamId ?: return
        val cached = epg[id]
        val now = System.currentTimeMillis() / 1000
        // Déjà en mémoire et encore à jour
        if (cached != null && cached.isNotEmpty() && cached.last().end > now) return
        if (cached != null && cached.isEmpty() && xmltvMap != null) return
        if (!epgLoading.add(id)) return
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                // 1) petit guide  2) guide détaillé de la chaîne  3) guide XMLTV
                var l = runCatching { XtreamClient.shortEpg(acc, id) }.getOrDefault(emptyList())
                    .filter { it.end > now }
                if (l.isEmpty()) {
                    l = runCatching { XtreamClient.fullEpg(acc, id) }.getOrDefault(emptyList())
                        .filter { it.end > now }.take(12)
                }
                if (l.isEmpty()) {
                    l = c.epgId?.let { e -> xmltvMap?.get(e) }?.filter { it.end > now } ?: emptyList()
                }
                l
            }
            epg[id] = list
            epgLoading.remove(id)
            if (list.isEmpty()) ensureXmltv()
        }
    }

    private fun ensureXmltv() {
        if (xmltvMap != null || xmltvLoading) return
        val acc = account ?: return
        xmltvLoading = true
        viewModelScope.launch {
            val now = System.currentTimeMillis() / 1000
            val map = withContext(Dispatchers.IO) {
                runCatching { XtreamClient.xmltv(acc, now - 3 * 3600, now + 26 * 3600) }.getOrNull()
            }
            xmltvLoading = false
            if (map == null) return@launch
            xmltvMap = map
            // On complète le guide de toutes les chaînes qui n'en avaient pas
            val nowSec = System.currentTimeMillis() / 1000
            channels.forEach { ch ->
                val id = ch.streamId ?: return@forEach
                val e = ch.epgId ?: return@forEach
                if (epg[id].isNullOrEmpty()) {
                    map[e]?.let { list -> epg[id] = list.filter { it.end > nowSec } }
                }
            }
        }
    }

    fun nowNext(c: Channel?): Pair<EpgEntry?, EpgEntry?> {
        val list = c?.streamId?.let { epg[it] } ?: return null to null
        val now = System.currentTimeMillis() / 1000
        val i = list.indexOfFirst { it.isNow(now) }
        return if (i >= 0) list[i] to list.getOrNull(i + 1) else null to list.firstOrNull { it.start > now }
    }

    // ---------- Lecture ----------

    fun playableOf(c: Channel) = Playable(c.name, c.group, c.url, c.logo, true, c.favKey, c)

    fun playableOf(m: Movie): Playable? {
        val acc = account ?: return null
        return Playable(m.name, m.category, XtreamClient.movieUrl(acc, m), m.poster, false, m.favKey)
    }

    fun playableOf(s: Series, e: Episode): Playable? {
        val acc = account ?: return null
        return Playable(
            "${s.name} · S${e.season} E${e.num}",
            e.title,
            XtreamClient.episodeUrl(acc, e),
            e.image ?: s.cover,
            false,
            "ep:${e.id}"
        )
    }

    // ---------- Favoris ----------

    fun isFavorite(key: String) = key in favorites

    fun toggleFavorite(key: String) {
        favorites = if (key in favorites) favorites - key else favorites + key
        prefs.edit().putStringSet("favs", favorites).apply()
    }

    // ---------- Reprise de lecture ----------

    private fun progressJson(): JSONObject =
        try { JSONObject(prefs.getString("progress", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    /** Position sauvegardée en ms (0 si rien). */
    fun savedPosition(key: String): Long {
        val o = progressJson().optJSONObject(key) ?: return 0L
        val p = o.optLong("p")
        val d = o.optLong("d")
        return if (d > 0 && p > d * 0.95) 0L else p
    }

    fun progressFraction(key: String): Float {
        val o = progressJson().optJSONObject(key) ?: return 0f
        val d = o.optLong("d")
        return if (d > 0) (o.optLong("p").toFloat() / d).coerceIn(0f, 1f) else 0f
    }

    fun saveProgress(item: Playable, posMs: Long, durMs: Long) {
        if (item.isLive || durMs <= 0 || item.key.startsWith("replay:")) return
        val root = progressJson()
        root.put(item.key, JSONObject().apply {
            put("p", posMs); put("d", durMs)
            put("t", item.title); put("s", item.subtitle)
            put("u", item.url); put("i", item.image ?: "")
            put("ts", System.currentTimeMillis())
        })
        // On garde les 60 plus récents
        if (root.length() > 60) {
            val keys = root.keys().asSequence().toList()
                .sortedBy { root.optJSONObject(it)?.optLong("ts") ?: 0L }
            keys.take(root.length() - 60).forEach { root.remove(it) }
        }
        prefs.edit().putString("progress", root.toString()).apply()
        progressVersion++
    }

    fun continueWatching(): List<Pair<Playable, Float>> {
        val root = progressJson()
        return root.keys().asSequence().mapNotNull { k ->
            val o = root.optJSONObject(k) ?: return@mapNotNull null
            val d = o.optLong("d")
            val p = o.optLong("p")
            if (d <= 0) return@mapNotNull null
            val f = p.toFloat() / d
            if (f < 0.02f || f > 0.95f) return@mapNotNull null
            Triple(
                Playable(
                    o.optString("t"), o.optString("s"), o.optString("u"),
                    o.optString("i").ifBlank { null }, false, k
                ),
                f,
                o.optLong("ts")
            )
        }.sortedByDescending { it.third }.take(20).map { it.first to it.second }.toList()
    }

    /** Toutes les progressions d'un coup (pour les grilles d'affiches). */
    fun progressMap(): Map<String, Float> {
        val root = progressJson()
        val out = HashMap<String, Float>()
        root.keys().forEach { k ->
            val o = root.optJSONObject(k) ?: return@forEach
            val d = o.optLong("d")
            if (d > 0) out[k] = (o.optLong("p").toFloat() / d).coerceIn(0f, 1f)
        }
        return out
    }

    fun resetProgress(key: String) {
        val root = progressJson()
        root.remove(key)
        prefs.edit().putString("progress", root.toString()).apply()
        progressVersion++
    }

    fun clearHistory() {
        prefs.edit().remove("progress").apply()
        progressVersion++
    }

    // ---------- Replay ----------

    suspend fun replayGuide(c: Channel): List<EpgEntry> {
        val acc = account ?: return emptyList()
        val id = c.streamId ?: return emptyList()
        return withContext(Dispatchers.IO) {
            runCatching { XtreamClient.fullEpg(acc, id) }.getOrDefault(emptyList())
        }
    }

    fun playableReplay(c: Channel, e: EpgEntry): Playable? {
        val acc = account ?: return null
        val id = c.streamId ?: return null
        return Playable(
            e.title.ifBlank { c.name },
            "Replay · ${c.name} · ${dayHour(e.start)}",
            XtreamClient.replayUrl(acc, id, e),
            c.logo,
            false,
            "replay:$id:${e.start}"
        )
    }

    private fun dayHour(sec: Long): String =
        java.text.SimpleDateFormat("EEE d MMM HH:mm", java.util.Locale.FRANCE).format(java.util.Date(sec * 1000))

    // ---------- Dernière chaîne ----------

    fun rememberLastChannel(c: Channel) {
        prefs.edit().putString("lastCh", c.url).apply()
    }

    fun lastChannel(): Channel? {
        val url = prefs.getString("lastCh", null) ?: return null
        return channels.firstOrNull { it.url == url }
    }

    fun setAutoLastChannelValue(v: Boolean) {
        autoLastChannel = v
        prefs.edit().putBoolean("autoLast", v).apply()
    }

    // ---------- Comptes multiples ----------

    private fun loadAccounts(): List<Account> = try {
        val arr = org.json.JSONArray(prefs.getString("accounts", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let {
                Account(it.optString("n"), it.optString("s"), it.optString("u"), it.optString("p"))
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun storeAccounts(list: List<Account>) {
        val arr = org.json.JSONArray()
        list.forEach { a ->
            arr.put(JSONObject().apply { put("n", a.name); put("s", a.server); put("u", a.user); put("p", a.pass) })
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
        accounts = list
    }

    private fun saveAccount(a: Account) {
        val others = accounts.filterNot { it.server == a.server && it.user == a.user }
        storeAccounts(listOf(a) + others)
    }

    fun switchAccount(a: Account) {
        loadXtream(a.server, a.user, a.pass, a.name)
    }

    fun deleteAccount(a: Account) {
        storeAccounts(accounts.filterNot { it == a })
    }

    fun isCurrent(a: Account) = mode == "xtream" && a.server == savedServer && a.user == savedUser

    private fun clearCache() {
        listOf("live_cats.json", "live.json", "vod_cats.json", "vod.json", "ser_cats.json", "ser.json")
            .forEach { file(it).delete() }
        allChannels = emptyList(); allMovies = emptyList(); allSeries = emptyList()
        epg.clear()
        applyFilter()
    }

    // ---------- Mise à jour ----------

    private fun checkUpdate(manual: Boolean = false) {
        viewModelScope.launch {
            if (manual) updateMessage = "Recherche d'une mise à jour…"
            val latest = withContext(Dispatchers.IO) {
                runCatching { XtreamClient.latestVersion(GITHUB_OWNER, GITHUB_REPO) }.getOrNull()
            }
            if (latest == null) {
                if (manual) updateMessage = "Impossible de vérifier pour le moment. Réessaie plus tard."
                return@launch
            }
            latestVersion = latest
            updateAvailable = latest > currentVersionCode()
            if (manual) {
                updateMessage = null
            } else if (updateAvailable) {
                showUpdateDialog = true
            }
        }
    }

    fun checkUpdateNow() = checkUpdate(manual = true)

    val currentVersion: Int get() = currentVersionCode()

    fun setUpdateMessageValue(msg: String?) {
        updateMessage = msg
    }

    /** Télécharge la nouvelle version puis appelle [onReady] avec le fichier. */
    fun downloadUpdate(onReady: (File) -> Unit) {
        if (updateProgress != null) return
        viewModelScope.launch {
            updateMessage = null
            updateProgress = 0f
            try {
                val app = getApplication<Application>()
                val f = withContext(Dispatchers.IO) {
                    Updater.download(app) { p -> updateProgress = p }
                }
                updateProgress = null
                onReady(f)
            } catch (e: Exception) {
                updateProgress = null
                updateMessage = "Échec du téléchargement : ${e.message ?: "erreur réseau"}"
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun currentVersionCode(): Int = runCatching {
        val app = getApplication<Application>()
        val info = app.packageManager.getPackageInfo(app.packageName, 0)
        if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else info.versionCode
    }.getOrDefault(Int.MAX_VALUE)

    companion object {
        const val GITHUB_OWNER = "alaeddine133"
        const val GITHUB_REPO = "irpro"
    }

    private fun markUpdated() {
        lastUpdate = System.currentTimeMillis()
        prefs.edit().putLong("lastUpdate", lastUpdate).apply()
    }

    fun cycleTextSize() {
        textSize = (textSize + 1) % 3
        prefs.edit().putInt("textSize", textSize).apply()
    }

    fun setIntroEnabledValue(v: Boolean) {
        introEnabled = v
        prefs.edit().putBoolean("intro", v).apply()
    }

    fun setLayoutStyleValue(style: String) {
        layoutStyle = style
        prefs.edit().putString("layout", style).apply()
        applyBackground()
    }

    /** Le style Verre a son propre fond translucide ; les autres utilisent le fond choisi. */
    private fun applyBackground() {
        AppTheme.background = if (layoutStyle == "glass") glassBackground
        else backgroundThemes.getOrElse(prefs.getInt("bgTheme", 0)) { backgroundThemes[0] }
    }

    // ---------- Thèmes ----------

    fun setAccent(i: Int) {
        AppTheme.accent = accentThemes[i]
        prefs.edit().putInt("accent", i).apply()
    }

    fun setBackground(i: Int) {
        prefs.edit().putInt("bgTheme", i).apply()
        applyBackground()
    }

    // ---------- Contrôle parental ----------

    fun checkPin(pin: String) = pin == (prefs.getString("pin", "0000") ?: "0000")

    fun changePin(newPin: String) {
        prefs.edit().putString("pin", newPin).apply()
    }

    fun setHideAdultValue(hide: Boolean) {
        hideAdult = hide
        prefs.edit().putBoolean("hideAdult", hide).apply()
        applyFilter()
    }
}
