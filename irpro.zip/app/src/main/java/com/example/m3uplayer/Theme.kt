package com.example.m3uplayer

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

// ---------- Thèmes IR PRO ----------

/** Couleur principale : sélection, boutons, barres de progression */
data class AccentTheme(val name: String, val primary: Color, val mid: Color, val light: Color, val dark: Color)

/** Couleurs de fond */
data class BackgroundTheme(val name: String, val bg: Color, val panel: Color, val card: Color)

val accentThemes = listOf(
    AccentTheme("Violet", Color(0xFF534AB7), Color(0xFF7F77DD), Color(0xFFAFA9EC), Color(0xFF26215C)),
    AccentTheme("Bleu", Color(0xFF185FA5), Color(0xFF378ADD), Color(0xFF85B7EB), Color(0xFF042C53)),
    AccentTheme("Vert", Color(0xFF0F6E56), Color(0xFF1D9E75), Color(0xFF5DCAA5), Color(0xFF04342C)),
    AccentTheme("Rouge", Color(0xFFA32D2D), Color(0xFFE24B4A), Color(0xFFF09595), Color(0xFF501313)),
    AccentTheme("Orange", Color(0xFF993C1D), Color(0xFFD85A30), Color(0xFFF0997B), Color(0xFF4A1B0C)),
    AccentTheme("Or", Color(0xFF854F0B), Color(0xFFBA7517), Color(0xFFEF9F27), Color(0xFF412402)),
    AccentTheme("Rose", Color(0xFF993556), Color(0xFFD4537E), Color(0xFFED93B1), Color(0xFF4B1528))
)

val backgroundThemes = listOf(
    BackgroundTheme("Noir profond", Color(0xFF08090B), Color(0xFF0F1115), Color(0xFF181B21)),
    BackgroundTheme("Anthracite", Color(0xFF16181D), Color(0xFF1E2127), Color(0xFF2A2E36)),
    BackgroundTheme("Bleu nuit", Color(0xFF0A1020), Color(0xFF111A2E), Color(0xFF1B2640)),
    BackgroundTheme("Violet nuit", Color(0xFF0E0B1A), Color(0xFF171228), Color(0xFF221B3A))
)

/** Fond spécial du style Verre : panneaux translucides posés sur un dégradé coloré */
val glassBackground = BackgroundTheme("Verre", Color(0xFF070B14), Color(0x26FFFFFF), Color(0x1FFFFFFF))

/** Thème en cours : le changer redessine toute l'appli instantanément. */
object AppTheme {
    var accent by mutableStateOf(accentThemes[0])
    var background by mutableStateOf(backgroundThemes[0])
}

val Purple: Color get() = AppTheme.accent.primary
val PurpleMid: Color get() = AppTheme.accent.mid
val PurpleLight: Color get() = AppTheme.accent.light
val PurpleDark: Color get() = AppTheme.accent.dark
val Bg: Color get() = AppTheme.background.bg
val Panel: Color get() = AppTheme.background.panel
val CardBg: Color get() = AppTheme.background.card

// Le logo garde toujours ses couleurs d'origine
val LogoPurple = Color(0xFF534AB7)
val LogoPurpleLight = Color(0xFFAFA9EC)
val TextMain = Color(0xFFF5F4F0)
val TextSoft = Color(0xFF9A9A9A)
val LiveRed = Color(0xFFE24B4A)
val FavPink = Color(0xFFF09595)

private val posterColors = listOf(
    Color(0xFF3C3489), Color(0xFF712B13), Color(0xFF085041), Color(0xFF0C447C),
    Color(0xFF72243E), Color(0xFF633806), Color(0xFF27500A), Color(0xFF26215C)
)

fun colorFor(text: String): Color = posterColors[(text.hashCode() and 0x7fffffff) % posterColors.size]

fun initials(name: String): String =
    name.split(" ", "-", "_").mapNotNull { it.firstOrNull()?.uppercaseChar() }
        .filter { it.isLetterOrDigit() }.take(2).joinToString("")

/** Le logo IR PRO dessiné en vectoriel (net à toutes les tailles). */
@Composable
fun IrProIcon(size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 88f
        drawRoundRect(LogoPurple, cornerRadius = CornerRadius(22f * s, 22f * s))
        drawRoundRect(
            Color.White,
            topLeft = Offset(18f * s, 18f * s),
            size = Size(12f * s, 52f * s),
            cornerRadius = CornerRadius(3f * s, 3f * s)
        )
        val bowl = Path().apply {
            moveTo(38f * s, 18f * s)
            lineTo(56f * s, 18f * s)
            arcTo(Rect(42f * s, 18f * s, 70f * s, 46f * s), -90f, 180f, false)
            lineTo(38f * s, 46f * s)
            close()
        }
        drawPath(bowl, Color.White)
        val leg = Path().apply {
            moveTo(38f * s, 48f * s)
            lineTo(38f * s, 70f * s)
            lineTo(70f * s, 70f * s)
            close()
        }
        drawPath(leg, Color.White)
    }
}

@Composable
fun IrProWordmark(fontSize: TextUnit) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("IR") }
            withStyle(SpanStyle(color = LogoPurpleLight, fontWeight = FontWeight.Light)) { append(" PRO") }
        },
        fontSize = fontSize,
        maxLines = 1
    )
}

/** Élément sélectionnable à la télécommande : grossit et s'entoure de violet. */
@Composable
fun FocusBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    selected: Boolean = false,
    focusScale: Float = 1.05f,
    filledWhenFocused: Boolean = true,
    onFocused: () -> Unit = {},
    content: @Composable BoxScope.(focused: Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusScale else 1f, label = "focusScale")
    Box(
        modifier
            .scale(scale)
            .clip(shape)
            .background(
                when {
                    focused && filledWhenFocused -> Purple
                    selected -> CardBg
                    else -> Color.Transparent
                }
            )
            .border(3.dp, if (focused) Color.White else Color.Transparent, shape)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .clickable(onClick = onClick)
    ) {
        content(focused)
    }
}

@Composable
fun ChannelLogo(channel: Channel, size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.24f).dp)).background(CardBg),
        contentAlignment = Alignment.Center
    ) {
        if (channel.logo != null) {
            AsyncImage(
                model = channel.logo,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding((size / 10).dp)
            )
        } else {
            // Pas de logo : icône arrondie colorée avec les initiales
            val base = colorFor(channel.name)
            Box(
                Modifier.fillMaxSize().background(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(base.copy(alpha = 0.95f), base.copy(alpha = 0.6f)))
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(initials(channel.name), color = Color.White, fontSize = (size / 3).sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Image avec repli coloré + titre quand il n'y a pas d'image. */
@Composable
fun ArtImage(url: String?, title: String, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Crop) {
    Box(modifier.background(colorFor(title)), contentAlignment = Alignment.BottomStart) {
        Text(
            title,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(8.dp)
        )
        if (url != null) {
            AsyncImage(model = url, contentDescription = title, contentScale = contentScale, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun ProgressLine(fraction: Float, modifier: Modifier = Modifier, color: Color = PurpleMid) {
    Box(modifier.height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x33FFFFFF))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f)).background(color))
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = TextMain,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier.padding(start = 8.dp, top = 18.dp, bottom = 10.dp)
    )
}

/** Affiche de film / série (format portrait). */
@Composable
fun PosterCard(
    title: String,
    image: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 140.dp,
    progress: Float = 0f,
    badge: String? = null
) {
    Column(modifier.width(width)) {
        FocusBox(onClick = onClick, filledWhenFocused = false, focusScale = 1.08f) {
            Box {
                ArtImage(image, title, Modifier.width(width).height(width * 1.45f))
                if (badge != null) {
                    Text(
                        badge,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                if (progress > 0f) {
                    ProgressLine(progress, Modifier.align(Alignment.BottomCenter).fillMaxWidth())
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(title, color = TextMain, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Carte d'une chaîne en direct avec le programme en cours. */
@Composable
fun LiveCard(vm: AppViewModel, channel: Channel, onClick: () -> Unit) {
    val (now, _) = vm.nowNext(channel)
    val nowSec = System.currentTimeMillis() / 1000
    FocusBox(
        onClick = onClick,
        selected = true,
        onFocused = { vm.loadEpg(channel) },
        modifier = Modifier.width(220.dp)
    ) { focused ->
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChannelLogo(channel, 40)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(channel.name, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        now?.title ?: channel.group,
                        color = if (focused) TextMain else TextSoft,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            ProgressLine(now?.progress(nowSec) ?: 0f, Modifier.fillMaxWidth(), if (focused) Color.White else PurpleMid)
        }
    }
}

@Composable
fun EmptyMessage(text: String) {
    Box(Modifier.fillMaxSize().padding(40.dp), contentAlignment = Alignment.Center) {
        Text(text, color = TextSoft, fontSize = 18.sp)
    }
}

@Composable
fun Pill(text: String, color: Color = CardBg, textColor: Color = TextMain) {
    Text(
        text,
        color = textColor,
        fontSize = 13.sp,
        modifier = Modifier
            .background(color, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
