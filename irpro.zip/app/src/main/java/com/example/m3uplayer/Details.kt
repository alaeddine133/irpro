package com.example.m3uplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun ActionButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconTint: Color = Color.White
) {
    FocusBox(onClick = onClick, selected = true, shape = RoundedCornerShape(28.dp), modifier = modifier) {
        Row(Modifier.padding(horizontal = 24.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = iconTint)
            Spacer(Modifier.width(10.dp))
            Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Backdrop(url: String?) {
    if (url != null) {
        AsyncImage(
            model = url,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = 0.35f,
            modifier = Modifier.fillMaxSize()
        )
    }
    Box(Modifier.fillMaxSize().background(Color(0x9908090B)))
}

private fun minutesText(ms: Long): String {
    val min = ms / 60_000
    return if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"
}

// =====================================================================
// FICHE FILM
// =====================================================================

@Composable
fun MovieDetailScreen(vm: AppViewModel, movie: Movie, nav: Nav) {
    var info by remember { mutableStateOf<MovieInfo?>(null) }
    LaunchedEffect(movie.id) { info = vm.movieInfo(movie) }
    val pos = remember(vm.progressVersion) { vm.savedPosition(movie.favKey) }
    val isFav = movie.favKey in vm.favorites
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { playFocus.requestFocus() }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Backdrop(info?.backdrop ?: movie.poster)
        Row(Modifier.fillMaxSize().padding(56.dp), verticalAlignment = Alignment.CenterVertically) {
            ArtImage(
                movie.poster, movie.name,
                Modifier.width(280.dp).height(410.dp).clip(RoundedCornerShape(18.dp))
            )
            Spacer(Modifier.width(48.dp))
            Column(Modifier.weight(1f)) {
                Text(movie.name, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    info?.year?.let { Pill(it) }
                    info?.duration?.let { Pill(it) }
                    movie.rating?.let { Pill("★ $it", Purple) }
                    Pill(movie.category)
                }
                info?.genre?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(it, color = PurpleLight, fontSize = 16.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    info?.plot ?: if (info == null && vm.account != null) "Chargement du résumé…" else "",
                    color = TextMain, fontSize = 17.sp, lineHeight = 25.sp, maxLines = 6, overflow = TextOverflow.Ellipsis
                )
                info?.director?.let {
                    Spacer(Modifier.height(10.dp))
                    Text("Réalisation : $it", color = TextSoft, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                info?.cast?.let {
                    Text("Avec : $it", color = TextSoft, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(28.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    val playable = vm.playableOf(movie)
                    ActionButton(
                        if (pos > 0) "Reprendre (${minutesText(pos)})" else "Lecture",
                        Icons.Filled.PlayArrow,
                        onClick = { playable?.let { nav.play(listOf(it), 0) } },
                        modifier = Modifier.focusRequester(playFocus)
                    )
                    if (pos > 0) {
                        ActionButton("Depuis le début", Icons.Filled.Replay, onClick = {
                            vm.resetProgress(movie.favKey)
                            playable?.let { nav.play(listOf(it), 0) }
                        })
                    }
                    ActionButton(
                        if (isFav) "Dans ma liste" else "Ma liste",
                        if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        onClick = { vm.toggleFavorite(movie.favKey) },
                        iconTint = if (isFav) FavPink else Color.White
                    )
                }
            }
        }
    }
}

// =====================================================================
// FICHE SÉRIE (saisons + épisodes)
// =====================================================================

@Composable
fun SeriesDetailScreen(vm: AppViewModel, series: Series, nav: Nav) {
    var info by remember { mutableStateOf<SeriesInfo?>(null) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(series.id) {
        info = vm.seriesInfo(series)
        loaded = true
    }
    val seasons = info?.seasons ?: emptyMap()
    var season by remember { mutableIntStateOf(-1) }
    LaunchedEffect(seasons) { if (season !in seasons.keys) season = seasons.keys.firstOrNull() ?: -1 }
    val episodes = seasons[season] ?: emptyList()
    val prog = remember(vm.progressVersion) { vm.progressMap() }
    val isFav = series.favKey in vm.favorites
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { firstFocus.requestFocus() }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Backdrop(info?.cover ?: series.cover)
        Row(Modifier.fillMaxSize().padding(40.dp)) {
            // Infos de la série
            Column(Modifier.width(420.dp).fillMaxHeight()) {
                ArtImage(
                    series.cover, series.name,
                    Modifier.width(200.dp).height(290.dp).clip(RoundedCornerShape(16.dp))
                )
                Spacer(Modifier.height(18.dp))
                Text(series.name, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    info?.year?.let { Pill(it) }
                    series.rating?.let { Pill("★ $it", Purple) }
                    if (seasons.isNotEmpty()) Pill("${seasons.size} saison(s)")
                }
                (info?.genre)?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = PurpleLight, fontSize = 15.sp, maxLines = 1)
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    info?.plot ?: series.plot ?: "",
                    color = TextMain, fontSize = 15.sp, lineHeight = 22.sp, maxLines = 6, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(18.dp))
                ActionButton(
                    if (isFav) "Dans mes séries" else "Mes séries",
                    if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    onClick = { vm.toggleFavorite(series.favKey) },
                    iconTint = if (isFav) FavPink else Color.White,
                    modifier = Modifier.focusRequester(firstFocus)
                )
            }
            Spacer(Modifier.width(32.dp))

            // Saisons + épisodes
            Column(Modifier.weight(1f).fillMaxHeight()) {
                when {
                    !loaded -> Text("Chargement des épisodes…", color = TextSoft, fontSize = 17.sp)
                    seasons.isEmpty() -> Text("Aucun épisode trouvé pour cette série.", color = TextSoft, fontSize = 17.sp)
                    else -> {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)
                        ) {
                            items(seasons.keys.toList()) { s ->
                                FocusBox(
                                    onClick = { season = s },
                                    onFocused = { season = s },
                                    selected = s == season,
                                    shape = RoundedCornerShape(20.dp)
                                ) { f ->
                                    Text(
                                        "Saison $s",
                                        color = if (f || s == season) TextMain else TextSoft,
                                        fontSize = 16.sp,
                                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 40.dp, top = 4.dp, start = 4.dp, end = 4.dp)
                        ) {
                            itemsIndexed(episodes) { i, e ->
                                val key = "ep:${e.id}"
                                FocusBox(
                                    onClick = {
                                        val list = episodes.mapNotNull { vm.playableOf(series, it) }
                                        nav.play(list, i)
                                    },
                                    selected = true,
                                    focusScale = 1.02f,
                                    modifier = Modifier.fillMaxWidth()
                                ) { f ->
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box {
                                            ArtImage(
                                                e.image ?: series.cover, "E${e.num}",
                                                Modifier.width(190.dp).height(107.dp).clip(RoundedCornerShape(10.dp))
                                            )
                                            val p = prog[key] ?: 0f
                                            if (p > 0f) ProgressLine(p, Modifier.align(Alignment.BottomCenter).fillMaxWidth())
                                        }
                                        Spacer(Modifier.width(16.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                "${e.num}. ${e.title}",
                                                color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                                maxLines = 1, overflow = TextOverflow.Ellipsis
                                            )
                                            e.durationSec?.let {
                                                Text("${it / 60} min", color = if (f) TextMain else TextSoft, fontSize = 13.sp)
                                            }
                                            e.plot?.let {
                                                Spacer(Modifier.height(4.dp))
                                                Text(it, color = if (f) TextMain else TextSoft, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
