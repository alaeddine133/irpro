package com.example.m3uplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val ALL_GUIDE = "Toutes"
private const val GUIDE_SPAN = 3 * 3600L // 3 heures affichées

private fun dayLabel(sec: Long): String =
    SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(sec * 1000)).replaceFirstChar { it.uppercase() }

// =====================================================================
// GRILLE TV (toutes les chaînes, heure par heure)
// =====================================================================

@Composable
fun GuideScreen(vm: AppViewModel, nav: Nav) {
    val channels = vm.channels
    val groups = remember(channels) { listOf(ALL_GUIDE) + channels.map { it.group }.distinct() }
    var group by rememberSaveable { mutableStateOf(ALL_GUIDE) }
    val list = remember(channels, group) { if (group == ALL_GUIDE) channels else channels.filter { it.group == group } }
    val nowSec = System.currentTimeMillis() / 1000
    val nowFloor = nowSec - nowSec % 1800
    var windowStart by rememberSaveable { mutableLongStateOf(nowFloor) }

    if (vm.account == null) {
        EmptyMessage("La grille TV est disponible avec un compte Xtream.")
        return
    }

    Column(Modifier.fillMaxSize()) {
        // Barre du haut : navigation dans le temps
        Row(
            Modifier.fillMaxWidth().padding(start = 28.dp, end = 28.dp, top = 18.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Guide TV", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(dayLabel(windowStart), color = PurpleLight, fontSize = 14.sp)
            }
            Spacer(Modifier.weight(1f))
            GuideButton("◀ Plus tôt") { windowStart = (windowStart - 3600).coerceAtLeast(nowFloor) }
            Spacer(Modifier.width(10.dp))
            GuideButton("Maintenant") { windowStart = nowFloor }
            Spacer(Modifier.width(10.dp))
            GuideButton("Plus tard ▶") { windowStart = (windowStart + 3600).coerceAtMost(nowFloor + 9 * 3600) }
        }

        // Catégories
        LazyRow(
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(groups) { g ->
                FocusBox(onClick = { group = g }, selected = g == group, focusScale = 1.04f, shape = RoundedCornerShape(20.dp)) { f ->
                    Text(
                        g, color = if (f || g == group) TextMain else TextSoft, fontSize = 14.sp, maxLines = 1,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
        }

        BoxWithConstraints(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp)) {
            val nameW = 230.dp
            val gridW = maxWidth - nameW - 8.dp
            val dpPerSec: Dp = gridW / GUIDE_SPAN.toFloat()

            Column(Modifier.fillMaxSize()) {
                // Échelle des heures
                Row(Modifier.height(30.dp)) {
                    Spacer(Modifier.width(nameW + 8.dp))
                    Box(Modifier.width(gridW).fillMaxHeight()) {
                        for (k in 0 until (GUIDE_SPAN / 1800).toInt()) {
                            val t = windowStart + k * 1800
                            Text(
                                hhmm(t), color = TextSoft, fontSize = 13.sp,
                                modifier = Modifier.offset(x = dpPerSec * (k * 1800f)).padding(start = 4.dp)
                            )
                        }
                        if (nowSec in windowStart until windowStart + GUIDE_SPAN) {
                            Box(
                                Modifier
                                    .offset(x = dpPerSec * (nowSec - windowStart).toFloat())
                                    .width(2.dp)
                                    .fillMaxHeight()
                                    .background(LiveRed)
                            )
                        }
                    }
                }
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(bottom = 40.dp)
                ) {
                    itemsIndexed(list) { i, c ->
                        GuideRow(vm, c, windowStart, nowSec, nameW, gridW, dpPerSec) {
                            nav.play(list.map { vm.playableOf(it) }, i)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideButton(text: String, onClick: () -> Unit) {
    FocusBox(onClick = onClick, selected = true, focusScale = 1.04f, shape = RoundedCornerShape(20.dp)) {
        Text(text, color = TextMain, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
    }
}

@Composable
private fun GuideRow(
    vm: AppViewModel,
    c: Channel,
    windowStart: Long,
    nowSec: Long,
    nameW: Dp,
    gridW: Dp,
    dpPerSec: Dp,
    onPlay: () -> Unit
) {
    LaunchedEffect(c.streamId) { vm.loadEpg(c) }
    val entries = c.streamId?.let { vm.epg[it] } ?: emptyList()
    val windowEnd = windowStart + GUIDE_SPAN
    val visible = entries.filter { it.end > windowStart && it.start < windowEnd }

    Row(Modifier.height(66.dp), verticalAlignment = Alignment.CenterVertically) {
        FocusBox(onClick = onPlay, selected = true, focusScale = 1.02f, modifier = Modifier.width(nameW).fillMaxHeight()) {
            Row(Modifier.padding(horizontal = 10.dp).fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                ChannelLogo(c, 40)
                Spacer(Modifier.width(10.dp))
                Text(c.name, color = TextMain, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(gridW).fillMaxHeight()) {
            if (visible.isEmpty()) {
                Text(
                    if (c.streamId != null && vm.epg[c.streamId] == null) "Chargement…" else "Pas de programme",
                    color = TextSoft, fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp)
                )
            }
            visible.forEach { e ->
                val s = maxOf(e.start, windowStart)
                val en = minOf(e.end, windowEnd)
                val isNow = e.isNow(nowSec)
                FocusBox(
                    onClick = onPlay,
                    selected = true,
                    focusScale = 1f,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .offset(x = dpPerSec * (s - windowStart).toFloat())
                        .width((dpPerSec * (en - s).toFloat() - 4.dp).coerceAtLeast(10.dp))
                        .fillMaxHeight()
                ) { f ->
                    Column(
                        Modifier
                            .fillMaxSize()
                            .background(if (isNow && !f) PurpleDark else Color.Transparent)
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(e.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${hhmm(e.start)} – ${hhmm(e.end)}",
                            color = if (f) TextMain else TextSoft, fontSize = 12.sp, maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

// =====================================================================
// REPLAY D'UNE CHAÎNE
// =====================================================================

@Composable
fun ReplayScreen(vm: AppViewModel, channel: Channel, nav: Nav) {
    var guide by remember { mutableStateOf<List<EpgEntry>?>(null) }
    LaunchedEffect(channel.url) { guide = vm.replayGuide(channel) }
    val nowSec = System.currentTimeMillis() / 1000
    val dayFmt = remember { SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE) }

    // Émissions passées, regroupées par jour (le plus récent d'abord)
    val days: List<Pair<String, List<EpgEntry>>> = remember(guide) {
        val g = guide ?: return@remember emptyList()
        val anyArchiveFlag = g.any { it.hasArchive }
        val limit = nowSec - channel.archiveDays.coerceAtLeast(1) * 86_400L
        g.filter { it.end <= nowSec && it.start >= limit && (!anyArchiveFlag || it.hasArchive) }
            .groupBy { dayFmt.format(Date(it.start * 1000)) }
            .toList()
            .sortedByDescending { it.first }
            .map { (k, v) -> k to v.sortedByDescending { it.start } }
    }
    var day by remember { mutableStateOf<String?>(null) }
    val selected = days.firstOrNull { it.first == day } ?: days.firstOrNull()
    val today = dayFmt.format(Date())
    val yesterday = dayFmt.format(Date(System.currentTimeMillis() - 86_400_000L))
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(days.isNotEmpty()) {
        if (days.isNotEmpty()) {
            delay(80)
            runCatching { firstFocus.requestFocus() }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(40.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ChannelLogo(channel, 70)
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Replay · ${channel.name}", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("${channel.archiveDays} jour(s) disponibles · Retour pour quitter", color = TextSoft, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(18.dp))

        when {
            guide == null -> Text("Chargement des émissions…", color = TextSoft, fontSize = 17.sp)
            days.isEmpty() -> Text("Aucune émission en replay pour cette chaîne.", color = TextSoft, fontSize = 17.sp)
            else -> {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 6.dp, horizontal = 4.dp)) {
                    itemsIndexed(days) { i, (key, list) ->
                        val label = when (key) {
                            today -> "Aujourd'hui"
                            yesterday -> "Hier"
                            else -> list.firstOrNull()?.let {
                                SimpleDateFormat("EEE d MMM", Locale.FRANCE).format(Date(it.start * 1000))
                            } ?: key
                        }
                        FocusBox(
                            onClick = { day = key },
                            onFocused = { day = key },
                            selected = selected?.first == key,
                            shape = RoundedCornerShape(20.dp),
                            modifier = if (i == 0) Modifier.focusRequester(firstFocus) else Modifier
                        ) { f ->
                            Text(
                                label, color = if (f || selected?.first == key) TextMain else TextSoft, fontSize = 15.sp,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 40.dp, start = 4.dp, end = 4.dp, top = 4.dp)
                ) {
                    items(selected?.second ?: emptyList()) { e ->
                        FocusBox(
                            onClick = { vm.playableReplay(channel, e)?.let { nav.play(listOf(it), 0) } },
                            selected = true,
                            focusScale = 1.02f,
                            modifier = Modifier.fillMaxWidth()
                        ) { f ->
                            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "${hhmm(e.start)} – ${hhmm(e.end)}",
                                    color = if (f) TextMain else PurpleLight, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(140.dp)
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, color = TextMain, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (e.desc.isNotBlank()) {
                                        Text(e.desc, color = if (f) TextMain else TextSoft, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                Text("▶", color = Color.White, fontSize = 18.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
