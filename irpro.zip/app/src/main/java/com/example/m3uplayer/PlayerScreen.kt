package com.example.m3uplayer

import android.app.Activity
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.ui.AspectRatioFrameLayout
import java.util.Locale

private fun timeText(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppViewModel, items: List<Playable>, startIndex: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    var index by remember { mutableIntStateOf(startIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))) }
    val item = items[index]
    val isLive = item.isLive

    var error by remember { mutableStateOf<String?>(null) }
    var buffering by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var overlayTick by remember { mutableIntStateOf(0) }
    var showOverlay by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    // Un seul lecteur pour toute la séance : zapping et épisodes suivants instantanés
    val player = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("IRPRO/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(20_000)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 1_000, 2_500)
            .build()
        // Décodeurs de la box en priorité, FFmpeg en secours pour tous les formats audio
        val renderers = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        ExoPlayer.Builder(context, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(context, http)))
            .setLoadControl(loadControl)
            .build()
            .apply {
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setPreferredAudioLanguage("fr")
                    .setPreferredTextLanguage("fr")
                    .build()
            }
    }

    var showPanel by remember { mutableStateOf(false) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var tracksVersion by remember { mutableIntStateOf(0) }
    var retries by remember { mutableIntStateOf(0) }
    var sleepMin by remember { mutableIntStateOf(0) }

    // Minuterie de mise en veille : met en pause et quitte le lecteur
    LaunchedEffect(sleepMin) {
        if (sleepMin > 0) {
            delay(sleepMin * 60_000L)
            player.pause()
            onBack()
        }
    }

    val currentItem by rememberUpdatedState(item)

    fun saveNow() {
        val d = player.duration
        if (!currentItem.isLive && d != C.TIME_UNSET && d > 0) {
            vm.saveProgress(currentItem, player.currentPosition, d)
        }
    }

    // Lancement de chaque élément (avec reprise pour films / épisodes)
    LaunchedEffect(index) {
        error = null
        retries = 0
        position = 0L
        duration = 0L
        player.setMediaItem(MediaItem.fromUri(item.url))
        val resumeAt = if (item.isLive) 0L else vm.savedPosition(item.key)
        if (resumeAt > 0) player.seekTo(resumeAt)
        player.prepare()
        player.playWhenReady = true
        item.channel?.let {
            vm.loadEpg(it)
            vm.rememberLastChannel(it)
        }
        overlayTick++
    }

    // Bandeau visible 4 s après chaque action
    LaunchedEffect(overlayTick) {
        showOverlay = true
        delay(4_000)
        if (player.isPlaying || isLive) showOverlay = false
    }

    // Position + sauvegarde régulière de la progression
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            delay(1_000)
            position = player.currentPosition
            val d = player.duration
            duration = if (d == C.TIME_UNSET || d < 0) 0L else d
            if (++tick % 10 == 0) saveNow()
        }
    }

    // Saisie d'un numéro de chaîne
    LaunchedEffect(digits) {
        if (digits.isEmpty()) return@LaunchedEffect
        delay(1_500)
        val n = digits.toIntOrNull()
        if (n != null && n in 1..items.size) index = n - 1
        digits = ""
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                // Direct trop en retard : on revient au direct sans rien afficher
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                // Coupure réseau : jusqu'à 3 reconnexions automatiques
                val network = e.errorCode in 2000..2999
                if (network && retries < 3) {
                    retries++
                    error = null
                    buffering = true
                    player.prepare()
                    player.playWhenReady = true
                    return
                }
                error = "Impossible de lire cette vidéo.\n(${e.errorCodeName})"
            }

            override fun onTracksChanged(tracks: Tracks) {
                tracksVersion++
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && !currentItem.isLive) {
                    // Fin : on note comme vu, puis épisode suivant s'il y en a un
                    val d = player.duration
                    if (d > 0) vm.saveProgress(currentItem, d, d)
                    if (index < items.size - 1) index++ else overlayTick++
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
        }
        player.addListener(listener)
        onDispose {
            saveNow()
            player.removeListener(listener)
            player.release()
        }
    }

    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(showPanel) {
        if (!showPanel) {
            delay(50)
            runCatching { focus.requestFocus() }
        }
    }
    BackHandler(onBack = onBack)
    // Déclaré après : quand le panneau est ouvert, « Retour » le ferme seulement
    BackHandler(enabled = showPanel) { showPanel = false }

    fun zap(delta: Int) {
        if (items.isEmpty()) return
        index = (index + delta + items.size) % items.size
    }

    fun seekBy(ms: Long) {
        val d = player.duration
        val target = (player.currentPosition + ms).coerceAtLeast(0L)
        player.seekTo(if (d > 0) target.coerceAtMost(d - 1_000) else target)
        position = player.currentPosition
        overlayTick++
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
        overlayTick++
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                // Panneau ouvert : les flèches servent à naviguer dedans
                if (showPanel) return@onKeyEvent false
                val code = e.nativeKeyEvent.keyCode
                if (e.key == Key.Menu || code == KeyEvent.KEYCODE_SETTINGS ||
                    code == KeyEvent.KEYCODE_CAPTIONS || code == KeyEvent.KEYCODE_INFO
                ) {
                    showPanel = true
                    return@onKeyEvent true
                }
                if (isLive) {
                    when {
                        e.key == Key.DirectionLeft || e.key == Key.DirectionRight -> { showPanel = true; true }
                        e.key == Key.DirectionUp || e.key == Key.ChannelUp -> { zap(-1); true }
                        e.key == Key.DirectionDown || e.key == Key.ChannelDown -> { zap(1); true }
                        e.key == Key.DirectionCenter || e.key == Key.Enter -> { overlayTick++; true }
                        code in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                            if (digits.length < 4) digits += (code - KeyEvent.KEYCODE_0).toString()
                            true
                        }
                        else -> false
                    }
                } else {
                    when {
                        e.key == Key.DirectionLeft || code == KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); true }
                        e.key == Key.DirectionRight || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(30_000); true }
                        e.key == Key.DirectionCenter || e.key == Key.Enter ||
                            code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); true }
                        e.key == Key.DirectionUp -> { overlayTick++; true }
                        e.key == Key.DirectionDown -> { showPanel = true; true }
                        code == KeyEvent.KEYCODE_MEDIA_NEXT && index < items.size - 1 -> { index++; true }
                        code == KeyEvent.KEYCODE_MEDIA_PREVIOUS && index > 0 -> { index--; true }
                        else -> false
                    }
                }
            }
            .focusable()
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    isFocusable = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                }
            },
            update = { it.resizeMode = resizeMode },
            modifier = Modifier.fillMaxSize()
        )

        if (buffering && error == null) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                IrProIcon(56.dp)
                Spacer(Modifier.height(12.dp))
                Text("Chargement…", color = Color(0xFFCCCCCC), fontSize = 18.sp)
            }
        }

        error?.let {
            Text(
                it + if (isLive) "\n\n▲ ▼ pour changer de chaîne" else "\n\nRetour pour revenir",
                color = Color.White,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }

        if (digits.isNotEmpty()) {
            Text(
                digits,
                color = Color.White,
                fontSize = 52.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(36.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 22.dp, vertical = 8.dp)
            )
        }

        if (showPanel) {
            SettingsPanel(
                player = player,
                tracksVersion = tracksVersion,
                resizeMode = resizeMode,
                onResize = { resizeMode = it },
                sleepMin = sleepMin,
                onSleep = { sleepMin = it },
                modifier = Modifier.align(Alignment.CenterEnd)
            )
        }

        if (showOverlay && !showPanel) {
            if (isLive) {
                LiveOverlay(vm, item, index + 1, Modifier.align(Alignment.BottomCenter))
            } else {
                VodOverlay(
                    item, playing, position, duration,
                    hasNext = index < items.size - 1,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
private fun LiveOverlay(vm: AppViewModel, item: Playable, number: Int, modifier: Modifier) {
    val (now, next) = vm.nowNext(item.channel)
    val nowSec = System.currentTimeMillis() / 1000
    Row(
        modifier
            .fillMaxWidth()
            .background(Color(0xE608090B))
            .padding(horizontal = 44.dp, vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$number", color = PurpleLight, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(24.dp))
        item.channel?.let { ChannelLogo(it, 72) }
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text(
                    "${hhmm(now.start)} – ${hhmm(now.end)}  ·  ${now.title}",
                    color = PurpleLight, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.7f), Color.White)
                if (next != null) {
                    Spacer(Modifier.height(4.dp))
                    Text("Ensuite ${hhmm(next.start)} : ${next.title}", color = TextSoft, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            } else {
                Text(item.subtitle, color = Color(0xFFBBBBBB), fontSize = 15.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.width(20.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill("● EN DIRECT", LiveRed, Color.White)
            Spacer(Modifier.height(8.dp))
            Text("▲ ▼ zapper  ·  chiffres  ·  OK infos", color = TextSoft, fontSize = 13.sp)
        }
    }
}

@Composable
private fun VodOverlay(
    item: Playable,
    playing: Boolean,
    position: Long,
    duration: Long,
    hasNext: Boolean,
    modifier: Modifier
) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Color(0xE608090B))
            .padding(horizontal = 44.dp, vertical = 22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.subtitle, color = PurpleLight, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                "◀ −10 s   OK lecture/pause   +30 s ▶" + if (hasNext) "   ⏭ épisode suivant" else "",
                color = TextSoft, fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(timeText(position), color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.width(14.dp))
            ProgressLine(
                if (duration > 0) position.toFloat() / duration else 0f,
                Modifier.weight(1f),
                PurpleMid
            )
            Spacer(Modifier.width(14.dp))
            Text(timeText(duration), color = Color.White, fontSize = 14.sp)
        }
    }
}

// =====================================================================
// PANNEAU : audio, sous-titres, format d'image
// =====================================================================

private class TrackOption(
    val label: String,
    val group: TrackGroup?,
    val index: Int,
    val selected: Boolean
)

private fun languageName(code: String?): String? {
    if (code.isNullOrBlank() || code == "und") return null
    return runCatching {
        Locale(code).getDisplayLanguage(Locale.FRANCE).replaceFirstChar { it.uppercase() }
    }.getOrNull()?.takeIf { it.isNotBlank() }
}

private fun audioDetails(f: Format): String {
    val codec = when (f.sampleMimeType) {
        MimeTypes.AUDIO_AC3 -> "Dolby Digital"
        MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "Dolby Digital+"
        MimeTypes.AUDIO_TRUEHD -> "Dolby TrueHD"
        MimeTypes.AUDIO_DTS, MimeTypes.AUDIO_DTS_HD, MimeTypes.AUDIO_DTS_EXPRESS -> "DTS"
        MimeTypes.AUDIO_AAC -> "AAC"
        MimeTypes.AUDIO_MPEG, MimeTypes.AUDIO_MPEG_L2 -> "MP3"
        MimeTypes.AUDIO_OPUS -> "Opus"
        else -> null
    }
    val ch = when (f.channelCount) {
        1 -> "Mono"
        2 -> "Stéréo"
        6 -> "5.1"
        8 -> "7.1"
        Format.NO_VALUE -> null
        else -> "${f.channelCount} canaux"
    }
    return listOfNotNull(codec, ch).joinToString(" · ")
}

private fun optionsFor(player: Player, type: Int): List<TrackOption> {
    val out = ArrayList<TrackOption>()
    var n = 1
    for (g in player.currentTracks.groups) {
        if (g.type != type) continue
        for (i in 0 until g.length) {
            if (!g.isTrackSupported(i)) continue
            val f = g.getTrackFormat(i)
            val name = f.label ?: languageName(f.language) ?: "Piste $n"
            val details = if (type == C.TRACK_TYPE_AUDIO) audioDetails(f) else ""
            out += TrackOption(
                if (details.isBlank()) name else "$name  ($details)",
                g.mediaTrackGroup, i, g.isTrackSelected(i)
            )
            n++
        }
    }
    return out
}

@Composable
private fun PanelItem(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    FocusBox(onClick = onClick, focusScale = 1.02f, shape = RoundedCornerShape(10.dp), modifier = modifier.fillMaxWidth()) { f ->
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (selected) "●" else "○",
                color = if (selected || f) Color.White else TextSoft,
                fontSize = 14.sp,
                modifier = Modifier.width(24.dp)
            )
            Text(text, color = if (selected || f) Color.White else TextSoft, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PanelTitle(text: String) {
    Text(
        text,
        color = PurpleLight,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 6.dp, top = 14.dp, bottom = 6.dp)
    )
}

@OptIn(UnstableApi::class)
@Composable
private fun SettingsPanel(
    player: Player,
    tracksVersion: Int,
    resizeMode: Int,
    onResize: (Int) -> Unit,
    sleepMin: Int,
    onSleep: (Int) -> Unit,
    modifier: Modifier
) {
    val audio = remember(tracksVersion) { optionsFor(player, C.TRACK_TYPE_AUDIO) }
    val subs = remember(tracksVersion) { optionsFor(player, C.TRACK_TYPE_TEXT) }
    val textDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) ||
        subs.none { it.selected }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(60)
        runCatching { first.requestFocus() }
    }

    fun select(type: Int, o: TrackOption) {
        val g = o.group ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(TrackSelectionOverride(g, o.index))
            .build()
    }

    LazyColumn(
        modifier
            .width(400.dp)
            .fillMaxHeight()
            .background(Color(0xF20F1115))
            .padding(20.dp)
    ) {
        item {
            Text("Réglages de lecture", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Retour pour fermer", color = TextSoft, fontSize = 13.sp)
        }

        item { PanelTitle("FORMAT D'IMAGE") }
        val formats = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "Ajusté (image entière)",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "Plein écran (étiré)",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom (rogné)"
        )
        items(formats.size) { i ->
            val (mode, label) = formats[i]
            PanelItem(
                label, resizeMode == mode, { onResize(mode) },
                if (i == 0) Modifier.focusRequester(first) else Modifier
            )
        }

        item { PanelTitle("MISE EN VEILLE") }
        val sleeps = listOf(0 to "Désactivée", 30 to "Dans 30 min", 60 to "Dans 1 h", 120 to "Dans 2 h")
        items(sleeps.size) { i ->
            val (m, label) = sleeps[i]
            PanelItem(label, sleepMin == m, { onSleep(m) })
        }

        item { PanelTitle("AUDIO") }
        if (audio.isEmpty()) {
            item { Text("Piste unique", color = TextSoft, fontSize = 14.sp, modifier = Modifier.padding(6.dp)) }
        }
        items(audio.size) { i ->
            val o = audio[i]
            PanelItem(o.label, o.selected, { select(C.TRACK_TYPE_AUDIO, o) })
        }

        item { PanelTitle("SOUS-TITRES") }
        item {
            PanelItem("Désactivés", textDisabled, {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
            })
        }
        items(subs.size) { i ->
            val o = subs[i]
            PanelItem(o.label, o.selected && !textDisabled, { select(C.TRACK_TYPE_TEXT, o) })
        }
    }
}
