package com.example.m3uplayer

import android.app.Activity
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward30
import androidx.compose.material.icons.filled.Settings
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.ui.AspectRatioFrameLayout
import java.util.Locale

private fun timeText(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppViewModel, initialItems: List<Playable>, startIndex: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    // La liste peut changer quand on choisit une chaîne d'un autre bouquet
    var items by remember { mutableStateOf(initialItems) }
    var index by remember { mutableIntStateOf(startIndex.coerceIn(0, (initialItems.size - 1).coerceAtLeast(0))) }
    var showChannels by remember { mutableStateOf(false) }
    // Commandes des films / séries : bouton lecture et barre de progression
    val playFocus = remember { FocusRequester() }
    val barFocus = remember { FocusRequester() }
    var focusBar by remember { mutableStateOf(false) }
    val item = items[index]
    val isLive = item.isLive

    var error by remember { mutableStateOf<String?>(null) }
    var buffering by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var overlayTick by remember { mutableIntStateOf(0) }
    var showOverlay by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    // Un seul lecteur pour toute la séance : zapping et épisodes suivants instantanés
    val player = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("IRPRO/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(20_000)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 1_000, 2_500)
            .build()
        // Décodeurs de la box en priorité, FFmpeg en secours pour tous les formats audio
        val renderers = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        ExoPlayer.Builder(context, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(context, http)))
            .setLoadControl(loadControl)
            .build()
            .apply {
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setPreferredAudioLanguage("fr")
                    .setPreferredTextLanguage("fr")
                    .build()
            }
    }

    var showPanel by remember { mutableStateOf(false) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var tracksVersion by remember { mutableIntStateOf(0) }
    var retries by remember { mutableIntStateOf(0) }
    var sleepMin by remember { mutableIntStateOf(0) }

    // Minuterie de mise en veille : met en pause et quitte le lecteur
    LaunchedEffect(sleepMin) {
        if (sleepMin > 0) {
            delay(sleepMin * 60_000L)
            player.pause()
            onBack()
        }
    }

    val currentItem by rememberUpdatedState(item)

    fun saveNow() {
        val d = player.duration
        if (!currentItem.isLive && d != C.TIME_UNSET && d > 0) {
            vm.saveProgress(currentItem, player.currentPosition, d)
        }
    }

    // Lancement de chaque élément (avec reprise pour films / épisodes)
    LaunchedEffect(items, index) {
        error = null
        retries = 0
        position = 0L
        duration = 0L
        player.setMediaItem(MediaItem.fromUri(item.url))
        val resumeAt = if (item.isLive) 0L else vm.savedPosition(item.key)
        if (resumeAt > 0) player.seekTo(resumeAt)
        player.prepare()
        player.playWhenReady = true
        item.channel?.let {
            vm.loadEpg(it)
            vm.rememberLastChannel(it)
        }
        overlayTick++
    }

    // Bandeau visible 4 s après chaque action
    LaunchedEffect(overlayTick) {
        showOverlay = true
        delay(4_000)
        if (player.isPlaying || isLive) showOverlay = false
    }

    // Position + sauvegarde régulière de la progression
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            delay(1_000)
            position = player.currentPosition
            val d = player.duration
            duration = if (d == C.TIME_UNSET || d < 0) 0L else d
            if (++tick % 10 == 0) saveNow()
        }
    }

    // Saisie d'un numéro de chaîne
    LaunchedEffect(digits) {
        if (digits.isEmpty()) return@LaunchedEffect
        delay(1_500)
        val n = digits.toIntOrNull()
        if (n != null && n in 1..items.size) index = n - 1
        digits = ""
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                // Direct trop en retard : on revient au direct sans rien afficher
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                // Coupure réseau : jusqu'à 3 reconnexions automatiques
                val network = e.errorCode in 2000..2999
                if (network && retries < 3) {
                    retries++
                    error = null
                    buffering = true
                    player.prepare()
                    player.playWhenReady = true
                    return
                }
                error = "Impossible de lire cette vidéo.\n(${e.errorCodeName})"
            }

            override fun onTracksChanged(tracks: Tracks) {
                tracksVersion++
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && !currentItem.isLive) {
                    // Fin : on note comme vu, puis épisode suivant s'il y en a un
                    val d = player.duration
                    if (d > 0) vm.saveProgress(currentItem, d, d)
                    if (index < items.size - 1) index++ else overlayTick++
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
        }
        player.addListener(listener)
        onDispose {
            saveNow()
            player.removeListener(listener)
            player.release()
        }
    }

    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(showPanel, showChannels, showOverlay) {
        if (!showPanel && !showChannels) {
            delay(60)
            runCatching {
                when {
                    // Commandes visibles : focus sur la barre ou sur Lecture
                    showOverlay && !isLive -> (if (focusBar) barFocus else playFocus).requestFocus()
                    else -> focus.requestFocus()
                }
            }
        }
    }
    BackHandler(onBack = onBack)
    // Retour cache d'abord les commandes du film, puis quitte au 2e appui
    BackHandler(enabled = showOverlay && !isLive) { showOverlay = false }
    // Déclaré après : quand le panneau est ouvert, « Retour » le ferme seulement
    BackHandler(enabled = showPanel) { showPanel = false }
    BackHandler(enabled = showChannels) { showChannels = false }

    fun zap(delta: Int) {
        if (items.isEmpty()) return
        index = (index + delta + items.size) % items.size
    }

    fun seekBy(ms: Long) {
        val d = player.duration
        val target = (player.currentPosition + ms).coerceAtLeast(0L)
        player.seekTo(if (d > 0) target.coerceAtMost(d - 1_000) else target)
        position = player.currentPosition
        overlayTick++
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
        overlayTick++
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .onPreviewKeyEvent { e ->
                if (!isLive && showOverlay && e.type == KeyEventType.KeyDown) overlayTick++
                false
            }
            .pointerInput(isLive) { detectTapGestures { focusBar = false; overlayTick++ } }
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                // Panneau ou liste ouverts : les flèches servent à naviguer dedans
                if (showPanel || showChannels) return@onKeyEvent false
                val code = e.nativeKeyEvent.keyCode
                if (e.key == Key.Menu || code == KeyEvent.KEYCODE_SETTINGS ||
                    code == KeyEvent.KEYCODE_CAPTIONS || code == KeyEvent.KEYCODE_INFO
                ) {
                    showPanel = true
                    return@onKeyEvent true
                }
                if (isLive) {
                    when {
                        e.key == Key.DirectionLeft || e.key == Key.DirectionRight -> { showPanel = true; true }
                        e.key == Key.DirectionUp || e.key == Key.ChannelUp -> { zap(-1); true }
                        e.key == Key.DirectionDown || e.key == Key.ChannelDown -> { zap(1); true }
                        // OK : liste des chaînes et des bouquets
                        e.key == Key.DirectionCenter || e.key == Key.Enter -> { showChannels = true; true }
                        code in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                            if (digits.length < 4) digits += (code - KeyEvent.KEYCODE_0).toString()
                            true
                        }
                        else -> false
                    }
                } else if (showOverlay) {
                    // Commandes affichées : les flèches et OK servent aux boutons et à la barre
                    when {
                        code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); true }
                        code == KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); true }
                        code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(30_000); true }
                        code == KeyEvent.KEYCODE_MEDIA_NEXT && index < items.size - 1 -> { index++; true }
                        code == KeyEvent.KEYCODE_MEDIA_PREVIOUS && index > 0 -> { index--; true }
                        else -> false
                    }
                } else {
                    when {
                        e.key == Key.DirectionLeft || code == KeyEvent.KEYCODE_MEDIA_REWIND -> { focusBar = true; seekBy(-10_000); true }
                        e.key == Key.DirectionRight || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { focusBar = true; seekBy(30_000); true }
                        code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); true }
                        e.key == Key.DirectionCenter || e.key == Key.Enter ||
                            e.key == Key.DirectionUp || e.key == Key.DirectionDown -> { focusBar = false; overlayTick++; true }
                        code == KeyEvent.KEYCODE_MEDIA_NEXT && index < items.size - 1 -> { index++; true }
                        code == KeyEvent.KEYCODE_MEDIA_PREVIOUS && index > 0 -> { index--; true }
                        else -> false
                    }
                }
            }
            .focusable()
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    isFocusable = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                }
            },
            update = { it.resizeMode = resizeMode },
            modifier = Modifier.fillMaxSize()
        )

        if (buffering && error == null) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                IrProIcon(56.dp)
                Spacer(Modifier.height(12.dp))
                Text("Chargement…", color = Color(0xFFCCCCCC), fontSize = 18.sp)
            }
        }

        error?.let {
            Text(
                it + if (isLive) "\n\n▲ ▼ pour changer de chaîne" else "\n\nRetour pour revenir",
                color = Color.White,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }

        if (digits.isNotEmpty()) {
            Text(
                digits,
                color = Color.White,
                fontSize = 52.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(36.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 22.dp, vertical = 8.dp)
            )
        }

        if (showPanel) {
            SettingsPanel(
                player = player,
                tracksVersion = tracksVersion,
                resizeMode = resizeMode,
                onResize = { resizeMode = it },
                sleepMin = sleepMin,
                onSleep = { sleepMin = it },
                modifier = Modifier.align(Alignment.CenterEnd)
            )
        }

        if (showChannels) {
            LiveChannelsOverlay(
                vm = vm,
                current = item.channel,
                onPick = { list, i ->
                    items = list.map { vm.playableOf(it) }
                    index = i
                    showChannels = false
                },
                modifier = Modifier.align(Alignment.CenterStart)
            )
        }

        if (showOverlay && !showPanel && !showChannels) {
            if (isLive) {
                LiveOverlay(vm, item, index + 1, Modifier.align(Alignment.BottomCenter))
            } else {
                VodOverlay(
                    item = item,
                    playing = playing,
                    position = position,
                    duration = duration,
                    showEpisodeButtons = items.size > 1,
                    hasPrev = index > 0,
                    hasNext = index < items.size - 1,
                    playFocus = playFocus,
                    barFocus = barFocus,
                    onTogglePlay = { togglePlay() },
                    onSeekTo = { ms ->
                        player.seekTo(ms)
                        position = ms
                        overlayTick++
                    },
                    onBack10 = { seekBy(-10_000) },
                    onFwd30 = { seekBy(30_000) },
                    onPrev = { if (index > 0) index-- },
                    onNext = { if (index < items.size - 1) index++ },
                    onSettings = { showPanel = true },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
private fun LiveOverlay(vm: AppViewModel, item: Playable, number: Int, modifier: Modifier) {
    val (now, next) = vm.nowNext(item.channel)
    val nowSec = System.currentTimeMillis() / 1000
    Row(
        modifier
            .fillMaxWidth()
            .background(Color(0xB308090B))
            .padding(horizontal = 44.dp, vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$number", color = PurpleLight, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(24.dp))
        item.channel?.let { ChannelLogo(it, 72) }
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text(
                    "${hhmm(now.start)} – ${hhmm(now.end)}  ·  ${now.title}",
                    color = PurpleLight, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.7f), Color.White)
                if (next != null) {
                    Spacer(Modifier.height(4.dp))
                    Text("Ensuite ${hhmm(next.start)} : ${next.title}", color = TextSoft, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            } else {
                Text(item.subtitle, color = Color(0xFFBBBBBB), fontSize = 15.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.width(20.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill("● EN DIRECT", LiveRed, Color.White)
            Spacer(Modifier.height(8.dp))
            Text("▲ ▼ zapper  ·  OK liste des chaînes  ·  ◀ ▶ réglages", color = TextSoft, fontSize = 13.sp)
        }
    }
}

@Composable
private fun VodOverlay(
    item: Playable,
    playing: Boolean,
    position: Long,
    duration: Long,
    showEpisodeButtons: Boolean,
    hasPrev: Boolean,
    hasNext: Boolean,
    playFocus: FocusRequester,
    barFocus: FocusRequester,
    onTogglePlay: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onBack10: () -> Unit,
    onFwd30: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier
) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xD9000000), Color(0xF2000000))))
            .padding(start = 44.dp, end = 44.dp, top = 48.dp, bottom = 20.dp)
    ) {
        Text(item.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(item.subtitle, color = PurpleLight, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(12.dp))

        // Barre de progression : flèches ◀ ▶ pour avancer / reculer, OK pour valider
        SeekBar(position, duration, barFocus, onSeekTo)
        Spacer(Modifier.height(14.dp))

        // Boutons
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.Top
        ) {
            if (showEpisodeButtons) {
                CtrlButton(Icons.Filled.SkipPrevious, "Épisode précédent", enabled = hasPrev, onClick = onPrev)
            }
            CtrlButton(Icons.Filled.Replay10, "Reculer 10 s", onClick = onBack10)
            CtrlButton(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                if (playing) "Pause" else "Lecture",
                big = true,
                modifier = Modifier.focusRequester(playFocus),
                onClick = onTogglePlay
            )
            CtrlButton(Icons.Filled.Forward30, "Avancer 30 s", onClick = onFwd30)
            if (showEpisodeButtons) {
                CtrlButton(Icons.Filled.SkipNext, "Épisode suivant", enabled = hasNext, onClick = onNext)
            }
            Spacer(Modifier.width(12.dp))
            CtrlButton(Icons.Filled.Settings, "Audio · sous-titres", onClick = onSettings)
        }
    }
}

/** Bouton rond du lecteur. */
@Composable
private fun CtrlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    big: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val size = if (big) 70.dp else 54.dp
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(96.dp)) {
        Box(
            modifier
                .size(size)
                .graphicsLayer {
                    val sc = if (focused) 1.12f else 1f
                    scaleX = sc
                    scaleY = sc
                }
                .clip(CircleShape)
                .background(
                    when {
                        focused -> Color.White
                        big -> Color(0x55FFFFFF)
                        else -> Color(0x33FFFFFF)
                    }
                )
                .focusProperties { canFocus = enabled }
                .onFocusChanged { focused = it.isFocused }
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon, contentDescription = label,
                tint = when {
                    !enabled -> Color(0x55FFFFFF)
                    focused -> Color.Black
                    else -> Color.White
                },
                modifier = Modifier.size(if (big) 40.dp else 30.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            color = if (focused) Color.White else Color(0x99FFFFFF),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Barre de progression qu'on peut déplacer :
 * - télécommande : ◀ ▶ déplacent le curseur (de plus en plus vite si on reste appuyé),
 *   la vidéo saute à la nouvelle position après un court instant ou avec OK ;
 * - téléphone : on touche la barre à l'endroit voulu.
 */
@Composable
private fun SeekBar(position: Long, duration: Long, focusRequester: FocusRequester, onSeekTo: (Long) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    var scrub by remember { mutableStateOf<Long?>(null) }
    val shown = scrub ?: position

    LaunchedEffect(scrub) {
        val s = scrub ?: return@LaunchedEffect
        delay(900)
        onSeekTo(s)
        scrub = null
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            timeText(shown),
            color = if (scrub != null) PurpleLight else Color.White,
            fontSize = if (scrub != null) 17.sp else 14.sp,
            fontWeight = if (scrub != null) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.width(78.dp)
        )
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .height(34.dp)
                .focusRequester(focusRequester)
                .onFocusChanged { focused = it.isFocused }
                .onKeyEvent { e ->
                    if (e.type != KeyEventType.KeyDown || duration <= 0) return@onKeyEvent false
                    val rep = e.nativeKeyEvent.repeatCount
                    val step = when {
                        rep > 20 -> 120_000L
                        rep > 6 -> 60_000L
                        else -> 10_000L
                    }
                    when (e.key) {
                        Key.DirectionLeft -> { scrub = (shown - step).coerceAtLeast(0L); true }
                        Key.DirectionRight -> { scrub = (shown + step).coerceAtMost((duration - 1_000).coerceAtLeast(0L)); true }
                        Key.DirectionCenter, Key.Enter -> {
                            scrub?.let { onSeekTo(it) }
                            scrub = null
                            true
                        }
                        else -> false
                    }
                }
                .focusable()
                .pointerInput(duration) {
                    detectTapGestures { off ->
                        if (duration > 0 && size.width > 0) {
                            onSeekTo((off.x / size.width * duration).toLong().coerceIn(0L, duration))
                        }
                    }
                },
            contentAlignment = Alignment.CenterStart
        ) {
            val frac = if (duration > 0) (shown.toFloat() / duration).coerceIn(0f, 1f) else 0f
            val barH = if (focused) 8.dp else 5.dp
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(barH)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x40FFFFFF))
            ) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(if (focused) Color.White else PurpleMid))
            }
            val thumb = if (focused) 24.dp else 14.dp
            Box(
                Modifier
                    .offset(x = maxWidth * frac - thumb / 2)
                    .size(thumb)
                    .background(Color.White, CircleShape)
                    .border(if (focused) 3.dp else 0.dp, if (focused) PurpleMid else Color.Transparent, CircleShape)
            )
        }
        Text(
            timeText(duration), color = Color.White, fontSize = 14.sp,
            textAlign = TextAlign.End, modifier = Modifier.width(78.dp)
        )
    }
    if (focused) {
        Text(
            "◀ ▶ pour avancer ou reculer · reste appuyé pour aller plus vite",
            color = Color(0x99FFFFFF), fontSize = 11.sp,
            modifier = Modifier.padding(start = 78.dp, top = 2.dp)
        )
    }
}

@Composable
private fun PanelItem(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    FocusBox(onClick = onClick, focusScale = 1.02f, shape = RoundedCornerShape(10.dp), modifier = modifier.fillMaxWidth()) { f ->
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (selected) "●" else "○",
                color = if (selected || f) Color.White else TextSoft,
                fontSize = 14.sp,
                modifier = Modifier.width(24.dp)
            )
            Text(text, color = if (selected || f) Color.White else TextSoft, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PanelTitle(text: String) {
    Text(
        text,
        color = PurpleLight,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 6.dp, top = 14.dp, bottom = 6.dp)
    )
}

@OptIn(UnstableApi::class)
@Composable
private fun SettingsPanel(
    player: Player,
    tracksVersion: Int,
    resizeMode: Int,
    onResize: (Int) -> Unit,
    sleepMin: Int,
    onSleep: (Int) -> Unit,
    modifier: Modifier
) {
    val audio = remember(tracksVersion) { optionsFor(player, C.TRACK_TYPE_AUDIO) }
    val subs = remember(tracksVersion) { optionsFor(player, C.TRACK_TYPE_TEXT) }
    val textDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) ||
        subs.none { it.selected }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(60)
        runCatching { first.requestFocus() }
    }

    fun select(type: Int, o: TrackOption) {
        val g = o.group ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(TrackSelectionOverride(g, o.index))
            .build()
    }

    LazyColumn(
        modifier
            .width(400.dp)
            .fillMaxHeight()
            .background(Color(0xCC0F1115))
            .padding(20.dp)
    ) {
        item {
            Text("Réglages de lecture", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Retour pour fermer", color = TextSoft, fontSize = 13.sp)
        }

        item { PanelTitle("FORMAT D'IMAGE") }
        val formats = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "Ajusté (image entière)",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "Plein écran (étiré)",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom (rogné)"
        )
        items(formats.size) { i ->
            val (mode, label) = formats[i]
            PanelItem(
                label, resizeMode == mode, { onResize(mode) },
                if (i == 0) Modifier.focusRequester(first) else Modifier
            )
        }

        item { PanelTitle("MISE EN VEILLE") }
        val sleeps = listOf(0 to "Désactivée", 30 to "Dans 30 min", 60 to "Dans 1 h", 120 to "Dans 2 h")
        items(sleeps.size) { i ->
            val (m, label) = sleeps[i]
            PanelItem(label, sleepMin == m, { onSleep(m) })
        }

        item { PanelTitle("AUDIO") }
        if (audio.isEmpty()) {
            item { Text("Piste unique", color = TextSoft, fontSize = 14.sp, modifier = Modifier.padding(6.dp)) }
        }
        items(audio.size) { i ->
            val o = audio[i]
            PanelItem(o.label, o.selected, { select(C.TRACK_TYPE_AUDIO, o) })
        }

        item { PanelTitle("SOUS-TITRES") }
        item {
            PanelItem("Désactivés", textDisabled, {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
            })
        }
        items(subs.size) { i ->
            val o = subs[i]
            PanelItem(o.label, o.selected && !textDisabled, { select(C.TRACK_TYPE_TEXT, o) })
        }
    }
}


// =====================================================================
// LISTE DES CHAÎNES ET BOUQUETS (touche OK pendant le direct)
// =====================================================================

@Composable
private fun LiveChannelsOverlay(
    vm: AppViewModel,
    current: Channel?,
    onPick: (List<Channel>, Int) -> Unit,
    modifier: Modifier
) {
    val all = vm.channels
    val favs = vm.favorites
    val groups = remember(all) { listOf("Favoris") + all.map { it.group }.distinct() }
    var group by remember { mutableStateOf(current?.group ?: groups.getOrElse(1) { "Favoris" }) }
    val list = remember(all, group, favs) {
        if (group == "Favoris") all.filter { it.favKey in favs } else all.filter { it.group == group }
    }
    val startIdx = remember { list.indexOfFirst { it.url == current?.url }.coerceAtLeast(0) }
    val chState = rememberLazyListState(initialFirstVisibleItemIndex = startIdx)
    val grState = rememberLazyListState(initialFirstVisibleItemIndex = groups.indexOf(group).coerceAtLeast(0))
    val currentFocus = remember { FocusRequester() }
    var infoCh by remember { mutableStateOf(current) }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { currentFocus.requestFocus() }
    }
    LaunchedEffect(infoCh) { vm.loadEpg(infoCh) }
    val nowSec = System.currentTimeMillis() / 1000

    Row(
        modifier
            .fillMaxHeight()
            .background(Color(0x33000000))
    ) {
        // Bouquets
        LazyColumn(
            state = grState,
            modifier = Modifier.width(210.dp).fillMaxHeight().background(Color(0x8C0B0D10)),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            item {
                Text("Bouquets", color = PurpleLight, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
            }
            items(groups.size) { gi ->
                val g = groups[gi]
                FocusBox(
                    onClick = { group = g },
                    onFocused = { group = g },
                    selected = g == group,
                    focusScale = 1.02f,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { f ->
                    Text(
                        g, color = if (f || g == group) Color.White else TextSoft, fontSize = 15.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    )
                }
            }
        }
        // Chaînes du bouquet
        LazyColumn(
            state = chState,
            modifier = Modifier.width(370.dp).fillMaxHeight(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            item {
                Text(
                    "$group · ${list.size} chaîne(s)", color = PurpleLight, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(6.dp)
                )
            }
            if (list.isEmpty()) {
                item { Text("Aucune chaîne ici.", color = TextSoft, modifier = Modifier.padding(8.dp)) }
            }
            items(list.size) { i ->
                val c = list[i]
                val isCurrent = c.url == current?.url
                val (now, _) = vm.nowNext(c)
                FocusBox(
                    onClick = { onPick(list, i) },
                    onFocused = { infoCh = c; vm.loadEpg(c) },
                    selected = isCurrent,
                    focusScale = 1.02f,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (isCurrent || (i == 0 && startIdx == 0 && current?.group != group)) Modifier.focusRequester(currentFocus) else Modifier)
                ) { f ->
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", color = if (f) Color.White else TextSoft, fontSize = 13.sp, modifier = Modifier.width(36.dp))
                        ChannelLogo(c, 36)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (isCurrent) "▶ " else "") + c.name,
                                color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            if (now != null) {
                                Text(now.title, color = if (f) Color.White else PurpleLight, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(3.dp))
                                ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.8f), if (f) Color.White else PurpleMid)
                            }
                        }
                    }
                }
            }
        }
        // Infos de la chaîne sélectionnée : programme en cours et suivant
        ChannelInfoPanel(vm, infoCh, nowSec)
    }
}

@Composable
private fun ChannelInfoPanel(vm: AppViewModel, c: Channel?, nowSec: Long) {
    Column(
        Modifier
            .width(330.dp)
            .fillMaxHeight()
            .background(Color(0x990B0D10))
            .padding(18.dp)
    ) {
        if (c == null) return@Column
        Row(verticalAlignment = Alignment.CenterVertically) {
            ChannelLogo(c, 56)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(c.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(c.group, color = PurpleLight, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(16.dp))
        val list = c.streamId?.let { vm.epg[it] }
        when {
            vm.account == null -> Text("Guide TV disponible avec un compte Xtream.", color = TextSoft, fontSize = 13.sp)
            list == null -> Text("Chargement du guide TV…", color = TextSoft, fontSize = 13.sp)
            list.isEmpty() -> Text("Pas de guide TV pour cette chaîne.", color = TextSoft, fontSize = 13.sp)
            else -> {
                val (now, next) = vm.nowNext(c)
                if (now != null) {
                    Text("MAINTENANT", color = PurpleLight, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("${hhmm(now.start)} – ${hhmm(now.end)}", color = TextSoft, fontSize = 12.sp)
                    Text(now.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth())
                    if (now.desc.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(now.desc, color = Color(0xFFCCCCCC), fontSize = 12.sp, lineHeight = 17.sp, maxLines = 6, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (next != null) {
                    Spacer(Modifier.height(16.dp))
                    Text("ENSUITE", color = TextSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("${hhmm(next.start)} – ${hhmm(next.end)}", color = TextSoft, fontSize = 12.sp)
                    Text(next.title, color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                val later = list.filter { it.start > (next?.start ?: nowSec) }.take(2)
                later.forEach { e ->
                    Spacer(Modifier.height(10.dp))
                    Text("${hhmm(e.start)}  ${e.title}", color = TextSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
