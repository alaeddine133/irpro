package com.example.m3uplayer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun updateText(vm: AppViewModel): String = when {
    vm.loading -> "Mise à jour…"
    vm.lastUpdate > 0 -> "Mis à jour à " + SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(vm.lastUpdate))
    else -> "Actualiser"
}

/** Bouton pour mettre à jour chaînes, films et séries à la demande. */
@Composable
fun RefreshButton(vm: AppViewModel, compact: Boolean = false, modifier: Modifier = Modifier) {
    FocusBox(
        onClick = { if (!vm.loading) vm.refresh() },
        focusScale = if (compact) 1f else 1.04f,
        selected = !compact,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) { f ->
        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.Refresh,
                contentDescription = "Actualiser les contenus",
                tint = when {
                    f -> Color.White
                    vm.loading -> PurpleLight
                    else -> TextSoft
                },
                modifier = Modifier.size(24.dp)
            )
            if (!compact) {
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Actualiser", color = TextMain, fontSize = 15.sp, maxLines = 1)
                    Text(updateText(vm), color = if (f) TextMain else TextSoft, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

// =====================================================================
// STYLE CLASSIQUE : grand menu à tuiles
// =====================================================================

@Composable
fun ClassicLayout(vm: AppViewModel, tab: Tab, onTab: (Tab) -> Unit, nav: Nav) {
    if (tab == Tab.HOME) {
        if (!vm.hasSource) TabContent(vm, Tab.HOME, nav) else ClassicHome(vm, onTab)
    } else {
        // Retour : on revient au menu à tuiles
        BackHandler { onTab(Tab.HOME) }
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 24.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IrProIcon(32.dp)
                Spacer(Modifier.width(14.dp))
                Text(tab.label, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("Retour : menu principal", color = TextSoft, fontSize = 13.sp)
                Spacer(Modifier.width(16.dp))
                RefreshButton(vm)
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { TabContent(vm, tab, nav) }
        }
    }
}

@Composable
private fun ClassicHome(vm: AppViewModel, onTab: (Tab) -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(120)
        runCatching { first.requestFocus() }
    }
    val clock = SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date())

    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IrProIcon(48.dp)
            Spacer(Modifier.width(14.dp))
            IrProWordmark(30.sp)
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Text(clock, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                vm.expiry?.let { Text("Abonnement jusqu'au $it", color = TextSoft, fontSize = 12.sp) }
            }
            Spacer(Modifier.width(18.dp))
            RefreshButton(vm)
        }
        Spacer(Modifier.height(20.dp))

        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            BigTile(
                Tab.LIVE.icon, "TV en direct", "${vm.channels.size} chaînes",
                onClick = { onTab(Tab.LIVE) },
                modifier = Modifier.weight(1.2f).fillMaxHeight().focusRequester(first),
                highlight = true
            )
            Column(Modifier.weight(2f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    BigTile(Tab.MOVIES.icon, "Films", "${vm.movies.size} titres", { onTab(Tab.MOVIES) }, Modifier.weight(1f).fillMaxHeight())
                    BigTile(Tab.SERIES.icon, "Séries", "${vm.series.size} séries", { onTab(Tab.SERIES) }, Modifier.weight(1f).fillMaxHeight())
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    BigTile(Tab.GUIDE.icon, "Guide TV", "Programmes", { onTab(Tab.GUIDE) }, Modifier.weight(1f).fillMaxHeight())
                    BigTile(Tab.FAVS.icon, "Favoris", "${vm.favorites.size} favori(s)", { onTab(Tab.FAVS) }, Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            SmallTile(Tab.SEARCH.icon, "Recherche") { onTab(Tab.SEARCH) }
            SmallTile(Tab.SETTINGS.icon, "Paramètres") { onTab(Tab.SETTINGS) }
        }
    }
}

@Composable
private fun BigTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    FocusBox(onClick = onClick, selected = true, focusScale = 1.03f, shape = RoundedCornerShape(20.dp), modifier = modifier) { f ->
        Column(
            Modifier
                .fillMaxSize()
                .background(if (highlight && !f) PurpleDark else Color.Transparent),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, null, tint = if (f) Color.White else PurpleLight, modifier = Modifier.size(if (highlight) 64.dp else 44.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, color = Color.White, fontSize = if (highlight) 28.sp else 22.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = if (f) Color.White else TextSoft, fontSize = 14.sp)
        }
    }
}

@Composable
private fun SmallTile(icon: ImageVector, title: String, onClick: () -> Unit) {
    FocusBox(onClick = onClick, selected = true, focusScale = 1.04f, shape = RoundedCornerShape(26.dp)) { f ->
        Row(Modifier.padding(horizontal = 20.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (f) Color.White else PurpleLight, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, color = TextMain, fontSize = 16.sp)
        }
    }
}

// =====================================================================
// STYLE MOSAÏQUE : menu en haut + chaînes en grandes cases
// =====================================================================

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun MosaicLayout(vm: AppViewModel, tab: Tab, onTab: (Tab) -> Unit, nav: Nav) {
    val tabs = listOf(Tab.HOME, Tab.LIVE, Tab.GUIDE, Tab.MOVIES, Tab.SERIES, Tab.FAVS, Tab.SEARCH, Tab.SETTINGS)
    val requesters = remember { tabs.associateWith { FocusRequester() } }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { requesters[tab]?.requestFocus() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel)
                .padding(horizontal = 18.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IrProIcon(34.dp)
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
                    .focusProperties { enter = { requesters[tab] ?: FocusRequester.Default } }
                    .focusGroup(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                tabs.forEach { t ->
                    FocusBox(
                        onClick = { onTab(t) },
                        onFocused = { onTab(t) },
                        selected = t == tab,
                        focusScale = 1.04f,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.focusRequester(requesters.getValue(t))
                    ) { f ->
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(t.icon, null, tint = if (f || t == tab) Color.White else TextSoft, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(t.label, color = if (f || t == tab) TextMain else TextSoft, fontSize = 14.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            RefreshButton(vm, compact = true)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == Tab.LIVE && vm.hasSource) MosaicLiveScreen(vm, nav) else TabContent(vm, tab, nav)
        }
    }
}

@Composable
private fun MosaicLiveScreen(vm: AppViewModel, nav: Nav) {
    val channels = vm.channels
    val favorites = vm.favorites
    val groups = remember(channels) { listOf("Toutes", "Favoris") + channels.map { it.group }.distinct() }
    var group by rememberSaveable { mutableStateOf("Toutes") }
    val list = remember(channels, group, favorites) {
        when (group) {
            "Toutes" -> channels
            "Favoris" -> channels.filter { it.favKey in favorites }
            else -> channels.filter { it.group == group }
        }
    }
    val nowSec = System.currentTimeMillis() / 1000

    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(groups) { g ->
                FocusBox(onClick = { group = g }, selected = g == group, focusScale = 1.04f, shape = RoundedCornerShape(20.dp)) { f ->
                    Text(
                        g, color = if (f || g == group) TextMain else TextSoft, fontSize = 14.sp, maxLines = 1,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
        }
        if (list.isEmpty()) {
            EmptyMessage(if (group == "Favoris") "Aucune chaîne favorite pour l'instant." else "Aucune chaîne ici.")
            return@Column
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 6.dp, bottom = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(list) { i, c ->
                val (now, _) = vm.nowNext(c)
                FocusBox(
                    onClick = { nav.play(list.map { vm.playableOf(it) }, i) },
                    onFocused = { vm.loadEpg(c) },
                    selected = true,
                    focusScale = 1.07f,
                    shape = RoundedCornerShape(16.dp)
                ) { f ->
                    Column(
                        Modifier.fillMaxWidth().height(150.dp).padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        ChannelLogo(c, 58)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            c.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                        )
                        Text(
                            now?.title ?: "${i + 1}", color = if (f) Color.White else TextSoft, fontSize = 11.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                        )
                        if (now != null) {
                            Spacer(Modifier.height(5.dp))
                            ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.85f), if (f) Color.White else PurpleMid)
                        }
                    }
                }
            }
        }
    }
}
