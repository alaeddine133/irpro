package com.example.m3uplayer

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")
    private const val DEFAULT_GROUP = "Autres"

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name: String? = null
        var logo: String? = null
        var group = DEFAULT_GROUP

        text.lineSequence()
            .map { it.trim().removePrefix("﻿") }
            .filter { it.isNotEmpty() }
            .forEach { line ->
                when {
                    line.startsWith("#EXTINF", ignoreCase = true) -> {
                        val attrs = attrRegex.findAll(line)
                            .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                        logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                        group = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: DEFAULT_GROUP
                        name = nameAfterComma(line) ?: attrs["tvg-name"]
                    }
                    line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                        line.substringAfter(':').trim().takeIf { it.isNotBlank() }?.let { group = it }
                    }
                    line.startsWith("#") -> Unit
                    else -> {
                        val finalName = name?.takeIf { it.isNotBlank() }
                            ?: line.substringAfterLast('/').ifBlank { line }
                        out += Channel(finalName, line, logo, group)
                        name = null
                        logo = null
                        group = DEFAULT_GROUP
                    }
                }
            }
        return out
    }

    private fun nameAfterComma(line: String): String? {
        var inQuotes = false
        for (i in line.indices) {
            val c = line[i]
            if (c == '"') inQuotes = !inQuotes
            else if (c == ',' && !inQuotes) return line.substring(i + 1).trim()
        }
        return null
    }
}
