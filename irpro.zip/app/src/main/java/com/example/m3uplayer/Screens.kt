package com.example.m3uplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.lazy.grid.items as gridItems

private val hourFormat = SimpleDateFormat("HH:mm", Locale.FRANCE)
fun hhmm(sec: Long): String = hourFormat.format(Date(sec * 1000))

// =====================================================================
// ACCUEIL
// =====================================================================

@Composable
fun HomeScreen(vm: AppViewModel, nav: Nav) {
    val channels = vm.channels
    val favorites = vm.favorites
    val featured = remember(channels, favorites) {
        channels.firstOrNull { it.favKey in favorites } ?: channels.firstOrNull()
    }
    LaunchedEffect(featured) { vm.loadEpg(featured) }

    val resume = remember(vm.progressVersion) { vm.continueWatching() }
    val favChannels = remember(channels, favorites) { channels.filter { it.favKey in favorites }.take(25) }
    val liveRow = favChannels.ifEmpty { channels.take(25) }
    val recentMovies = remember(vm.movies) { vm.movies.sortedByDescending { it.added }.take(30) }
    val recentSeries = remember(vm.series) { vm.series.sortedByDescending { it.added }.take(30) }
    val prog = remember(vm.progressVersion) { vm.progressMap() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 28.dp, end = 28.dp, top = 24.dp, bottom = 48.dp)
    ) {
        if (vm.updateAvailable) {
            item {
                Text(
                    "Nouvelle version d'IR PRO disponible : ouvre Downloader et tape ton code pour l'installer.",
                    color = Color.White, fontSize = 15.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .background(Purple, RoundedCornerShape(12.dp))
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                )
            }
        }
        if (featured != null) {
            item { Hero(vm, featured, nav, liveRow.ifEmpty { listOf(featured) }) }
        }
        if (resume.isNotEmpty()) {
            item { SectionTitle("Reprendre la lecture") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                    itemsIndexed(resume) { i, (p, f) ->
                        ResumeCard(p, f) { nav.play(resume.map { it.first }, i) }
                    }
                }
            }
        }
        if (liveRow.isNotEmpty()) {
            item { SectionTitle(if (favChannels.isNotEmpty()) "Tes chaînes favorites" else "En direct maintenant") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                    itemsIndexed(liveRow) { i, c ->
                        LiveCard(vm, c) { nav.play(liveRow.map { vm.playableOf(it) }, i) }
                    }
                }
            }
        }
        if (recentMovies.isNotEmpty()) {
            item { SectionTitle("Films ajoutés récemment") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
                    items(recentMovies) { m ->
                        PosterCard(m.name, m.poster, { nav.openMovie(m) }, progress = prog[m.favKey] ?: 0f, badge = m.rating)
                    }
                }
            }
        }
        if (recentSeries.isNotEmpty()) {
            item { SectionTitle("Séries à découvrir") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
                    items(recentSeries) { s ->
                        PosterCard(s.name, s.cover, { nav.openSeries(s) }, badge = s.rating)
                    }
                }
            }
        }
    }
}

@Composable
private fun Hero(vm: AppViewModel, channel: Channel, nav: Nav, list: List<Channel>) {
    val (now, next) = vm.nowNext(channel)
    val nowSec = System.currentTimeMillis() / 1000
    val isFav = channel.favKey in vm.favorites
    Box(
        Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(PurpleDark)
    ) {
        Box(Modifier.align(Alignment.CenterEnd).padding(end = 48.dp)) {
            ChannelLogo(channel, 150)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(32.dp).fillMaxWidth(0.62f)) {
            Pill("● EN DIRECT", LiveRed, Color.White)
            Spacer(Modifier.height(10.dp))
            Text(channel.name, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text(
                    "${hhmm(now.start)} – ${hhmm(now.end)}  ·  ${now.title}",
                    color = PurpleLight, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                ProgressLine(now.progress(nowSec), Modifier.width(320.dp), Color.White)
                if (next != null) {
                    Spacer(Modifier.height(6.dp))
                    Text("Ensuite : ${hhmm(next.start)}  ${next.title}", color = TextSoft, fontSize = 14.sp, maxLines = 1)
                }
            } else {
                Text(channel.group, color = PurpleLight, fontSize = 17.sp)
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                FocusBox(
                    onClick = { nav.play(list.map { vm.playableOf(it) }, list.indexOf(channel).coerceAtLeast(0)) },
                    selected = true,
                    shape = RoundedCornerShape(26.dp)
                ) {
                    Row(Modifier.padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Regarder", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
                FocusBox(
                    onClick = { vm.toggleFavorite(channel.favKey) },
                    selected = true,
                    shape = RoundedCornerShape(26.dp)
                ) {
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (isFav) FavPink else Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isFav) "Dans mes favoris" else "Favori", color = Color.White, fontSize = 17.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ResumeCard(p: Playable, fraction: Float, onClick: () -> Unit) {
    Column(Modifier.width(280.dp)) {
        FocusBox(onClick = onClick, filledWhenFocused = false, focusScale = 1.06f) {
            Box {
                ArtImage(p.image, p.title, Modifier.width(280.dp).height(158.dp))
                Icon(
                    Icons.Filled.PlayArrow, null, tint = Color.White,
                    modifier = Modifier.align(Alignment.Center).size(48.dp)
                        .background(Color(0x88000000), RoundedCornerShape(24.dp)).padding(8.dp)
                )
                ProgressLine(fraction, Modifier.align(Alignment.BottomCenter).fillMaxWidth())
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(p.title, color = TextMain, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(p.subtitle, color = TextSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// =====================================================================
// DIRECT (avec guide TV)
// =====================================================================

private const val ALL = "Toutes les chaînes"
private const val FAVS = "Favoris"

@Composable
fun LiveScreen(vm: AppViewModel, nav: Nav) {
    val channels = vm.channels
    val favorites = vm.favorites
    val groups = remember(channels) { listOf(ALL, FAVS) + channels.map { it.group }.distinct() }
    var group by rememberSaveable { mutableStateOf(ALL) }
    var focused by remember { mutableStateOf<Channel?>(null) }
    val shown = remember(channels, group, favorites) {
        channels.filter {
            when (group) {
                ALL -> true
                FAVS -> it.favKey in favorites
                else -> it.group == group
            }
        }
    }
    val preview = focused ?: shown.firstOrNull()
    LaunchedEffect(preview) { vm.loadEpg(preview) }

    Row(Modifier.fillMaxSize()) {
        // Catégories
        LazyColumn(
            Modifier.width(250.dp).fillMaxHeight().background(Color(0xFF0B0D10)),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(groups) { g ->
                FocusBox(
                    onClick = { group = g },
                    onFocused = { group = g },
                    selected = g == group,
                    focusScale = 1.02f,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { f ->
                    Text(
                        g,
                        color = if (f || g == group) TextMain else TextSoft,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp)
                    )
                }
            }
        }

        // Chaînes
        LazyColumn(
            Modifier.weight(1f).fillMaxHeight(),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (shown.isEmpty()) {
                item {
                    Text(
                        if (group == FAVS) "Aucun favori. Sélectionne le cœur à droite d'une chaîne." else "Aucune chaîne ici.",
                        color = TextSoft, modifier = Modifier.padding(16.dp)
                    )
                }
            }
            itemsIndexed(shown) { i, c ->
                ChannelRow(vm, i + 1, c,
                    onFocus = { focused = c },
                    onPlay = { nav.play(shown.map { vm.playableOf(it) }, i) })
            }
        }

        // Aperçu + guide TV
        LivePreview(vm, preview, nav, Modifier.width(360.dp).fillMaxHeight())
    }
}

@Composable
private fun ChannelRow(vm: AppViewModel, number: Int, c: Channel, onFocus: () -> Unit, onPlay: () -> Unit) {
    val isFav = c.favKey in vm.favorites
    val (now, _) = vm.nowNext(c)
    val nowSec = System.currentTimeMillis() / 1000
    Row(verticalAlignment = Alignment.CenterVertically) {
        FocusBox(onClick = onPlay, onFocused = onFocus, focusScale = 1.02f, modifier = Modifier.weight(1f)) { f ->
            Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("$number", color = if (f) TextMain else TextSoft, fontSize = 15.sp, modifier = Modifier.width(48.dp))
                ChannelLogo(c, 46)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, color = TextMain, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (now != null) {
                        Text(now.title, color = if (f) TextMain else PurpleLight, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.7f), if (f) Color.White else PurpleMid)
                    } else {
                        Text(c.group, color = if (f) TextMain else TextSoft, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        FocusBox(onClick = { vm.toggleFavorite(c.favKey) }, onFocused = onFocus, shape = RoundedCornerShape(28.dp)) { f ->
            Icon(
                if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = if (isFav) "Retirer des favoris" else "Ajouter aux favoris",
                tint = when { f -> Color.White; isFav -> FavPink; else -> TextSoft },
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}

@Composable
private fun LivePreview(vm: AppViewModel, c: Channel?, nav: Nav, modifier: Modifier) {
    Column(modifier.background(Panel).verticalScroll(rememberScrollState()).padding(22.dp)) {
        if (c == null) return@Column
        ChannelLogo(c, 80)
        Spacer(Modifier.height(12.dp))
        Text(c.name, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(c.group, color = PurpleLight, fontSize = 14.sp, maxLines = 1)
        if (c.archiveDays > 0 && vm.account != null) {
            Spacer(Modifier.height(12.dp))
            FocusBox(onClick = { nav.openReplay(c) }, selected = true, shape = RoundedCornerShape(20.dp)) {
                Text(
                    "⟲ Replay · ${c.archiveDays} jour(s)", color = TextMain, fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        val list = c.streamId?.let { vm.epg[it] }
        val nowSec = System.currentTimeMillis() / 1000
        when {
            vm.account == null -> Text("Guide TV disponible avec un compte Xtream.", color = TextSoft, fontSize = 14.sp)
            list == null -> Text("Chargement du guide TV…", color = TextSoft, fontSize = 14.sp)
            list.isEmpty() -> Text("Pas de guide TV pour cette chaîne.", color = TextSoft, fontSize = 14.sp)
            else -> {
                Text("GUIDE TV", color = TextSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                list.take(3).forEach { e ->
                    val isNow = e.isNow(nowSec)
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(if (isNow) CardBg else Color.Transparent, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            (if (isNow) "MAINTENANT  " else "") + "${hhmm(e.start)} – ${hhmm(e.end)}",
                            color = if (isNow) PurpleLight else TextSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold
                        )
                        Text(e.title, color = TextMain, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (isNow) {
                            if (e.desc.isNotBlank()) {
                                Text(e.desc, color = TextSoft, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                            Spacer(Modifier.height(6.dp))
                            ProgressLine(e.progress(nowSec), Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// FILMS & SÉRIES (grilles d'affiches)
// =====================================================================

@Composable
private fun <T> PosterGridScreen(
    items: List<T>,
    categoryOf: (T) -> String,
    nameOf: (T) -> String,
    dateOf: (T) -> Long,
    ratingOf: (T) -> Double,
    emptyText: String,
    card: @Composable (T) -> Unit
) {
    if (items.isEmpty()) {
        EmptyMessage(emptyText)
        return
    }
    val cats = remember(items) { listOf("Tout") + items.map(categoryOf).distinct() }
    var cat by rememberSaveable { mutableStateOf("Tout") }
    var sort by rememberSaveable { mutableStateOf("Par défaut") }
    val list = remember(items, cat, sort) {
        val base = if (cat == "Tout") items else items.filter { categoryOf(it) == cat }
        when (sort) {
            "A → Z" -> base.sortedBy { nameOf(it).lowercase() }
            "Récents" -> base.sortedByDescending { dateOf(it) }
            "Mieux notés" -> base.sortedByDescending { ratingOf(it) }
            else -> base
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(cats) { c ->
                FocusBox(onClick = { cat = c }, selected = c == cat, focusScale = 1.04f, shape = RoundedCornerShape(20.dp)) { f ->
                    Text(
                        c,
                        color = if (f || c == cat) TextMain else TextSoft,
                        fontSize = 15.sp,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
        Row(
            Modifier.padding(start = 28.dp, end = 28.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("${list.size} titre(s)  ·  Trier :", color = TextSoft, fontSize = 13.sp)
            listOf("Par défaut", "A → Z", "Récents", "Mieux notés").forEach { o ->
                FocusBox(onClick = { sort = o }, selected = o == sort, focusScale = 1.04f, shape = RoundedCornerShape(16.dp)) { f ->
                    Text(
                        o, color = if (f || o == sort) TextMain else TextSoft, fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(start = 28.dp, end = 28.dp, top = 8.dp, bottom = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            gridItems(list) { item -> card(item) }
        }
    }
}

@Composable
fun MoviesScreen(vm: AppViewModel, nav: Nav) {
    val prog = remember(vm.progressVersion) { vm.progressMap() }
    PosterGridScreen(
        items = vm.movies,
        categoryOf = { it.category },
        nameOf = { it.name },
        dateOf = { it.added },
        ratingOf = { it.rating?.toDoubleOrNull() ?: 0.0 },
        emptyText = "Aucun film disponible avec cette source."
    ) { m ->
        PosterCard(m.name, m.poster, { nav.openMovie(m) }, width = 150.dp, progress = prog[m.favKey] ?: 0f, badge = m.rating)
    }
}

@Composable
fun SeriesScreen(vm: AppViewModel, nav: Nav) {
    PosterGridScreen(
        items = vm.series,
        categoryOf = { it.category },
        nameOf = { it.name },
        dateOf = { it.added },
        ratingOf = { it.rating?.toDoubleOrNull() ?: 0.0 },
        emptyText = "Aucune série disponible avec cette source."
    ) { s ->
        PosterCard(s.name, s.cover, { nav.openSeries(s) }, width = 150.dp, badge = s.rating)
    }
}

// =====================================================================
// RECHERCHE
// =====================================================================

@Composable
fun SearchScreen(vm: AppViewModel, nav: Nav) {
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim()
    val chs = remember(q, vm.channels) { if (q.length < 2) emptyList() else vm.channels.filter { it.name.contains(q, true) }.take(30) }
    val mvs = remember(q, vm.movies) { if (q.length < 2) emptyList() else vm.movies.filter { it.name.contains(q, true) }.take(40) }
    val srs = remember(q, vm.series) { if (q.length < 2) emptyList() else vm.series.filter { it.name.contains(q, true) }.take(40) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(28.dp)) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Rechercher une chaîne, un film, une série…") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (q.length >= 2 && chs.isEmpty() && mvs.isEmpty() && srs.isEmpty()) {
            item { Text("Aucun résultat pour « $q ».", color = TextSoft, fontSize = 16.sp, modifier = Modifier.padding(top = 24.dp)) }
        }
        if (chs.isNotEmpty()) {
            item { SectionTitle("Chaînes") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                    itemsIndexed(chs) { i, c -> LiveCard(vm, c) { nav.play(chs.map { vm.playableOf(it) }, i) } }
                }
            }
        }
        if (mvs.isNotEmpty()) {
            item { SectionTitle("Films") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
                    items(mvs) { m -> PosterCard(m.name, m.poster, { nav.openMovie(m) }, badge = m.rating) }
                }
            }
        }
        if (srs.isNotEmpty()) {
            item { SectionTitle("Séries") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
                    items(srs) { s -> PosterCard(s.name, s.cover, { nav.openSeries(s) }, badge = s.rating) }
                }
            }
        }
    }
}

// =====================================================================
// FAVORIS
// =====================================================================

@Composable
fun FavoritesScreen(vm: AppViewModel, nav: Nav) {
    val favs = vm.favorites
    val chs = remember(vm.channels, favs) { vm.channels.filter { it.favKey in favs } }
    val mvs = remember(vm.movies, favs) { vm.movies.filter { it.favKey in favs } }
    val srs = remember(vm.series, favs) { vm.series.filter { it.favKey in favs } }

    if (chs.isEmpty() && mvs.isEmpty() && srs.isEmpty()) {
        EmptyMessage("Pas encore de favoris. Ajoute-les avec le cœur sur une chaîne, un film ou une série.")
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(28.dp)) {
        if (chs.isNotEmpty()) {
            item { SectionTitle("Chaînes favorites") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(8.dp)) {
                    itemsIndexed(chs) { i, c -> LiveCard(vm, c) { nav.play(chs.map { vm.playableOf(it) }, i) } }
                }
            }
        }
        if (mvs.isNotEmpty()) {
            item { SectionTitle("Ma liste de films") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
                    items(mvs) { m -> PosterCard(m.name, m.poster, { nav.openMovie(m) }, badge = m.rating) }
                }
            }
        }
        if (srs.isNotEmpty()) {
            item { SectionTitle("Mes séries") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(8.dp)) {
                    items(srs) { s -> PosterCard(s.name, s.cover, { nav.openSeries(s) }, badge = s.rating) }
                }
            }
        }
    }
}

// =====================================================================
// PARAMÈTRES
// =====================================================================

@Composable
fun SettingsScreen(vm: AppViewModel, nav: Nav) {
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }
    // "toggle", "old", "new", "locks", "unlock"
    var pinAction by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var showAccounts by remember { mutableStateOf(false) }
    var showLocks by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    var showStyles by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Paramètres", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp)) }
        item {
            val sub = vm.account?.let { "Xtream · ${it.user} · ${it.server}" + (vm.expiry?.let { e -> " · jusqu'au $e" } ?: "") }
                ?: if (vm.lastUrl.isNotBlank()) "Lien M3U" else "Aucune source"
            SettingRow("Compte et source", sub, nav.openSource)
        }
        item {
            val styleName = when (vm.layoutStyle) { "premium" -> "Premium"; "classic" -> "Classique"; "mosaic" -> "Mosaïque"; else -> "Moderne" }
            SettingRow("Style d'interface", "$styleName · change toute la disposition de l'appli") { showStyles = true }
        }
        item {
            SettingRow(
                "Intro animée à l'ouverture",
                if (vm.introEnabled) "Oui : logo en 3D et effets de lumière" else "Non : démarrage rapide"
            ) { vm.setIntroEnabledValue(!vm.introEnabled) }
        }
        item {
            SettingRow(
                "Thème",
                "Couleur ${AppTheme.accent.name} · Fond ${AppTheme.background.name}"
            ) { showThemes = true }
        }
        item {
            SettingRow(
                "Mes comptes",
                if (vm.accounts.isEmpty()) "Aucun compte enregistré" else "${vm.accounts.size} compte(s) · changer en un clic"
            ) { showAccounts = true }
        }
        item {
            SettingRow(
                "Dernière chaîne au démarrage",
                if (vm.autoLastChannel) "Oui : la dernière chaîne regardée se relance" else "Non : l'appli s'ouvre sur l'accueil"
            ) { vm.setAutoLastChannelValue(!vm.autoLastChannel) }
        }
        item {
            SettingRow(
                "Actualiser les listes",
                "${vm.channels.size} chaînes · ${vm.movies.size} films · ${vm.series.size} séries"
            ) { vm.refresh(); info = "Actualisation en cours…" }
        }
        item {
            SettingRow(
                "Contrôle parental",
                if (vm.hideAdult) "Contenus adultes masqués" else "Contenus adultes visibles"
            ) { pinAction = "toggle" }
        }
        item {
            SettingRow(
                "Catégories verrouillées",
                if (vm.lockedCats.isEmpty()) "Aucune · protège des catégories avec le code PIN" else "${vm.lockedCats.size} catégorie(s) verrouillée(s)"
            ) { pinAction = "locks" }
        }
        item {
            SettingRow(
                if (vm.sessionUnlocked) "Reverrouiller maintenant" else "Déverrouiller jusqu'à la fermeture",
                if (vm.sessionUnlocked) "Tout est visible pour le moment" else "Affiche les contenus protégés après le code PIN"
            ) {
                if (vm.sessionUnlocked) vm.setSessionUnlockedValue(false) else pinAction = "unlock"
            }
        }
        item { SettingRow("Changer le code PIN", "Code par défaut : 0000") { pinAction = "old" } }
        item { SettingRow("Effacer l'historique de lecture", "Vide la rangée « Reprendre la lecture »") { vm.clearHistory(); info = "Historique effacé" } }
        item {
            SettingRow(
                "À propos",
                "IR PRO version $version · Cette appli ne fournit aucun contenu : elle lit uniquement ta propre source."
            ) {}
        }
        info?.let { item { Text(it, color = PurpleLight, fontSize = 15.sp, modifier = Modifier.padding(8.dp)) } }
    }

    when (pinAction) {
        "toggle" -> PinDialog(
            title = if (vm.hideAdult) "Afficher les contenus adultes" else "Masquer les contenus adultes",
            onDismiss = { pinAction = null }
        ) { pin ->
            if (vm.checkPin(pin)) {
                vm.setHideAdultValue(!vm.hideAdult); true
            } else false
        }
        "old" -> PinDialog(title = "Code PIN actuel", onDismiss = { if (pinAction == "old") pinAction = null }) { pin ->
            if (vm.checkPin(pin)) {
                pinAction = "new"; true
            } else false
        }
        "new" -> PinDialog(title = "Nouveau code PIN", onDismiss = { pinAction = null }) { pin ->
            vm.changePin(pin); info = "Code PIN modifié"; true
        }
        "locks" -> PinDialog(title = "Code PIN", onDismiss = { if (pinAction == "locks") pinAction = null }) { pin ->
            if (vm.checkPin(pin)) {
                pinAction = null; showLocks = true; true
            } else false
        }
        "unlock" -> PinDialog(title = "Déverrouiller", onDismiss = { pinAction = null }) { pin ->
            if (vm.checkPin(pin)) {
                vm.setSessionUnlockedValue(true); true
            } else false
        }
    }

    if (showAccounts) AccountsDialog(vm, nav, onDismiss = { showAccounts = false })
    if (showLocks) LocksDialog(vm, onDismiss = { showLocks = false })
    if (showThemes) ThemeDialog(vm, onDismiss = { showThemes = false })
    if (showStyles) StyleDialog(vm, onDismiss = { showStyles = false })
}

@Composable
private fun StyleDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val styles = listOf(
        Triple("premium", "Premium", "Plein écran cinéma, lumière d'ambiance, cartes qui s'agrandissent"),
        Triple("modern", "Moderne", "Menu en icônes à gauche, rangées d'affiches (façon Netflix)"),
        Triple("classic", "Classique", "Grand menu à tuiles au démarrage (façon MyTVOnline)"),
        Triple("mosaic", "Mosaïque", "Menu en haut, chaînes en grandes cases avec logo")
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Style d'interface", color = TextMain) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                styles.forEach { (id, name, desc) ->
                    val sel = vm.layoutStyle == id
                    FocusBox(
                        onClick = { vm.setLayoutStyleValue(id); onDismiss() },
                        selected = sel, focusScale = 1.02f,
                        modifier = Modifier.fillMaxWidth()
                    ) { f ->
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                            Text((if (sel) "● " else "○ ") + name, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(desc, color = if (f) TextMain else TextSoft, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
private fun ThemeDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Thème", color = TextMain) },
        text = {
            Column {
                Text("COULEUR PRINCIPALE", color = TextSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(4.dp)) {
                    itemsIndexed(accentThemes) { i, t ->
                        val sel = AppTheme.accent == t
                        FocusBox(onClick = { vm.setAccent(i) }, selected = sel, shape = RoundedCornerShape(14.dp), filledWhenFocused = false) { f ->
                            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(44.dp).background(t.primary, RoundedCornerShape(22.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (sel) Text("✓", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(t.name, color = if (f || sel) TextMain else TextSoft, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("FOND", color = TextSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(4.dp)) {
                    itemsIndexed(backgroundThemes) { i, t ->
                        val sel = AppTheme.background == t
                        FocusBox(onClick = { vm.setBackground(i) }, selected = sel, shape = RoundedCornerShape(14.dp), filledWhenFocused = false) { f ->
                            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(Modifier.size(width = 64.dp, height = 40.dp).background(t.bg, RoundedCornerShape(8.dp)).padding(6.dp)) {
                                    Box(Modifier.width(12.dp).fillMaxHeight().background(t.panel, RoundedCornerShape(3.dp)))
                                    Spacer(Modifier.width(4.dp))
                                    Box(Modifier.weight(1f).fillMaxHeight().background(t.card, RoundedCornerShape(3.dp)))
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(t.name, color = if (f || sel) TextMain else TextSoft, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Terminé") } }
    )
}

@Composable
private fun AccountsDialog(vm: AppViewModel, nav: Nav, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Mes comptes", color = TextMain) },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (vm.accounts.isEmpty()) {
                    item { Text("Aucun compte. Ajoute-en un avec le bouton ci-dessous.", color = TextSoft) }
                }
                items(vm.accounts) { a ->
                    val current = vm.isCurrent(a)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FocusBox(
                            onClick = { if (!current) vm.switchAccount(a); onDismiss() },
                            selected = current, focusScale = 1.02f,
                            modifier = Modifier.weight(1f)
                        ) { f ->
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                Text((if (current) "● " else "") + a.name, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("${a.user} · ${a.server}", color = if (f) TextMain else TextSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (!current) {
                            Spacer(Modifier.width(6.dp))
                            FocusBox(onClick = { vm.deleteAccount(a) }, shape = RoundedCornerShape(20.dp)) {
                                Text("Supprimer", color = FavPink, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDismiss(); nav.openSource() }) { Text("Ajouter un compte") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
private fun LocksDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val cats = remember { vm.allCategories() }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Catégories verrouillées", color = TextMain) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item { Text("Les catégories cochées sont cachées partout tant qu'on n'a pas tapé le code PIN.", color = TextSoft, fontSize = 13.sp) }
                items(cats) { c ->
                    val locked = c in vm.lockedCats
                    FocusBox(onClick = { vm.setLocked(c, !locked) }, selected = locked, focusScale = 1.02f, modifier = Modifier.fillMaxWidth()) { f ->
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (locked) "🔒" else "○", fontSize = 14.sp, color = if (f || locked) TextMain else TextSoft, modifier = Modifier.width(28.dp))
                            Text(c, color = if (f || locked) TextMain else TextSoft, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Terminé") } }
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    FocusBox(onClick = onClick, selected = true, focusScale = 1.01f, modifier = Modifier.fillMaxWidth()) { f ->
        Row(Modifier.padding(horizontal = 22.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = if (f) TextMain else TextSoft, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = if (f) Color.White else TextSoft)
        }
    }
}
